Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let node_fs = require("node:fs");
let node_path = require("node:path");
let node_child_process = require("node:child_process");
let node_os = require("node:os");
let node_events = require("node:events");
//#region mods/livepet/main/stt.ts
var MODELS = [{
	id: "base-q5",
	file: "ggml-base-q5_1.bin",
	bytes: 59707625,
	label: "base（推荐）",
	desc: "59 MB，中文识别准确，一段话约 1~2 秒"
}, {
	id: "tiny-q5",
	file: "ggml-tiny-q5_1.bin",
	bytes: 32152673,
	label: "tiny（轻量）",
	desc: "32 MB，更快更省内存，个别字容易听错"
}];
/** 国内可直连的 HF 镜像；官方域名放最后，作为镜像失效时的兜底。 */
var MODEL_HOSTS = ["https://hf-mirror.com/ggerganov/whisper.cpp/resolve/main/", "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"];
var SttEngine = class {
	paths;
	log;
	onProgress;
	downloading = null;
	cancelled = false;
	constructor(paths, log, onProgress) {
		this.paths = paths;
		this.log = log;
		this.onProgress = onProgress;
	}
	/** `stt/` inside the installed plugin: whisper-cli.exe + its DLLs. */
	binDir() {
		return (0, node_path.join)(this.paths.installDir, "stt");
	}
	exe() {
		return (0, node_path.join)(this.binDir(), "whisper-cli.exe");
	}
	/** Where the downloaded model lives. `models/` under the plugin's private data. */
	modelPath(modelId) {
		const model = MODELS.find((m) => m.id === modelId) ?? MODELS[0];
		return (0, node_path.join)(this.paths.dataDir, "models", model.file);
	}
	/** runtime present and usable? Does not check the model. */
	runtimeReady() {
		return (0, node_fs.existsSync)(this.exe());
	}
	modelReady(modelId) {
		const model = MODELS.find((m) => m.id === modelId) ?? MODELS[0];
		try {
			return (0, node_fs.existsSync)(this.modelPath(model.id)) && (0, node_fs.statSync)(this.modelPath(model.id)).size >= model.bytes * .95;
		} catch {
			return false;
		}
	}
	status(modelId) {
		const model = MODELS.find((m) => m.id === modelId) ?? MODELS[0];
		let bytes = 0;
		try {
			bytes = (0, node_fs.statSync)(this.modelPath(model.id)).size;
		} catch {}
		return {
			runtime: this.runtimeReady(),
			model: this.modelReady(model.id),
			modelId: model.id,
			bytes
		};
	}
	cancelDownload() {
		this.cancelled = true;
	}
	/**
	* Downloads the model once, then reuses it forever.
	*
	* The request goes straight to the mirror: routing 59 MB through the user's proxy is
	* slower than the mirror itself, and the mirror is reachable from the mainland.
	*/
	async ensureModel(modelId) {
		const model = MODELS.find((m) => m.id === modelId) ?? MODELS[0];
		const target = this.modelPath(model.id);
		if (this.modelReady(model.id)) return target;
		if (this.downloading) return this.downloading;
		this.cancelled = false;
		this.downloading = (async () => {
			(0, node_fs.mkdirSync)((0, node_path.join)(this.paths.dataDir, "models"), { recursive: true });
			const part = `${target}.part`;
			let lastError = "";
			for (const host of MODEL_HOSTS) {
				const url = host + model.file;
				try {
					this.log("info", `下载 ${model.file} ← ${host}`);
					await this.fetchTo(url, part, model.bytes);
					const size = (0, node_fs.statSync)(part).size;
					if (size < model.bytes * .95) throw new Error(`下载不完整（${size} 字节）`);
					return await this.finalize(part, target);
				} catch (e) {
					lastError = e instanceof Error ? e.message : String(e);
					this.log("warn", `模型下载失败（${host}）：${lastError}`);
					if (this.cancelled) break;
				}
			}
			this.downloading = null;
			throw new Error(`模型下载失败：${lastError || "所有镜像都不可用"}`);
		})();
		try {
			return await this.downloading;
		} finally {
			this.downloading = null;
		}
	}
	async finalize(part, target) {
		const { renameSync } = await import("node:fs");
		renameSync(part, target);
		this.onProgress({
			ratio: 1,
			received: (0, node_fs.statSync)(target).size,
			total: (0, node_fs.statSync)(target).size
		});
		return target;
	}
	async fetchTo(url, dest, expected) {
		const res = await fetch(url, { redirect: "follow" });
		if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
		const total = Number(res.headers.get("content-length")) || expected;
		let received = 0;
		const out = (0, node_fs.createWriteStream)(dest);
		const reader = res.body.getReader();
		try {
			for (;;) {
				const { done, value } = await reader.read();
				if (done) break;
				if (this.cancelled) throw new Error("已取消");
				received += value.byteLength;
				out.write(value);
				if (received % 262144 < 8192) this.onProgress({
					ratio: total ? received / total : -1,
					received,
					total
				});
			}
		} finally {
			out.end();
			await (0, node_events.once)(out, "finish").catch(() => void 0);
		}
		this.onProgress({
			ratio: 1,
			received,
			total
		});
	}
	/**
	* Transcribes a 16 kHz mono WAV and returns simplified-Chinese text.
	*
	* whisper-cli writes the transcript to `<prefix>.txt`; parsing stdout instead would
	* mean fighting with its banner and timing lines.
	*/
	async transcribe(wavPath, modelId, opts = {}) {
		if (!this.runtimeReady()) throw new Error("插件里缺少语音识别组件（stt/whisper-cli.exe），请重新安装插件");
		const model = this.modelReady(modelId) ? this.modelPath(modelId) : await this.ensureModel(modelId);
		const dataDir = this.paths.dataDir;
		const relModel = (0, node_path.relative)(dataDir, model).replace(/\\/g, "/");
		const relWav = (0, node_path.relative)(dataDir, wavPath).replace(/\\/g, "/");
		if (relModel.startsWith("..") || relWav.startsWith("..")) throw new Error("语音文件不在插件数据目录内，无法识别");
		const relOut = relWav.replace(/\.wav$/i, "");
		const threads = Math.max(2, Math.min(8, Math.floor((0, node_os.cpus)().length / 2)));
		const args = [
			"-m",
			relModel,
			"-f",
			relWav,
			"-l",
			opts.language ?? "zh",
			"-nt",
			"-otxt",
			"-of",
			relOut,
			"-t",
			String(threads)
		];
		this.log("info", `whisper ${relModel} · ${relWav} · ${threads} 线程`);
		const text = await new Promise((resolve, reject) => {
			const child = (0, node_child_process.spawn)(this.exe(), args, {
				cwd: dataDir,
				windowsHide: true,
				stdio: [
					"ignore",
					"pipe",
					"pipe"
				]
			});
			let stderr = "";
			child.stderr?.on("data", (buf) => {
				stderr += buf.toString("utf8");
			});
			const timer = setTimeout(() => {
				child.kill();
				reject(/* @__PURE__ */ new Error("语音识别超时"));
			}, 3e4);
			child.on("error", (e) => {
				clearTimeout(timer);
				reject(/* @__PURE__ */ new Error(`无法启动语音识别：${e.message}`));
			});
			child.on("exit", (code) => {
				clearTimeout(timer);
				if (code !== 0) {
					reject(/* @__PURE__ */ new Error(`语音识别失败（退出码 ${code}）${stderr ? `：${stderr.slice(-200)}` : ""}`));
					return;
				}
				try {
					resolve((0, node_fs.readFileSync)(`${wavPath.replace(/\.wav$/i, "")}.txt`, "utf8"));
				} catch {
					resolve("");
				}
			});
		});
		return this.toSimplified(cleanTranscript(text));
	}
	/**
	* whisper's Chinese output is frequently traditional, so the transcript is folded to
	* simplified before it is shown or sent to the model.
	*
	* The table is OpenCC's `TSCharacters.txt` (4148 single-character mappings, 34 KB),
	* shipped with the plugin and read from disk — no dictionary is embedded in the bundle.
	*/
	toSimplified(text) {
		if (!this.table) try {
			const raw = (0, node_fs.readFileSync)((0, node_path.join)(this.paths.installDir, "stt", "t2s.tsv"), "utf8").replace(/\r/g, "");
			const map = /* @__PURE__ */ new Map();
			for (const line of raw.split("\n")) {
				const i = line.indexOf("	");
				if (i > 0) map.set(line.slice(0, i), line.slice(i + 1));
			}
			this.table = map;
		} catch {
			this.table = /* @__PURE__ */ new Map();
		}
		let out = "";
		for (const ch of text) out += this.table.get(ch) ?? ch;
		return out;
	}
	table = null;
};
/**
* Drops what whisper likes to add around real speech: bracketed sound markers such as
* `[音乐]`、`（笑声）`, leftover timestamps, and stray spaces between CJK characters.
*
* whisper-cli writes one line per segment, joined with CRLF — and its segments break
* mid-sentence, so the carriage returns must go before anything else or the transcript
* ends up with `帮\r我看看现\r在几\r点`. Line breaks are only dropped for CJK text; latin
* output keeps a single space between lines so English words do not run together.
*/
function cleanTranscript(raw) {
	return raw.replace(/\r\n?/g, "\n").replace(/\[[^\]]*\]/g, "").replace(/（[^）]*）/g, "").replace(/\([^)]*\)/g, "").replace(/\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[,.]\d{3}/g, "").split("\n").map((line) => line.trim()).filter(Boolean).join("\n").replace(/(?<=[\u4e00-\u9fff，。！？、；：])\n(?=[\u4e00-\u9fff，。！？、；：])/g, "").replace(/\n+/g, " ").replace(/[ \t]+/g, " ").replace(/\s+([，。！？、；：])/g, "$1").trim();
}
//#endregion
//#region mods/livepet/main/index.ts
var DEFAULTS = {
	hitBox: null,
	modelDir: "",
	modelFile: "",
	windowId: null,
	scale: 1,
	alwaysOnTop: true,
	sttModel: "base-q5"
};
/** Live2D models only reference a handful of file types; everything else is dead weight. */
var KEEP = /* @__PURE__ */ new Set([
	".json",
	".moc3",
	".png",
	".jpg",
	".jpeg",
	".webp",
	".wav",
	".mp3",
	".motion3.json"
]);
function register(dola) {
	const stateFile = (0, node_path.join)(dola.dataDir, "pet.json");
	const modelsRoot = (0, node_path.join)(dola.dataDir, "models");
	(0, node_fs.mkdirSync)(modelsRoot, { recursive: true });
	const audioDir = (0, node_path.join)(dola.dataDir, "audio");
	(0, node_fs.mkdirSync)(audioDir, { recursive: true });
	let state = { ...DEFAULTS };
	try {
		if ((0, node_fs.existsSync)(stateFile)) state = {
			...DEFAULTS,
			...JSON.parse((0, node_fs.readFileSync)(stateFile, "utf8"))
		};
	} catch {}
	const save = () => {
		try {
			(0, node_fs.mkdirSync)(dola.dataDir, { recursive: true });
			(0, node_fs.writeFileSync)(stateFile, JSON.stringify({
				...state,
				windowId: null,
				hitBox: null
			}, null, 2));
		} catch {}
	};
	const stt = new SttEngine({
		installDir: dola.installDir,
		dataDir: dola.dataDir
	}, (level, msg) => dola.log(level, msg), (p) => dola.ipc.broadcast("stt-progress", p));
	/** Copies a model folder into the plugin's data dir, keeping only referenced files. */
	const importModel = async (sourceDir) => {
		const findModel = (dir, depth = 0) => {
			let entries = [];
			try {
				entries = (0, node_fs.readdirSync)(dir);
			} catch {
				return null;
			}
			const direct = entries.find((n) => n.toLowerCase().endsWith(".model3.json"));
			if (direct) return (0, node_path.join)(dir, direct);
			if (depth >= 2) return null;
			for (const name of entries) {
				const full = (0, node_path.join)(dir, name);
				try {
					if ((0, node_fs.readdirSync)(full).length) {
						const nested = findModel(full, depth + 1);
						if (nested) return nested;
					}
				} catch {}
			}
			return null;
		};
		const modelJson = findModel(sourceDir);
		if (!modelJson) throw new Error("这个文件夹里没有 .model3.json，可能不是 Live2D 模型");
		const root = (0, node_path.dirname)(modelJson);
		JSON.parse((0, node_fs.readFileSync)(modelJson, "utf8")).FileReferences;
		const name = (0, node_path.basename)(root);
		const target = (0, node_path.join)(modelsRoot, name);
		(0, node_fs.rmSync)(target, {
			recursive: true,
			force: true
		});
		(0, node_fs.mkdirSync)(target, { recursive: true });
		const copy = (from, to) => {
			for (const entry of (0, node_fs.readdirSync)(from, { withFileTypes: true })) {
				const src = (0, node_path.join)(from, entry.name);
				const dst = (0, node_path.join)(to, entry.name);
				if (entry.isDirectory()) {
					(0, node_fs.mkdirSync)(dst, { recursive: true });
					copy(src, dst);
				} else {
					const lower = entry.name.toLowerCase();
					if (lower.endsWith(".json") || KEEP.has((0, node_path.extname)(lower)) || lower.includes(".motion3.json")) (0, node_fs.cpSync)(src, dst);
				}
			}
		};
		copy(root, target);
		return {
			name,
			entry: (0, node_path.relative)(target, (0, node_path.join)(target, (0, node_path.relative)(root, modelJson))).replace(/\\/g, "/")
		};
	};
	const openPet = async () => {
		if (!state.modelFile) return {
			ok: false,
			error: "请先在设置里上传 Live2D 模型"
		};
		if (state.windowId) return {
			ok: true,
			windowId: state.windowId
		};
		const modelPath = `@data/models/${state.modelDir}/${state.modelFile}`.replace(/\/+/g, "/");
		const id = await dola.desktop.open({
			modId: "livepet",
			page: "pet.html",
			width: 380,
			height: 520,
			ignoreMouse: true,
			alwaysOnTop: state.alwaysOnTop,
			query: {
				model: modelPath,
				scale: String(state.scale)
			}
		});
		state.windowId = id;
		save();
		return {
			ok: true,
			windowId: id
		};
	};
	const closePet = () => {
		if (state.windowId) {
			dola.desktop.close(state.windowId);
			state.windowId = null;
			save();
		}
		return { ok: true };
	};
	dola.ipc.handle("state", () => ({
		modelDir: state.modelDir,
		modelFile: state.modelFile,
		showing: Boolean(state.windowId),
		scale: state.scale,
		alwaysOnTop: state.alwaysOnTop
	}));
	dola.ipc.handle("pick-model", async () => {
		try {
			const picked = await dola.dialog.pickDirectory("选择 Live2D 模型文件夹（含 .model3.json）");
			if (!picked) return {
				ok: false,
				canceled: true
			};
			const { name, entry } = await importModel(picked);
			state.modelDir = name;
			state.modelFile = entry;
			state.windowId = null;
			save();
			dola.ipc.broadcast("state-changed", {
				modelDir: name,
				modelFile: entry,
				showing: false
			});
			return {
				ok: true,
				name,
				entry
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "导入失败"
			};
		}
	});
	/** Import from an explicit path (also used by tests, since dialogs need a human). */
	dola.ipc.handle("import-model", async (dir) => {
		if (typeof dir !== "string" || !dir) return {
			ok: false,
			error: "缺少路径"
		};
		try {
			const { name, entry } = await importModel(dir);
			state.modelDir = name;
			state.modelFile = entry;
			state.windowId = null;
			save();
			dola.ipc.broadcast("state-changed", {
				modelDir: name,
				modelFile: entry,
				showing: false
			});
			return {
				ok: true,
				name,
				entry
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "导入失败"
			};
		}
	});
	dola.ipc.handle("show", () => openPet());
	dola.ipc.handle("hide", () => closePet());
	dola.ipc.handle("set-scale", (_scale) => {
		const s = Number(_scale);
		if (Number.isFinite(s) && s > .2 && s < 3) state.scale = s;
		save();
		if (state.windowId) {
			dola.desktop.close(state.windowId);
			state.windowId = null;
			openPet();
		}
		return {
			ok: true,
			scale: state.scale
		};
	});
	dola.ipc.handle("set-on-top", (on) => {
		state.alwaysOnTop = Boolean(on);
		if (state.windowId) dola.desktop.setAlwaysOnTop(state.windowId, state.alwaysOnTop);
		save();
		return {
			ok: true,
			alwaysOnTop: state.alwaysOnTop
		};
	});
	/**
	* The page reports the character's box so the host can decide where clicks land.
	*
	* The window is created with passthrough on; the page then toggles it off whenever the
	* pointer is over the character and back on when it leaves. That needs the pointer
	* position, which only the page has (Electron's `forward: true` keeps mousemove flowing
	* while ignoring clicks), so the page drives it and the main side just stores the box.
	*/
	dola.ipc.handle("hit-box", (box) => {
		if (!state.windowId || !box || typeof box !== "object") return { ok: false };
		state.hitBox = box;
		return { ok: true };
	});
	/** Called by the page as the pointer enters / leaves the character. */
	dola.ipc.handle("set-passthrough", (ignore) => {
		if (!state.windowId) return { ok: false };
		dola.desktop.setIgnoreMouse(state.windowId, Boolean(ignore));
		return { ok: true };
	});
	dola.ipc.handle("list-windows", () => dola.desktop.list());
	let orbWindow = null;
	let orbExpanded = false;
	const openOrb = async () => {
		if (orbWindow) return orbWindow;
		orbWindow = await dola.desktop.open({
			modId: "livepet",
			page: "orb.html",
			width: 240,
			height: 60,
			ignoreMouse: false,
			alwaysOnTop: true
		});
		dola.desktop.setBounds(orbWindow, {
			width: 240,
			height: 60
		});
		return orbWindow;
	};
	const closeOrb = () => {
		if (orbWindow) {
			dola.desktop.close(orbWindow);
			orbWindow = null;
		}
	};
	dola.ipc.handle("orb-show", async () => {
		if (orbWindow) return { ok: true };
		await openOrb();
		return { ok: true };
	});
	dola.ipc.handle("orb-hide", () => {
		closeOrb();
		return { ok: true };
	});
	dola.ipc.handle("orb-state", () => ({
		expanded: orbExpanded,
		showing: Boolean(orbWindow)
	}));
	dola.ipc.handle("orb-expanded", (on) => {
		orbExpanded = Boolean(on);
		save();
		return { ok: true };
	});
	dola.ipc.handle("orb-window", () => dola.desktop.list().filter((w) => w.id === orbWindow).map((w) => ({
		id: w.id,
		bounds: w.bounds
	})));
	dola.ipc.handle("orb-move", (pos) => {
		if (!orbWindow || !pos || typeof pos !== "object") return { ok: false };
		const p = pos;
		dola.desktop.setBounds(orbWindow, {
			x: p.x,
			y: p.y
		});
		return { ok: true };
	});
	/**
	* Grows / shrinks the orb window.
	*
	* The ball and the result panel share one window, so the page asks for a taller window
	* when a result arrives and shrinks back when it is dismissed. The width stays fixed at
	* the row width — resizing it would re-centre the disc and make it jump.
	*/
	dola.ipc.handle("orb-resize", (spec) => {
		if (!orbWindow || !spec || typeof spec !== "object") return { ok: false };
		const s = spec;
		const height = Math.max(60, Math.min(720, Math.round(Number(s.height) || 60)));
		dola.desktop.setBounds(orbWindow, {
			...typeof s.x === "number" ? { x: Math.round(s.x) } : {},
			...typeof s.y === "number" ? { y: Math.round(s.y) } : {},
			width: 240,
			height
		});
		return { ok: true };
	});
	dola.ipc.handle("orb-open-settings", () => {
		const win = dola.windows.main();
		if (win) {
			win.show();
			win.focus();
		}
		return { ok: true };
	});
	/** The four orb buttons. Vision / STT / chat all route through the app's AI settings. */
	dola.ipc.handle("orb-action", async (action) => {
		const kind = String(action);
		try {
			if (kind === "vision") {
				const shot = await captureScreen();
				if (!shot) return {
					ok: false,
					error: "无法截屏"
				};
				const res = await dola.ai.chat([{
					role: "system",
					content: "你是一个桌面助手，请用简短中文描述这张屏幕截图的内容与当前用户在做什么。"
				}, {
					role: "user",
					content: [{
						type: "text",
						text: "请描述这张截图。"
					}, {
						type: "image_url",
						image_url: { url: shot }
					}]
				}]);
				return res.ok ? {
					ok: true,
					text: res.content
				} : {
					ok: false,
					error: res.error
				};
			}
			if (kind === "chat") {
				const res = await dola.ai.chat([{
					role: "user",
					content: "你好，用一句话介绍你自己。"
				}]);
				return res.ok ? {
					ok: true,
					text: res.content
				} : {
					ok: false,
					error: res.error
				};
			}
			return {
				ok: false,
				error: `未知操作：${kind}`
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "操作失败"
			};
		}
	});
	/**
	* The orb records from the microphone itself (only a renderer has `getUserMedia`), then
	* posts the captured audio here as a base64 WAV. The main process writes it to disk and
	* runs whisper-cli, so the recognition happens locally and the audio never leaves the
	* machine.
	*/
	dola.ipc.handle("stt-status", () => stt.status(state.sttModel));
	dola.ipc.handle("stt-set-model", (id) => {
		const model = MODELS.find((m) => m.id === String(id));
		if (!model) return {
			ok: false,
			error: "未知模型"
		};
		state.sttModel = model.id;
		save();
		return {
			ok: true,
			modelId: model.id
		};
	});
	dola.ipc.handle("stt-download", async (id) => {
		const modelId = MODELS.some((m) => m.id === String(id)) ? String(id) : state.sttModel;
		try {
			await stt.ensureModel(modelId);
			return {
				ok: true,
				modelId
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "下载失败"
			};
		}
	});
	dola.ipc.handle("stt-cancel-download", () => {
		stt.cancelDownload();
		return { ok: true };
	});
	/**
	* Writes the posted audio and runs whisper over it.
	*
	* Shared by 转写 (stt-transcribe) and 语音问答 (stt-ask) so both go through exactly the
	* same path — including the model auto-download on first use.
	*/
	const transcribePosted = async (payload, opts) => {
		const data = String(payload ?? "");
		if (!data) return {
			ok: false,
			error: "没有收到音频"
		};
		const language = typeof opts === "object" && opts ? opts.language : void 0;
		const wavPath = (0, node_path.join)(audioDir, "last.wav");
		try {
			(0, node_fs.writeFileSync)(wavPath, Buffer.from(data, "base64"));
		} catch (e) {
			return {
				ok: false,
				error: `写入音频失败：${e instanceof Error ? e.message : "未知错误"}`
			};
		}
		try {
			return {
				ok: true,
				text: await stt.transcribe(wavPath, state.sttModel, { language })
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "识别失败"
			};
		}
	};
	dola.ipc.handle("stt-transcribe", async (payload, opts) => {
		const res = await transcribePosted(payload, opts);
		return res.ok ? {
			ok: true,
			text: res.text,
			modelId: state.sttModel
		} : res;
	});
	/** 听音 = 说话 → 本地转写 → 用软件里的 AI 设置回答。 */
	dola.ipc.handle("stt-ask", async (payload, opts) => {
		const res = await transcribePosted(payload, opts);
		if (!res.ok) return {
			ok: false,
			error: res.error
		};
		const heard = res.text;
		if (!heard) return {
			ok: true,
			heard: "",
			reply: "",
			text: "",
			error: "没听清，再说一遍？"
		};
		if (!dola.ai.status().configured) return {
			ok: true,
			heard,
			reply: "",
			text: "",
			error: "软件设置里还没有配置 AI，只能先给你转写结果"
		};
		const chat = await dola.ai.chat([{
			role: "system",
			content: "你是一个桌面助手。用户在用语音和你说话，请用一到两句话简短回答，不要列表、不要标题。"
		}, {
			role: "user",
			content: heard
		}]);
		return chat.ok ? {
			ok: true,
			heard,
			reply: chat.content,
			text: chat.content
		} : {
			ok: true,
			heard,
			reply: "",
			text: "",
			error: chat.error ?? "AI 没有返回内容"
		};
	});
	dola.on("boot", async () => {
		openOrb().catch(() => void 0);
		if (!state.modelFile) return;
		try {
			await openPet();
		} catch {}
	});
	dola.on("quit", () => {
		closeOrb();
		if (state.windowId) dola.desktop.close(state.windowId);
		state.windowId = null;
	});
}
/**
* Captures the primary display as a PNG data URL.
*
* `desktopCapturer` is a main-process API; the renderer cannot reach the screen without
* a permission prompt, so the screenshot for 识屏 is taken here.
*/
async function captureScreen() {
	try {
		const { desktopCapturer, screen } = await import("electron");
		const display = screen.getPrimaryDisplay();
		const { width, height } = display.size;
		const scale = display.scaleFactor || 1;
		const source = (await desktopCapturer.getSources({
			types: ["screen"],
			thumbnailSize: {
				width: Math.round(width * scale),
				height: Math.round(height * scale)
			}
		}))[0];
		if (!source) return null;
		return source.thumbnail.toDataURL();
	} catch {
		return null;
	}
}
//#endregion
exports.register = register;
