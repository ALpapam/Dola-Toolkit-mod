Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let node_fs = require("node:fs");
let node_path = require("node:path");
let node_child_process = require("node:child_process");
let node_os = require("node:os");
let node_events = require("node:events");
//#region main/stt.ts
var MODELS = [{
	id: "base-q5",
	file: "ggml-base-q5_1.bin",
	bytes: 59707625,
	label: "base（推荐）",
	desc: "59 MB，中文识别准确，一段话约 1~2 秒"
}, {
	id: "tiny-q5",
	file: "ggml-tiny-q5_1.bin",
	bytes: 32152673,
	label: "tiny（轻量）",
	desc: "32 MB，更快更省内存，个别字容易听错"
}];
/** 国内可直连的 HF 镜像；官方域名放最后，作为镜像失效时的兜底。 */
var MODEL_HOSTS = ["https://hf-mirror.com/ggerganov/whisper.cpp/resolve/main/", "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"];
var SttEngine = class {
	paths;
	log;
	onProgress;
	downloading = null;
	cancelled = false;
	constructor(paths, log, onProgress) {
		this.paths = paths;
		this.log = log;
		this.onProgress = onProgress;
	}
	/** `stt/` inside the installed plugin: whisper-cli.exe + its DLLs. */
	binDir() {
		return (0, node_path.join)(this.paths.installDir, "stt");
	}
	exe() {
		return (0, node_path.join)(this.binDir(), "whisper-cli.exe");
	}
	/** Where the downloaded model lives. `models/` under the plugin's private data. */
	modelPath(modelId) {
		const model = MODELS.find((m) => m.id === modelId) ?? MODELS[0];
		return (0, node_path.join)(this.paths.dataDir, "models", model.file);
	}
	/** runtime present and usable? Does not check the model. */
	runtimeReady() {
		return (0, node_fs.existsSync)(this.exe());
	}
	modelReady(modelId) {
		const model = MODELS.find((m) => m.id === modelId) ?? MODELS[0];
		try {
			return (0, node_fs.existsSync)(this.modelPath(model.id)) && (0, node_fs.statSync)(this.modelPath(model.id)).size >= model.bytes * .95;
		} catch {
			return false;
		}
	}
	status(modelId) {
		const model = MODELS.find((m) => m.id === modelId) ?? MODELS[0];
		let bytes = 0;
		try {
			bytes = (0, node_fs.statSync)(this.modelPath(model.id)).size;
		} catch {}
		return {
			runtime: this.runtimeReady(),
			model: this.modelReady(model.id),
			modelId: model.id,
			bytes
		};
	}
	cancelDownload() {
		this.cancelled = true;
	}
	/**
	* Downloads the model once, then reuses it forever.
	*
	* The request goes straight to the mirror: routing 59 MB through the user's proxy is
	* slower than the mirror itself, and the mirror is reachable from the mainland.
	*/
	async ensureModel(modelId) {
		const model = MODELS.find((m) => m.id === modelId) ?? MODELS[0];
		const target = this.modelPath(model.id);
		if (this.modelReady(model.id)) return target;
		if (this.downloading) return this.downloading;
		this.cancelled = false;
		this.downloading = (async () => {
			(0, node_fs.mkdirSync)((0, node_path.join)(this.paths.dataDir, "models"), { recursive: true });
			const part = `${target}.part`;
			let lastError = "";
			for (const host of MODEL_HOSTS) {
				const url = host + model.file;
				try {
					this.log("info", `下载 ${model.file} ← ${host}`);
					await this.fetchTo(url, part, model.bytes);
					const size = (0, node_fs.statSync)(part).size;
					if (size < model.bytes * .95) throw new Error(`下载不完整（${size} 字节）`);
					return await this.finalize(part, target);
				} catch (e) {
					lastError = e instanceof Error ? e.message : String(e);
					this.log("warn", `模型下载失败（${host}）：${lastError}`);
					if (this.cancelled) break;
				}
			}
			this.downloading = null;
			throw new Error(`模型下载失败：${lastError || "所有镜像都不可用"}`);
		})();
		try {
			return await this.downloading;
		} finally {
			this.downloading = null;
		}
	}
	async finalize(part, target) {
		const { renameSync } = await import("node:fs");
		renameSync(part, target);
		this.onProgress({
			ratio: 1,
			received: (0, node_fs.statSync)(target).size,
			total: (0, node_fs.statSync)(target).size
		});
		return target;
	}
	async fetchTo(url, dest, expected) {
		const res = await fetch(url, { redirect: "follow" });
		if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
		const total = Number(res.headers.get("content-length")) || expected;
		let received = 0;
		const out = (0, node_fs.createWriteStream)(dest);
		const reader = res.body.getReader();
		try {
			for (;;) {
				const { done, value } = await reader.read();
				if (done) break;
				if (this.cancelled) throw new Error("已取消");
				received += value.byteLength;
				out.write(value);
				if (received % 262144 < 8192) this.onProgress({
					ratio: total ? received / total : -1,
					received,
					total
				});
			}
		} finally {
			out.end();
			await (0, node_events.once)(out, "finish").catch(() => void 0);
		}
		this.onProgress({
			ratio: 1,
			received,
			total
		});
	}
	/**
	* Transcribes a 16 kHz mono WAV and returns simplified-Chinese text.
	*
	* whisper-cli writes the transcript to `<prefix>.txt`; parsing stdout instead would
	* mean fighting with its banner and timing lines.
	*/
	async transcribe(wavPath, modelId, opts = {}) {
		if (!this.runtimeReady()) throw new Error("插件里缺少语音识别组件（stt/whisper-cli.exe），请重新安装插件");
		const model = this.modelReady(modelId) ? this.modelPath(modelId) : await this.ensureModel(modelId);
		const dataDir = this.paths.dataDir;
		const relModel = (0, node_path.relative)(dataDir, model).replace(/\\/g, "/");
		const relWav = (0, node_path.relative)(dataDir, wavPath).replace(/\\/g, "/");
		if (relModel.startsWith("..") || relWav.startsWith("..")) throw new Error("语音文件不在插件数据目录内，无法识别");
		const relOut = relWav.replace(/\.wav$/i, "");
		const threads = Math.max(2, Math.min(8, Math.floor((0, node_os.cpus)().length / 2)));
		const args = [
			"-m",
			relModel,
			"-f",
			relWav,
			"-l",
			opts.language ?? "zh",
			"-nt",
			"-otxt",
			"-of",
			relOut,
			"-t",
			String(threads)
		];
		this.log("info", `whisper ${relModel} · ${relWav} · ${threads} 线程`);
		const text = await new Promise((resolve, reject) => {
			const child = (0, node_child_process.spawn)(this.exe(), args, {
				cwd: dataDir,
				windowsHide: true,
				stdio: [
					"ignore",
					"pipe",
					"pipe"
				]
			});
			let stderr = "";
			child.stderr?.on("data", (buf) => {
				stderr += buf.toString("utf8");
			});
			const timer = setTimeout(() => {
				child.kill();
				reject(/* @__PURE__ */ new Error("语音识别超时"));
			}, 3e4);
			child.on("error", (e) => {
				clearTimeout(timer);
				reject(/* @__PURE__ */ new Error(`无法启动语音识别：${e.message}`));
			});
			child.on("exit", (code) => {
				clearTimeout(timer);
				if (code !== 0) {
					reject(/* @__PURE__ */ new Error(`语音识别失败（退出码 ${code}）${stderr ? `：${stderr.slice(-200)}` : ""}`));
					return;
				}
				try {
					resolve((0, node_fs.readFileSync)(`${wavPath.replace(/\.wav$/i, "")}.txt`, "utf8"));
				} catch {
					resolve("");
				}
			});
		});
		return this.toSimplified(cleanTranscript(text));
	}
	/**
	* whisper's Chinese output is frequently traditional, so the transcript is folded to
	* simplified before it is shown or sent to the model.
	*
	* The table is OpenCC's `TSCharacters.txt` (4148 single-character mappings, 34 KB),
	* shipped with the plugin and read from disk — no dictionary is embedded in the bundle.
	*/
	toSimplified(text) {
		if (!this.table) try {
			const raw = (0, node_fs.readFileSync)((0, node_path.join)(this.paths.installDir, "stt", "t2s.tsv"), "utf8").replace(/\r/g, "");
			const map = /* @__PURE__ */ new Map();
			for (const line of raw.split("\n")) {
				const i = line.indexOf("	");
				if (i > 0) map.set(line.slice(0, i), line.slice(i + 1));
			}
			this.table = map;
		} catch {
			this.table = /* @__PURE__ */ new Map();
		}
		let out = "";
		for (const ch of text) out += this.table.get(ch) ?? ch;
		return out;
	}
	table = null;
};
/**
* Drops what whisper likes to add around real speech: bracketed sound markers such as
* `[音乐]`、`（笑声）`, leftover timestamps, and stray spaces between CJK characters.
*
* whisper-cli writes one line per segment, joined with CRLF — and its segments break
* mid-sentence, so the carriage returns must go before anything else or the transcript
* ends up with `帮\r我看看现\r在几\r点`. Line breaks are only dropped for CJK text; latin
* output keeps a single space between lines so English words do not run together.
*/
function cleanTranscript(raw) {
	return raw.replace(/\r\n?/g, "\n").replace(/\[[^\]]*\]/g, "").replace(/（[^）]*）/g, "").replace(/\([^)]*\)/g, "").replace(/\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[,.]\d{3}/g, "").split("\n").map((line) => line.trim()).filter(Boolean).join("\n").replace(/(?<=[\u4e00-\u9fff，。！？、；：])\n(?=[\u4e00-\u9fff，。！？、；：])/g, "").replace(/\n+/g, " ").replace(/[ \t]+/g, " ").replace(/\s+([，。！？、；：])/g, "$1").trim();
}
//#endregion
//#region main/tts.ts
var TTS_DEFAULTS = {
	enabled: true,
	endpoint: "http://127.0.0.1:9880/tts",
	refAudio: "",
	promptText: "",
	promptLang: "ja",
	textLang: "zh",
	speed: 1,
	timeoutMs: 12e4
};
/** GPT-SoVITS gets unstable well before this; one paragraph is plenty for a pet. */
var MAX_TEXT = 400;
var TtsEngine = class {
	paths;
	config;
	log;
	constructor(paths, config, log) {
		this.paths = paths;
		this.config = config;
		this.log = log;
	}
	getConfig() {
		return { ...this.config };
	}
	setConfig(patch) {
		this.config = {
			...this.config,
			...patch
		};
		return this.getConfig();
	}
	/**
	* Where the bundled sample lives once it is unpacked.
	*
	* The plugin's install folder is replaced wholesale on upgrade, so the clip is copied
	* into the plugin's data dir on first use and read from there forever after.
	*/
	stableRefPath() {
		return (0, node_path.join)(this.paths.dataDir, "voice", "ref.wav");
	}
	/** Copies the bundled sample into the data dir (idempotent) and returns its path. */
	installBundledReference() {
		const bundled = (0, node_path.join)(this.paths.installDir, "ref-voice.wav");
		const stable = this.stableRefPath();
		try {
			if ((0, node_fs.existsSync)(stable)) return stable;
			if (!(0, node_fs.existsSync)(bundled)) return null;
			(0, node_fs.mkdirSync)((0, node_path.join)(this.paths.dataDir, "voice"), { recursive: true });
			(0, node_fs.cpSync)(bundled, stable);
			return stable;
		} catch {
			return null;
		}
	}
	/**
	* Ensures a reference clip is configured.
	*
	* On first run nothing is set, so the bundled sample is adopted automatically — the
	* user can then replace it with their own voice without touching any file paths.
	*/
	ensureReference() {
		if (this.config.refAudio && (0, node_fs.existsSync)(this.config.refAudio)) return;
		const bundled = this.installBundledReference();
		if (bundled) this.config.refAudio = bundled;
	}
	status() {
		const base = {
			endpoint: this.config.endpoint,
			refAudio: this.config.refAudio
		};
		if (!this.config.enabled) return {
			...base,
			configured: false,
			ready: false,
			reason: "语音合成已关闭"
		};
		if (!this.config.endpoint) return {
			...base,
			configured: false,
			ready: false,
			reason: "没有填服务地址"
		};
		if (!this.config.refAudio) {
			const bundled = this.installBundledReference();
			if (bundled) {
				this.config.refAudio = bundled;
				return {
					...base,
					endpoint: this.config.endpoint,
					refAudio: bundled,
					configured: true,
					ready: true,
					reason: ""
				};
			}
			return {
				...base,
				configured: false,
				ready: false,
				reason: "还没有参考音频"
			};
		}
		if (!(0, node_fs.existsSync)(this.config.refAudio)) {
			const bundled = this.installBundledReference();
			if (bundled) {
				this.config.refAudio = bundled;
				return {
					...base,
					refAudio: bundled,
					configured: true,
					ready: true,
					reason: ""
				};
			}
			return {
				...base,
				configured: true,
				ready: false,
				reason: "参考音频文件不存在"
			};
		}
		return {
			...base,
			configured: true,
			ready: true,
			reason: ""
		};
	}
	/**
	* Trims what should never be read aloud: code blocks, markdown punctuation, and
	* anything past a sentence boundary once the text gets long.
	*/
	clampText(text) {
		const clean = text.replace(/```[\s\S]*?```/g, "").replace(/[*_#`>]/g, "").replace(/\s+/g, " ").trim();
		if (clean.length <= MAX_TEXT) return clean;
		const cut = clean.slice(0, MAX_TEXT);
		const lastStop = Math.max(...[
			"。",
			"！",
			"？",
			"；",
			".",
			"!",
			"?",
			"\n"
		].map((p) => cut.lastIndexOf(p)));
		return lastStop > MAX_TEXT * .5 ? cut.slice(0, lastStop + 1) : cut;
	}
	async speak(rawText) {
		const text = this.clampText(rawText);
		if (!text) return {
			ok: false,
			audio: "",
			text: "",
			error: "没有要朗读的内容"
		};
		this.ensureReference();
		const status = this.status();
		if (!status.ready) return {
			ok: false,
			audio: "",
			text,
			error: status.reason || "语音合成不可用"
		};
		const url = new URL(this.config.endpoint);
		url.searchParams.set("text", text);
		url.searchParams.set("text_lang", this.config.textLang || "zh");
		url.searchParams.set("ref_audio_path", this.config.refAudio);
		url.searchParams.set("prompt_text", this.config.promptText ?? "");
		url.searchParams.set("prompt_lang", this.config.promptLang || "zh");
		url.searchParams.set("media_type", "wav");
		const speed = Number(this.config.speed);
		if (Number.isFinite(speed) && speed > .5 && speed < 2.5) url.searchParams.set("speed_factor", String(speed));
		const controller = new AbortController();
		const timer = setTimeout(() => controller.abort(), Math.max(1e4, this.config.timeoutMs || 12e4));
		try {
			const res = await fetch(url, { signal: controller.signal });
			if (!res.ok) {
				let detail = `HTTP ${res.status}`;
				try {
					const payload = await res.json();
					detail = [payload.message, payload.Exception].filter(Boolean).join("：") || detail;
				} catch {}
				return {
					ok: false,
					audio: "",
					text,
					error: `合成失败：${detail}`
				};
			}
			const bytes = Buffer.from(await res.arrayBuffer());
			if (bytes.length < 200) return {
				ok: false,
				audio: "",
				text,
				error: "合成返回的音频是空的"
			};
			const mime = res.headers.get("content-type")?.split(";")[0] || "audio/wav";
			this.log("info", `tts ${text.length} 字 → ${(bytes.length / 1024).toFixed(0)} KB`);
			return {
				ok: true,
				audio: `data:${mime};base64,${bytes.toString("base64")}`,
				text,
				error: null
			};
		} catch (e) {
			return {
				ok: false,
				audio: "",
				text,
				error: e instanceof Error && e.name === "AbortError" ? "合成超时（服务没有响应）" : `连不上语音服务：${e instanceof Error ? e.message : String(e)}`
			};
		} finally {
			clearTimeout(timer);
		}
	}
	/** Reads a local audio file as a data URL, for previewing the reference clip. */
	previewRefAudio() {
		try {
			const p = this.config.refAudio;
			if (!p || !(0, node_fs.existsSync)(p)) return null;
			if ((0, node_fs.statSync)(p).size > 20971520) return null;
			return `data:audio/wav;base64,${(0, node_fs.readFileSync)(p).toString("base64")}`;
		} catch {
			return null;
		}
	}
	/**
	* Writes the last generated clip to disk.
	*
	* Handy for the settings page's "上次合成的音频" replay, and as the only way to check
	* what went out when a user reports "it sounds wrong".
	*/
	cacheLast(audioDataUrl) {
		try {
			const dir = (0, node_path.join)(this.paths.dataDir, "voice");
			(0, node_fs.mkdirSync)(dir, { recursive: true });
			const b64 = audioDataUrl.slice(audioDataUrl.indexOf(",") + 1);
			(0, node_fs.writeFileSync)((0, node_path.join)(dir, "last.wav"), Buffer.from(b64, "base64"));
		} catch {}
	}
};
//#endregion
//#region main/memory.ts
/** Keep this many turns around; roughly a few minutes of conversation. */
var MAX_TURNS = 40;
/** …and never more characters than this, so one huge pasted block cannot blow it up. */
var MAX_CHARS = 6e3;
var Memory = class {
	dataDir;
	chat;
	turns = [];
	constructor(dataDir, chat) {
		this.dataDir = dataDir;
		this.chat = chat;
	}
	file() {
		return (0, node_path.join)(this.dataDir, "chat.json");
	}
	load() {
		try {
			if (!(0, node_fs.existsSync)(this.dataDir)) (0, node_fs.mkdirSync)(this.dataDir, { recursive: true });
			if (!(0, node_fs.existsSync)(this.file())) return;
			const raw = JSON.parse((0, node_fs.readFileSync)(this.file(), "utf8"));
			if (Array.isArray(raw.turns)) this.turns = raw.turns.filter(isTurn).slice(-40);
		} catch {
			this.turns = [];
		}
	}
	save() {
		try {
			(0, node_fs.mkdirSync)(this.dataDir, { recursive: true });
			(0, node_fs.writeFileSync)(this.file(), JSON.stringify({ turns: this.turns }, null, 2), "utf8");
		} catch {}
	}
	all() {
		return [...this.turns];
	}
	push(turn) {
		this.turns.push({
			...turn,
			at: Date.now()
		});
		let total = this.turns.reduce((n, t) => n + t.text.length, 0);
		while (this.turns.length > MAX_TURNS || total > MAX_CHARS) {
			if (!this.turns.length) break;
			const removed = this.turns.shift();
			total -= removed ? removed.text.length : 0;
		}
		this.save();
	}
	clear() {
		this.turns = [];
		this.save();
	}
	/**
	* The recent past as chat messages.
	*
	* Only the last few turns go to the model: older context makes replies drift and
	* costs tokens on every request. The pet is a desktop companion, not a chatbot that
	* needs the whole transcript.
	*/
	contextMessages(limit = 8) {
		return this.turns.slice(-limit).map((t) => ({
			role: t.role === "pet" ? "assistant" : "user",
			content: t.text
		}));
	}
	/**
	* One-line recap of what happened before, used as a system hint.
	*
	* Kept deliberately terse: it costs a token budget on every request, and a paragraph
	* of recap tends to be recited back verbatim instead of answered.
	*/
	recap() {
		if (this.turns.length === 0) return "";
		const lastUser = [...this.turns].reverse().find((t) => t.role === "user");
		if (!lastUser) return "";
		return `上一轮用户说的是：「${lastUser.text.slice(0, 60)}」`;
	}
};
function isTurn(v) {
	if (!v || typeof v !== "object") return false;
	const r = v;
	return typeof r["text"] === "string" && (r["role"] === "user" || r["role"] === "pet");
}
//#endregion
//#region main/index.ts
var DEFAULTS = {
	hitBox: null,
	modelDir: "",
	modelFile: "",
	windowId: null,
	shown: true,
	scale: 1,
	alwaysOnTop: true,
	sttModel: "base-q5",
	speakReply: true,
	rememberChat: true,
	tts: { ...TTS_DEFAULTS }
};
/**
* The pet's voice, sent on every request.
*
* Kept short and concrete: a long persona prompt tends to be performed rather than
* followed, and every turn pays for it.
*/
var PET_SYSTEM_PROMPT = [
	"你是用户电脑上的桌面伙伴，正在陪着他。",
	"用口语化的中文回答，一到三句话，不要列表、标题、Markdown。",
	"不要说「作为 AI」这类话；不知道的事直接说不知道。",
	"如果用户提到上一轮聊过的事，可以自然地接上，但不要重复复述。"
].join("");
/** Live2D models only reference a handful of file types; everything else is dead weight. */
var KEEP = /* @__PURE__ */ new Set([
	".json",
	".moc3",
	".png",
	".jpg",
	".jpeg",
	".webp",
	".wav",
	".mp3",
	".motion3.json"
]);
function register(dola) {
	const stateFile = (0, node_path.join)(dola.dataDir, "pet.json");
	const modelsRoot = (0, node_path.join)(dola.dataDir, "models");
	(0, node_fs.mkdirSync)(modelsRoot, { recursive: true });
	const audioDir = (0, node_path.join)(dola.dataDir, "audio");
	(0, node_fs.mkdirSync)(audioDir, { recursive: true });
	let state = { ...DEFAULTS };
	try {
		if ((0, node_fs.existsSync)(stateFile)) {
			const parsed = JSON.parse((0, node_fs.readFileSync)(stateFile, "utf8"));
			state = {
				...DEFAULTS,
				...parsed,
				tts: {
					...TTS_DEFAULTS,
					...parsed.tts ?? {}
				}
			};
		}
	} catch {}
	const save = () => {
		try {
			(0, node_fs.mkdirSync)(dola.dataDir, { recursive: true });
			(0, node_fs.writeFileSync)(stateFile, JSON.stringify({
				...state,
				windowId: null,
				hitBox: null
			}, null, 2));
		} catch {}
	};
	const tts = new TtsEngine({
		installDir: dola.installDir,
		dataDir: dola.dataDir
	}, state.tts, (level, msg) => dola.log(level, msg));
	tts.ensureReference();
	state.tts = tts.getConfig();
	/** Chat history lives with the plugin; the host has no business reading it. */
	const memory = new Memory(dola.dataDir, (messages) => dola.ai.chat(messages).then((r) => ({
		ok: r.ok,
		content: r.content,
		error: r.error
	})));
	memory.load();
	const stt = new SttEngine({
		installDir: dola.installDir,
		dataDir: dola.dataDir
	}, (level, msg) => dola.log(level, msg), (p) => dola.ipc.broadcast("stt-progress", p));
	/** Copies a model folder into the plugin's data dir, keeping only referenced files. */
	const importModel = async (sourceDir) => {
		const findModel = (dir, depth = 0) => {
			let entries = [];
			try {
				entries = (0, node_fs.readdirSync)(dir);
			} catch {
				return null;
			}
			const direct = entries.find((n) => n.toLowerCase().endsWith(".model3.json"));
			if (direct) return (0, node_path.join)(dir, direct);
			if (depth >= 2) return null;
			for (const name of entries) {
				const full = (0, node_path.join)(dir, name);
				try {
					if ((0, node_fs.readdirSync)(full).length) {
						const nested = findModel(full, depth + 1);
						if (nested) return nested;
					}
				} catch {}
			}
			return null;
		};
		const modelJson = findModel(sourceDir);
		if (!modelJson) throw new Error("这个文件夹里没有 .model3.json，可能不是 Live2D 模型");
		const root = (0, node_path.dirname)(modelJson);
		JSON.parse((0, node_fs.readFileSync)(modelJson, "utf8")).FileReferences;
		const name = (0, node_path.basename)(root);
		const target = (0, node_path.join)(modelsRoot, name);
		(0, node_fs.rmSync)(target, {
			recursive: true,
			force: true
		});
		(0, node_fs.mkdirSync)(target, { recursive: true });
		const copy = (from, to) => {
			for (const entry of (0, node_fs.readdirSync)(from, { withFileTypes: true })) {
				const src = (0, node_path.join)(from, entry.name);
				const dst = (0, node_path.join)(to, entry.name);
				if (entry.isDirectory()) {
					(0, node_fs.mkdirSync)(dst, { recursive: true });
					copy(src, dst);
				} else {
					const lower = entry.name.toLowerCase();
					if (lower.endsWith(".json") || KEEP.has((0, node_path.extname)(lower)) || lower.includes(".motion3.json")) (0, node_fs.cpSync)(src, dst);
				}
			}
		};
		copy(root, target);
		return {
			name,
			entry: (0, node_path.relative)(target, (0, node_path.join)(target, (0, node_path.relative)(root, modelJson))).replace(/\\/g, "/")
		};
	};
	let orbWindow = null;
	let orbExpanded = false;
	const openOrb = async () => {
		if (orbWindow) return orbWindow;
		orbWindow = await dola.desktop.open({
			modId: "livepet",
			page: "orb.html",
			width: 240,
			height: 60,
			ignoreMouse: false,
			alwaysOnTop: true
		});
		dola.desktop.setBounds(orbWindow, {
			width: 240,
			height: 60
		});
		return orbWindow;
	};
	const closeOrb = () => {
		if (orbWindow) {
			dola.desktop.close(orbWindow);
			orbWindow = null;
		}
	};
	const openPet = async () => {
		if (!state.modelFile) return {
			ok: false,
			error: "请先在设置里上传 Live2D 模型"
		};
		if (state.windowId) return {
			ok: true,
			windowId: state.windowId
		};
		const modelPath = `@data/models/${state.modelDir}/${state.modelFile}`.replace(/\/+/g, "/");
		const id = await dola.desktop.open({
			modId: "livepet",
			page: "pet.html",
			width: 380,
			height: 520,
			ignoreMouse: true,
			alwaysOnTop: state.alwaysOnTop,
			query: {
				model: modelPath,
				scale: String(state.scale)
			}
		});
		state.windowId = id;
		state.shown = true;
		save();
		await openOrb().catch(() => void 0);
		dola.ipc.broadcast("state-changed", { showing: true });
		return {
			ok: true,
			windowId: id
		};
	};
	/**
	* Hides the pet AND its orb.
	*
	* The orb exists only to operate the pet; leaving it floating over the desktop with
	* nothing to control is just clutter.
	*/
	const closePet = () => {
		if (state.windowId) {
			dola.desktop.close(state.windowId);
			state.windowId = null;
		}
		state.shown = false;
		save();
		closeOrb();
		dola.ipc.broadcast("state-changed", { showing: false });
		return { ok: true };
	};
	dola.ipc.handle("state", () => ({
		modelDir: state.modelDir,
		modelFile: state.modelFile,
		showing: Boolean(state.windowId),
		scale: state.scale,
		alwaysOnTop: state.alwaysOnTop,
		sttModel: state.sttModel,
		speakReply: state.speakReply,
		rememberChat: state.rememberChat,
		tts: tts.getConfig()
	}));
	dola.ipc.handle("pick-model", async () => {
		try {
			const picked = await dola.dialog.pickDirectory("选择 Live2D 模型文件夹（含 .model3.json）");
			if (!picked) return {
				ok: false,
				canceled: true
			};
			const { name, entry } = await importModel(picked);
			state.modelDir = name;
			state.modelFile = entry;
			state.windowId = null;
			save();
			dola.ipc.broadcast("state-changed", {
				modelDir: name,
				modelFile: entry,
				showing: false
			});
			return {
				ok: true,
				name,
				entry
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "导入失败"
			};
		}
	});
	/** Import from an explicit path (also used by tests, since dialogs need a human). */
	dola.ipc.handle("import-model", async (dir) => {
		if (typeof dir !== "string" || !dir) return {
			ok: false,
			error: "缺少路径"
		};
		try {
			const { name, entry } = await importModel(dir);
			state.modelDir = name;
			state.modelFile = entry;
			state.windowId = null;
			save();
			dola.ipc.broadcast("state-changed", {
				modelDir: name,
				modelFile: entry,
				showing: false
			});
			return {
				ok: true,
				name,
				entry
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "导入失败"
			};
		}
	});
	dola.ipc.handle("show", () => openPet());
	dola.ipc.handle("hide", () => closePet());
	dola.ipc.handle("set-scale", (_scale) => {
		const s = Number(_scale);
		if (Number.isFinite(s) && s > .2 && s < 3) state.scale = s;
		save();
		if (state.windowId) {
			dola.desktop.close(state.windowId);
			state.windowId = null;
			openPet();
		}
		return {
			ok: true,
			scale: state.scale
		};
	});
	dola.ipc.handle("set-on-top", (on) => {
		state.alwaysOnTop = Boolean(on);
		if (state.windowId) dola.desktop.setAlwaysOnTop(state.windowId, state.alwaysOnTop);
		save();
		return {
			ok: true,
			alwaysOnTop: state.alwaysOnTop
		};
	});
	/**
	* The page reports the character's box so the host can decide where clicks land.
	*
	* The window is created with passthrough on; the page then toggles it off whenever the
	* pointer is over the character and back on when it leaves. That needs the pointer
	* position, which only the page has (Electron's `forward: true` keeps mousemove flowing
	* while ignoring clicks), so the page drives it and the main side just stores the box.
	*/
	dola.ipc.handle("hit-box", (box) => {
		if (!state.windowId || !box || typeof box !== "object") return { ok: false };
		state.hitBox = box;
		return { ok: true };
	});
	/** Called by the page as the pointer enters / leaves the character. */
	dola.ipc.handle("set-passthrough", (ignore) => {
		if (!state.windowId) return { ok: false };
		dola.desktop.setIgnoreMouse(state.windowId, Boolean(ignore));
		return { ok: true };
	});
	dola.ipc.handle("list-windows", () => dola.desktop.list());
	dola.ipc.handle("orb-show", async () => {
		if (orbWindow) return { ok: true };
		await openOrb();
		return { ok: true };
	});
	dola.ipc.handle("orb-hide", () => {
		closeOrb();
		return { ok: true };
	});
	dola.ipc.handle("orb-state", () => ({
		expanded: orbExpanded,
		showing: Boolean(orbWindow)
	}));
	dola.ipc.handle("orb-expanded", (on) => {
		orbExpanded = Boolean(on);
		save();
		return { ok: true };
	});
	dola.ipc.handle("orb-window", () => dola.desktop.list().filter((w) => w.id === orbWindow).map((w) => ({
		id: w.id,
		bounds: w.bounds
	})));
	dola.ipc.handle("orb-move", (pos) => {
		if (!orbWindow || !pos || typeof pos !== "object") return { ok: false };
		const p = pos;
		dola.desktop.setBounds(orbWindow, {
			x: p.x,
			y: p.y
		});
		return { ok: true };
	});
	/**
	* Grows / shrinks the orb window.
	*
	* The ball and the result panel share one window, so the page asks for a taller window
	* when a result arrives and shrinks back when it is dismissed. The width stays fixed at
	* the row width — resizing it would re-centre the disc and make it jump.
	*/
	dola.ipc.handle("orb-resize", (spec) => {
		if (!orbWindow || !spec || typeof spec !== "object") return { ok: false };
		const s = spec;
		const height = Math.max(60, Math.min(720, Math.round(Number(s.height) || 60)));
		dola.desktop.setBounds(orbWindow, {
			...typeof s.x === "number" ? { x: Math.round(s.x) } : {},
			...typeof s.y === "number" ? { y: Math.round(s.y) } : {},
			width: 240,
			height
		});
		return { ok: true };
	});
	dola.ipc.handle("orb-open-settings", () => {
		const win = dola.windows.main();
		if (win) {
			win.show();
			win.focus();
		}
		return { ok: true };
	});
	/** The four orb buttons. Vision / STT / chat all route through the app's AI settings. */
	dola.ipc.handle("orb-action", async (action) => {
		const kind = String(action);
		try {
			if (kind === "vision") {
				const shot = await captureScreen();
				if (!shot) return {
					ok: false,
					error: "无法截屏"
				};
				const res = await dola.ai.chat([{
					role: "system",
					content: "你是一个桌面助手，请用简短中文描述这张屏幕截图的内容与当前用户在做什么。"
				}, {
					role: "user",
					content: [{
						type: "text",
						text: "请描述这张截图。"
					}, {
						type: "image_url",
						image_url: { url: shot }
					}]
				}]);
				return res.ok ? {
					ok: true,
					text: res.content
				} : {
					ok: false,
					error: res.error
				};
			}
			if (kind === "chat") {
				const res = await dola.ai.chat([{
					role: "user",
					content: "你好，用一句话介绍你自己。"
				}]);
				return res.ok ? {
					ok: true,
					text: res.content
				} : {
					ok: false,
					error: res.error
				};
			}
			return {
				ok: false,
				error: `未知操作：${kind}`
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "操作失败"
			};
		}
	});
	/**
	* The orb records from the microphone itself (only a renderer has `getUserMedia`), then
	* posts the captured audio here as a base64 WAV. The main process writes it to disk and
	* runs whisper-cli, so the recognition happens locally and the audio never leaves the
	* machine.
	*/
	dola.ipc.handle("stt-status", () => stt.status(state.sttModel));
	dola.ipc.handle("stt-set-model", (id) => {
		const model = MODELS.find((m) => m.id === String(id));
		if (!model) return {
			ok: false,
			error: "未知模型"
		};
		state.sttModel = model.id;
		save();
		return {
			ok: true,
			modelId: model.id
		};
	});
	dola.ipc.handle("stt-download", async (id) => {
		const modelId = MODELS.some((m) => m.id === String(id)) ? String(id) : state.sttModel;
		try {
			await stt.ensureModel(modelId);
			return {
				ok: true,
				modelId
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "下载失败"
			};
		}
	});
	dola.ipc.handle("stt-cancel-download", () => {
		stt.cancelDownload();
		return { ok: true };
	});
	/**
	* Writes the posted audio and runs whisper over it.
	*
	* Shared by 转写 (stt-transcribe) and 语音问答 (stt-ask) so both go through exactly the
	* same path — including the model auto-download on first use.
	*/
	const transcribePosted = async (payload, opts) => {
		const data = String(payload ?? "");
		if (!data) return {
			ok: false,
			error: "没有收到音频"
		};
		const language = typeof opts === "object" && opts ? opts.language : void 0;
		const wavPath = (0, node_path.join)(audioDir, "last.wav");
		try {
			(0, node_fs.writeFileSync)(wavPath, Buffer.from(data, "base64"));
		} catch (e) {
			return {
				ok: false,
				error: `写入音频失败：${e instanceof Error ? e.message : "未知错误"}`
			};
		}
		try {
			return {
				ok: true,
				text: await stt.transcribe(wavPath, state.sttModel, { language })
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "识别失败"
			};
		}
	};
	dola.ipc.handle("stt-transcribe", async (payload, opts) => {
		const res = await transcribePosted(payload, opts);
		return res.ok ? {
			ok: true,
			text: res.text,
			modelId: state.sttModel
		} : res;
	});
	/**
	* 听音 = 说话 → 本地转写 → 带着最近几轮对话去问 AI → 念出回答。
	*
	* The history is what makes this feel like a companion rather than a command line:
	* "那明天呢？" only makes sense if the previous turn is still in context.
	*/
	dola.ipc.handle("stt-ask", async (payload, opts) => {
		const res = await transcribePosted(payload, opts);
		if (!res.ok) return {
			ok: false,
			error: res.error
		};
		const heard = res.text;
		if (!heard) return {
			ok: true,
			heard: "",
			reply: "",
			text: "",
			error: "没听清，再说一遍？"
		};
		if (!dola.ai.status().configured) return {
			ok: true,
			heard,
			reply: "",
			text: "",
			error: "软件设置里还没有配置 AI，只能先给你转写结果"
		};
		const history = state.rememberChat ? memory.contextMessages() : [];
		const chat = await dola.ai.chat([
			{
				role: "system",
				content: PET_SYSTEM_PROMPT
			},
			...history,
			{
				role: "user",
				content: heard
			}
		]);
		if (!chat.ok) return {
			ok: true,
			heard,
			reply: "",
			text: "",
			error: chat.error ?? "AI 没有返回内容"
		};
		if (state.rememberChat) {
			memory.push({
				role: "user",
				text: heard,
				source: "voice"
			});
			memory.push({
				role: "pet",
				text: chat.content,
				source: "voice"
			});
		}
		if (state.speakReply && tts.status().ready) tts.speak(chat.content).then((voice) => {
			if (voice.ok) {
				tts.cacheLast(voice.audio);
				dola.ipc.broadcast("voice", {
					audio: voice.audio,
					text: voice.text
				});
			} else dola.ipc.broadcast("voice-error", { error: voice.error });
		}).catch(() => void 0);
		return {
			ok: true,
			heard,
			reply: chat.content,
			text: chat.content
		};
	});
	/** 聊天按钮：带上下文的闲聊，不需要麦克风。 */
	dola.ipc.handle("chat-ask", async (text) => {
		const said = String(text ?? "").trim();
		if (!said) return {
			ok: false,
			error: "没有要发送的内容"
		};
		if (!dola.ai.status().configured) return {
			ok: false,
			error: "软件设置里还没有配置 AI"
		};
		const history = state.rememberChat ? memory.contextMessages() : [];
		const chat = await dola.ai.chat([
			{
				role: "system",
				content: PET_SYSTEM_PROMPT
			},
			...history,
			{
				role: "user",
				content: said
			}
		]);
		if (!chat.ok) return {
			ok: false,
			error: chat.error ?? "AI 没有返回内容"
		};
		if (state.rememberChat) {
			memory.push({
				role: "user",
				text: said,
				source: "chat"
			});
			memory.push({
				role: "pet",
				text: chat.content,
				source: "chat"
			});
		}
		if (state.speakReply && tts.status().ready) tts.speak(chat.content).then((voice) => {
			if (voice.ok) dola.ipc.broadcast("voice", {
				audio: voice.audio,
				text: voice.text
			});
		});
		return {
			ok: true,
			reply: chat.content,
			text: chat.content
		};
	});
	dola.ipc.handle("memory-get", () => ({
		enabled: state.rememberChat,
		turns: memory.all().map((t) => ({
			role: t.role,
			text: t.text,
			at: t.at
		}))
	}));
	dola.ipc.handle("memory-clear", () => {
		memory.clear();
		return { ok: true };
	});
	dola.ipc.handle("set-remember-chat", (on) => {
		state.rememberChat = Boolean(on);
		save();
		if (!state.rememberChat) memory.clear();
		return {
			ok: true,
			rememberChat: state.rememberChat
		};
	});
	dola.ipc.handle("tts-status", () => tts.status());
	dola.ipc.handle("tts-config", () => tts.getConfig());
	dola.ipc.handle("tts-set-config", (patch) => {
		if (!patch || typeof patch !== "object") return {
			ok: false,
			error: "缺少配置"
		};
		const p = patch;
		const next = {};
		if (typeof p.enabled === "boolean") next.enabled = p.enabled;
		if (typeof p.endpoint === "string") next.endpoint = p.endpoint.trim();
		if (typeof p.refAudio === "string") next.refAudio = p.refAudio.trim();
		if (typeof p.promptText === "string") next.promptText = p.promptText;
		if (typeof p.promptLang === "string") next.promptLang = p.promptLang;
		if (typeof p.textLang === "string") next.textLang = p.textLang;
		if (typeof p.speed === "number" && p.speed > .5 && p.speed < 2.5) next.speed = p.speed;
		state.tts = tts.setConfig(next);
		save();
		return {
			ok: true,
			config: state.tts,
			status: tts.status()
		};
	});
	/** Picks a reference clip through the host's file dialog. */
	dola.ipc.handle("tts-pick-ref", async () => {
		try {
			const picked = await dola.dialog.pickFile("选择参考音频（3~10 秒，无背景音乐）", [{
				name: "音频",
				extensions: [
					"wav",
					"flac",
					"ogg",
					"mp3"
				]
			}]);
			if (!picked) return {
				ok: false,
				canceled: true
			};
			state.tts = tts.setConfig({ refAudio: picked });
			save();
			return {
				ok: true,
				path: picked,
				preview: tts.previewRefAudio()
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "选择失败"
			};
		}
	});
	/** Restores the clip that ships with the plugin (or copies it if missing). */
	dola.ipc.handle("tts-reset-ref", () => {
		const path = tts.installBundledReference();
		if (!path) return {
			ok: false,
			error: "插件里没有自带参考音频"
		};
		state.tts = tts.setConfig({ refAudio: path });
		save();
		return {
			ok: true,
			path,
			preview: tts.previewRefAudio()
		};
	});
	dola.ipc.handle("tts-preview-ref", () => ({ audio: tts.previewRefAudio() }));
	/** Speaks a fixed line so the user can hear the configured voice. */
	dola.ipc.handle("tts-test", async () => {
		return {
			...await tts.speak("你好，我是你的桌面伙伴。"),
			status: tts.status()
		};
	});
	/** Speaks arbitrary text (the 朗读 button and 识屏 results use this). */
	dola.ipc.handle("tts-speak", async (text) => {
		const res = await tts.speak(String(text ?? ""));
		if (res.ok) tts.cacheLast(res.audio);
		return res;
	});
	dola.ipc.handle("set-speak-reply", (on) => {
		state.speakReply = Boolean(on);
		save();
		return {
			ok: true,
			speakReply: state.speakReply
		};
	});
	dola.on("boot", async () => {
		if (!state.modelFile) return;
		if (!state.shown) return;
		try {
			await openPet();
		} catch {}
	});
	dola.on("quit", () => {
		closeOrb();
		if (state.windowId) dola.desktop.close(state.windowId);
		state.windowId = null;
	});
}
/**
* Captures the primary display as a PNG data URL.
*
* `desktopCapturer` is a main-process API; the renderer cannot reach the screen without
* a permission prompt, so the screenshot for 识屏 is taken here.
*/
async function captureScreen() {
	try {
		const { desktopCapturer, screen } = await import("electron");
		const display = screen.getPrimaryDisplay();
		const { width, height } = display.size;
		const scale = display.scaleFactor || 1;
		const source = (await desktopCapturer.getSources({
			types: ["screen"],
			thumbnailSize: {
				width: Math.round(width * scale),
				height: Math.round(height * scale)
			}
		}))[0];
		if (!source) return null;
		return source.thumbnail.toDataURL();
	} catch {
		return null;
	}
}
//#endregion
exports.register = register;
