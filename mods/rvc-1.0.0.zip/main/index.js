Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let node_child_process = require("node:child_process");
let node_fs = require("node:fs");
let node_path = require("node:path");
//#region mods/rvc/main/index.ts
var DEFAULTS = {
	root: "",
	pitch: 0,
	f0Method: "rmvpe",
	indexRate: .75,
	protect: .33,
	rmsMixRate: 1,
	openOnFinish: true
};
var SEP_MODELS = [
	{
		id: "bs-karaoke",
		name: "bs_roformer_karaoke_anvuew.ckpt",
		label: "BS-RoFormer Karaoke",
		group: "卡拉OK",
		note: "分离主唱与被伴奏盖住的和声，200 MB",
		sizeMB: 205,
		stems: ["vocals", "instrumental"]
	},
	{
		id: "mel-karaoke",
		name: "mel_band_roformer_karaoke_gabox.ckpt",
		label: "Mel-Band RoFormer Karaoke",
		group: "卡拉OK",
		note: "同为卡拉 OK 用途，质量更高但更慢，913 MB",
		sizeMB: 913,
		stems: ["vocals", "instrumental"]
	},
	{
		id: "bs-vocal",
		name: "mel_band_roformer_karaoke_gabox_v2.ckpt",
		label: "Mel-Band RoFormer Karaoke v2",
		group: "卡拉OK",
		note: "v2，对人声更宽容，913 MB",
		sizeMB: 913,
		stems: ["vocals", "instrumental"]
	},
	{
		id: "bs-dereverb",
		name: "dereverb_bs_roformer_anvuew_sdr_22.5050.ckpt",
		label: "BS-RoFormer DeReverb",
		group: "去混响",
		note: "去掉房间混响，保留人声，205 MB",
		sizeMB: 205,
		stems: ["vocals"]
	},
	{
		id: "uvr-dereverb",
		name: "UVR-DeEcho-DeReverb.pth",
		label: "UVR DeEcho-DeReverb",
		group: "去混响",
		note: "经典 UVR 去回声/去混响，小且快，224 MB",
		sizeMB: 224,
		stems: ["vocals"]
	}
];
/** RVC 推理必需、且插件会检查的文件的相对路径。 */
var REQUIRED_MODELS = [
	{
		key: "hubert",
		label: "HuBERT 特征提取",
		rel: (0, node_path.join)("assets", "hubert_base", "pytorch_model.bin"),
		mb: 180
	},
	{
		key: "rmvpe",
		label: "RMVPE 音高提取",
		rel: (0, node_path.join)("assets", "rmvpe", "rmvpe.pt"),
		mb: 173
	},
	{
		key: "base40k",
		label: "声码器底模（40k）",
		rel: (0, node_path.join)("assets", "pretrained_v2", "f0G40k.pth"),
		mb: 70
	}
];
function register(dola) {
	const stateFile = (0, node_path.join)(dola.dataDir, "rvc.json");
	const workRoot = (0, node_path.join)(dola.dataDir, "jobs");
	(0, node_fs.mkdirSync)(workRoot, { recursive: true });
	let state = { ...DEFAULTS };
	try {
		if ((0, node_fs.existsSync)(stateFile)) state = {
			...DEFAULTS,
			...JSON.parse((0, node_fs.readFileSync)(stateFile, "utf8"))
		};
	} catch {}
	const save = () => {
		try {
			(0, node_fs.mkdirSync)(dola.dataDir, { recursive: true });
			(0, node_fs.writeFileSync)(stateFile, JSON.stringify(state, null, 2));
		} catch {}
	};
	const pythonExe = () => (0, node_path.join)(state.root, "runtime", "python.exe");
	/**
	* RVC 根目录是否可用。
	*
	* 只检查"能证明这是一个 RVC 整合包"的东西：python 运行时和 infer 包。
	* 缺模型是另一回事（可以下载），所以分开报。
	*/
	const rootStatus = () => {
		if (!state.root) return {
			ok: false,
			reason: "还没有指定 RVC 目录",
			python: false,
			infer: false
		};
		if (!(0, node_fs.existsSync)(state.root)) return {
			ok: false,
			reason: "指定的目录不存在",
			python: false,
			infer: false
		};
		const py = (0, node_fs.existsSync)(pythonExe());
		const infer = (0, node_fs.existsSync)((0, node_path.join)(state.root, "infer", "vc", "modules.py"));
		if (!py) return {
			ok: false,
			reason: "目录里没有 runtime\\python.exe",
			python: false,
			infer
		};
		if (!infer) return {
			ok: false,
			reason: "目录里没有 infer 包，可能不是 RVC 整合包",
			python: py,
			infer: false
		};
		return {
			ok: true,
			reason: "",
			python: py,
			infer
		};
	};
	const missingModels = () => REQUIRED_MODELS.filter((m) => !(0, node_fs.existsSync)((0, node_path.join)(state.root, m.rel)));
	/** 可用的音色模型（assets/weights 下的 .pth）与同名索引。 */
	const listVoices = () => {
		if (!rootStatus().ok) return [];
		const dir = (0, node_path.join)(state.root, "assets", "weights");
		if (!(0, node_fs.existsSync)(dir)) return [];
		const indexDirs = [(0, node_path.join)(state.root, "assets", "indices"), (0, node_path.join)(state.root, "logs")];
		const out = [];
		for (const name of (0, node_fs.readdirSync)(dir)) {
			if (!name.toLowerCase().endsWith(".pth")) continue;
			const full = (0, node_path.join)(dir, name);
			let mb = 0;
			try {
				mb = Math.round((0, node_fs.statSync)(full).size / 1024 / 1024);
			} catch {}
			const stem = name.replace(/\.pth$/i, "");
			let index = "";
			for (const idir of indexDirs) {
				if (!(0, node_fs.existsSync)(idir)) continue;
				const hit = findIndexFile(idir, stem);
				if (hit) {
					index = hit;
					break;
				}
			}
			out.push({
				name: stem,
				path: full,
				index,
				mb
			});
		}
		return out.sort((a, b) => a.name.localeCompare(b.name));
	};
	/**
	* 把一个 job 交给 python 跑。
	*
	* 输出协议：stdout 每行以 `PROGRESS ` 开头是进度，`RESULT ` 开头是最终结果；
	* 其余（第三方库的警告、tqdm）忽略。stderr 保留尾部用于报错。
	*
	* 桥接脚本**不写进 RVC 目录**：那是用户的安装，应用不该往里丢文件（而且从
	* Electron 里写它可能被拒绝）。改为用 `-c` 执行一段引导代码，让它把插件目录里的
	* rvc_bridge.py 当作模块加载，`cwd` 仍是 RVC 根目录，于是项目内的相对导入照样成立。
	*/
	const runBridge = async (job, timeoutMs = 12e5) => {
		const status = rootStatus();
		if (!status.ok) return {
			ok: false,
			data: {},
			error: status.reason,
			stderrTail: ""
		};
		const bridgeDir = (0, node_path.join)(dola.installDir, "bridge");
		if (!(0, node_fs.existsSync)((0, node_path.join)(bridgeDir, "rvc_bridge.py"))) return {
			ok: false,
			data: {},
			error: "插件缺少 bridge/rvc_bridge.py，请重新安装插件",
			stderrTail: ""
		};
		const jobFile = (0, node_path.join)(workRoot, `job-${Date.now()}.json`);
		(0, node_fs.writeFileSync)(jobFile, JSON.stringify(job, null, 2), "utf8");
		const bootstrap = [
			"import sys, importlib.util, os",
			`sys.path.insert(0, ${JSON.stringify(bridgeDir)})`,
			`sys.path.insert(0, ${JSON.stringify(state.root)})`,
			"spec = importlib.util.spec_from_file_location(\"dola_rvc_bridge\", " + JSON.stringify((0, node_path.join)(bridgeDir, "rvc_bridge.py")) + ")",
			"mod = importlib.util.module_from_spec(spec)",
			"sys.modules[\"dola_rvc_bridge\"] = mod",
			"spec.loader.exec_module(mod)",
			`mod.run_job(${JSON.stringify(jobFile)}, ${JSON.stringify(state.root)})`
		].join("\n");
		const sysRoot = process.env["SystemRoot"] || "C:\\Windows";
		const runtimeDir = (0, node_path.join)(state.root, "runtime");
		const fullPath = [
			runtimeDir,
			(0, node_path.join)(runtimeDir, "Lib", "site-packages", "torch", "lib"),
			(0, node_path.join)(sysRoot, "System32"),
			(0, node_path.join)(sysRoot, "System32", "WindowsPowerShell", "v1.0"),
			sysRoot,
			process.env["PATH"] ?? ""
		].filter(Boolean).join(";");
		return new Promise((resolve) => {
			const outFile = (0, node_path.join)(workRoot, `out-${Date.now()}.log`);
			const errFile = (0, node_path.join)(workRoot, `err-${Date.now()}.log`);
			const outFd = (0, node_fs.openSync)(outFile, "w");
			const errFd = (0, node_fs.openSync)(errFile, "w");
			const child = (0, node_child_process.spawn)(pythonExe(), ["-c", bootstrap], {
				cwd: state.root,
				windowsHide: true,
				stdio: [
					"ignore",
					outFd,
					errFd
				],
				detached: true,
				env: (() => {
					const keep = [
						"SystemRoot",
						"SystemDrive",
						"windir",
						"USERPROFILE",
						"HOMEDRIVE",
						"HOMEPATH",
						"APPDATA",
						"LOCALAPPDATA",
						"PROGRAMDATA",
						"PROGRAMFILES",
						"PROGRAMFILES(X86)",
						"COMMONPROGRAMFILES",
						"NUMBER_OF_PROCESSORS",
						"PROCESSOR_ARCHITECTURE",
						"OS",
						"COMPUTERNAME",
						"USERNAME",
						"PATHEXT"
					];
					const env = {};
					for (const k of keep) {
						const v = process.env[k];
						if (v !== void 0) env[k] = v;
					}
					env["PATH"] = fullPath;
					env["PYTHONPATH"] = `${state.root};${bridgeDir}`;
					env["PYTHONIOENCODING"] = "utf-8";
					env["PYTHONUTF8"] = "1";
					env["RVC_CUDA_GRAPH"] = "0";
					env["OPENBLAS_NUM_THREADS"] = "1";
					env["CUDA_MODULE_LOADING"] = "LAZY";
					env["CUDA_DEVICE_MAX_CONNECTIONS"] = "1";
					const cacheDir = (0, node_path.join)(dola.dataDir, "cache");
					try {
						(0, node_fs.mkdirSync)(cacheDir, { recursive: true });
					} catch {}
					env["DOLA_CACHE_DIR"] = cacheDir;
					return env;
				})()
			});
			let settled = false;
			const readTail = (file, max = 800) => {
				try {
					const raw = (0, node_fs.readFileSync)(file, "utf8");
					return raw.length > max ? raw.slice(-max) : raw;
				} catch {
					return "";
				}
			};
			const cleanup = () => {
				try {
					(0, node_fs.closeSync)(outFd);
				} catch {}
				try {
					(0, node_fs.closeSync)(errFd);
				} catch {}
			};
			const done = (result) => {
				if (settled) return;
				settled = true;
				clearTimeout(timer);
				cleanup();
				try {
					(0, node_fs.rmSync)(jobFile, { force: true });
				} catch {}
				resolve(result);
			};
			const timer = setTimeout(() => {
				child.kill();
				done({
					ok: false,
					data: {},
					error: "处理超时（20 分钟）",
					stderrTail: readTail(errFile, 500)
				});
			}, timeoutMs);
			child.on("spawn", () => {
				dola.log("info", `rvc bridge spawned pid=${child.pid} mode=${String(job["mode"])}`);
			});
			child.on("error", (e) => {
				dola.log("error", `rvc bridge spawn failed: ${e.message}`);
				done({
					ok: false,
					data: {},
					error: `无法启动 python：${e.message}`,
					stderrTail: ""
				});
			});
			child.on("exit", (code) => {
				const stdout = readTail(outFile, 2e5);
				const stderr = readTail(errFile, 4e3);
				dola.log("info", `rvc bridge exited code=${code}`);
				const line = stdout.split("\n").reverse().find((l) => l.startsWith("RESULT "));
				if (line) try {
					const data = JSON.parse(line.slice(7));
					done({
						ok: data["ok"] !== false,
						data,
						error: data["error"] ?? null,
						stderrTail: stderr.slice(-500)
					});
					return;
				} catch (e) {
					done({
						ok: false,
						data: {},
						error: `结果解析失败：${e instanceof Error ? e.message : ""}`,
						stderrTail: stderr.slice(-500)
					});
					return;
				}
				try {
					const dumpDir = (0, node_path.join)(dola.dataDir, "logs");
					(0, node_fs.mkdirSync)(dumpDir, { recursive: true });
					(0, node_fs.writeFileSync)((0, node_path.join)(dumpDir, `bridge-${Date.now()}.log`), `code=${code}\n--- stdout ---\n${stdout}\n--- stderr ---\n${stderr}\n`, "utf8");
				} catch {}
				done({
					ok: false,
					data: {},
					error: code === 0 ? "运行结束但没有返回结果" : `python 退出码 ${code}`,
					stderrTail: stderr.slice(-800)
				});
			});
		});
	};
	dola.ipc.handle("state", () => ({
		root: state.root,
		rootOk: rootStatus().ok,
		rootReason: rootStatus().reason,
		pitch: state.pitch,
		f0Method: state.f0Method,
		indexRate: state.indexRate,
		protect: state.protect,
		rmsMixRate: state.rmsMixRate,
		openOnFinish: state.openOnFinish,
		missingModels: missingModels().map((m) => ({
			key: m.key,
			label: m.label,
			mb: m.mb
		})),
		sepModels: SEP_MODELS
	}));
	/** 选 RVC 目录（用宿主的文件夹选择框）。 */
	dola.ipc.handle("set-root", async (dir) => {
		const target = String(dir ?? "").trim();
		if (!target) try {
			const picked = await dola.dialog.pickDirectory("选择 RVC 整合包根目录（含 runtime 与 infer）");
			if (!picked) return {
				ok: false,
				canceled: true
			};
			state.root = picked;
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "选择失败"
			};
		}
		else state.root = target;
		save();
		const st = rootStatus();
		return {
			ok: st.ok,
			root: state.root,
			reason: st.reason
		};
	});
	dola.ipc.handle("set-params", (patch) => {
		if (!patch || typeof patch !== "object") return { ok: false };
		const p = patch;
		if (typeof p.pitch === "number" && p.pitch >= -24 && p.pitch <= 24) state.pitch = Math.round(p.pitch);
		if (typeof p.f0Method === "string" && [
			"rmvpe",
			"pm",
			"harvest",
			"crepe"
		].includes(p.f0Method)) state.f0Method = p.f0Method;
		if (typeof p.indexRate === "number" && p.indexRate >= 0 && p.indexRate <= 1) state.indexRate = p.indexRate;
		if (typeof p.protect === "number" && p.protect >= 0 && p.protect <= .5) state.protect = p.protect;
		if (typeof p.rmsMixRate === "number" && p.rmsMixRate >= 0 && p.rmsMixRate <= 1) state.rmsMixRate = p.rmsMixRate;
		if (typeof p.openOnFinish === "boolean") state.openOnFinish = p.openOnFinish;
		save();
		return {
			ok: true,
			state: {
				pitch: state.pitch,
				f0Method: state.f0Method
			}
		};
	});
	/** 运行时体检：python/torch/cuda + 必需模型。 */
	dola.ipc.handle("probe", async () => {
		const st = rootStatus();
		if (!st.ok) return {
			ok: false,
			error: st.reason
		};
		const res = await runBridge({ mode: "probe" }, 12e4);
		if (!res.ok) return {
			ok: false,
			error: res.error ?? "探测失败",
			stderr: res.stderrTail
		};
		return {
			ok: true,
			info: res.data,
			missing: missingModels().map((m) => m.label)
		};
	});
	/**
	* 分步自检：在"当前这个进程环境"里分别测 torch、ffmpeg 管道、音频加载和整段推理。
	*
	* 存在的理由：同一套命令在命令行里 32 秒跑完、从 Electron 启动却慢几十倍时，
	* 靠日志猜是没用的。这个接口把每一步的毫秒数直接量出来，一眼看出是哪一段。
	*/
	dola.ipc.handle("selftest", async (payload) => {
		const st = rootStatus();
		if (!st.ok) return {
			ok: false,
			error: st.reason
		};
		const p = payload ?? {};
		const input = String(p.inputPath ?? "");
		const voice = String(p.voicePath ?? "");
		if (!input || !(0, node_fs.existsSync)(input)) return {
			ok: false,
			error: "先选择一段输入音频"
		};
		if (!voice || !(0, node_fs.existsSync)(voice)) return {
			ok: false,
			error: "先选择一个音色模型"
		};
		const res = await runBridge({
			mode: "selftest",
			inputPath: input,
			modelPath: voice,
			indexPath: p.indexPath ?? "",
			outputPath: (0, node_path.join)(workRoot, `selftest-${Date.now()}.wav`),
			pitch: state.pitch,
			f0Method: state.f0Method,
			indexRate: state.indexRate,
			rmsMixRate: state.rmsMixRate,
			protect: state.protect
		}, 6e5);
		if (!res.ok) return {
			ok: false,
			error: res.error ?? "自检失败",
			stderr: res.stderrTail
		};
		return {
			ok: true,
			steps: res.data["steps"]
		};
	});
	dola.ipc.handle("voices", () => listVoices());
	/** 选择一个音频文件（输入）。 */
	dola.ipc.handle("pick-audio", async () => {
		try {
			const picked = await dola.dialog.pickFile("选择要转换的音频", [{
				name: "音频",
				extensions: [
					"wav",
					"mp3",
					"flac",
					"m4a",
					"ogg",
					"aac"
				]
			}]);
			if (!picked) return {
				ok: false,
				canceled: true
			};
			return {
				ok: true,
				path: picked,
				name: (0, node_path.basename)(picked)
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "选择失败"
			};
		}
	});
	/** 选择音色模型文件（.pth）。 */
	dola.ipc.handle("pick-voice", async () => {
		try {
			const picked = await dola.dialog.pickFile("选择 RVC 音色模型", [{
				name: "RVC 模型",
				extensions: ["pth"]
			}]);
			if (!picked) return {
				ok: false,
				canceled: true
			};
			return {
				ok: true,
				path: picked,
				name: (0, node_path.basename)(picked)
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "选择失败"
			};
		}
	});
	/**
	* 转换主流程。
	*
	* separation 可选：不分离就直接转；分离则先出人声再转人声，
	* 因为 RVC 对混了伴奏的输入效果明显更差。
	*/
	dola.ipc.handle("convert", async (payload) => {
		const st = rootStatus();
		if (!st.ok) return {
			ok: false,
			error: st.reason
		};
		const missing = missingModels();
		if (missing.length) return {
			ok: false,
			error: `缺少必需模型：${missing.map((m) => m.label).join("、")}`
		};
		if (!payload || typeof payload !== "object") return {
			ok: false,
			error: "参数为空"
		};
		const p = payload;
		const inputPath = String(p.inputPath ?? "");
		const voicePath = String(p.voicePath ?? "");
		if (!inputPath || !(0, node_fs.existsSync)(inputPath)) return {
			ok: false,
			error: "输入音频不存在"
		};
		if (!voicePath || !(0, node_fs.existsSync)(voicePath)) return {
			ok: false,
			error: "音色模型不存在"
		};
		const jobDir = (0, node_path.join)(workRoot, `run-${Date.now()}`);
		(0, node_fs.mkdirSync)(jobDir, { recursive: true });
		const outputs = [];
		const started = Date.now();
		try {
			let working = inputPath;
			let convertedFrom = "原始音频";
			if (p.sepModel) {
				const model = SEP_MODELS.find((m) => m.id === p.sepModel);
				if (!model) return {
					ok: false,
					error: "未知的分离模型"
				};
				dola.ipc.broadcast("stage", {
					stage: "separate",
					label: `正在分离人声：${model.label}`
				});
				const sepOut = (0, node_path.join)(jobDir, "sep");
				(0, node_fs.mkdirSync)(sepOut, { recursive: true });
				const storeDirs = {};
				for (const stem of model.stems) storeDirs[stem] = (0, node_path.join)(sepOut, stem);
				const res = await runBridge({
					mode: "separate",
					model: model.name,
					inputPath,
					outputDir: sepOut,
					modelDir: (0, node_path.join)(state.root, "assets", "uvr5_weights"),
					storeDirs
				});
				if (!res.ok) return {
					ok: false,
					error: res.error ?? "分离失败",
					stderr: res.stderrTail
				};
				const produced = res.data["outputs"] ?? [];
				for (const f of produced) outputs.push({
					label: (0, node_path.basename)(f, (0, node_path.extname)(f)),
					path: f
				});
				const vocal = produced.find((f) => /vocal/i.test((0, node_path.basename)(f))) ?? produced[0];
				if (!vocal || !(0, node_fs.existsSync)(vocal)) return {
					ok: false,
					error: "分离没有产出人声，无法继续"
				};
				working = vocal;
				convertedFrom = (0, node_path.basename)(vocal);
			}
			dola.ipc.broadcast("stage", {
				stage: "convert",
				label: "正在转换音色…"
			});
			const finalPath = (0, node_path.join)(jobDir, `${(0, node_path.basename)(voicePath, (0, node_path.extname)(voicePath))}-${Date.now()}.wav`);
			const res = await runBridge({
				mode: "convert",
				modelPath: voicePath,
				indexPath: p.indexPath ?? "",
				inputPath: working,
				outputPath: finalPath,
				pitch: state.pitch,
				f0Method: state.f0Method,
				indexRate: state.indexRate,
				rmsMixRate: state.rmsMixRate,
				protect: state.protect
			});
			if (!res.ok) return {
				ok: false,
				error: res.error ?? "转换失败",
				stderr: res.stderrTail
			};
			const outPath = String(res.data["outputPath"] ?? finalPath);
			outputs.push({
				label: "转换结果",
				path: outPath
			});
			const seconds = Math.round((Date.now() - started) / 1e3);
			const last = {
				input: (0, node_path.basename)(inputPath),
				outputs,
				at: Date.now(),
				seconds
			};
			(0, node_fs.writeFileSync)((0, node_path.join)(dola.dataDir, "last.json"), JSON.stringify(last, null, 2), "utf8");
			dola.ipc.broadcast("stage", {
				stage: "done",
				label: `完成，用时 ${seconds} 秒`
			});
			if (state.openOnFinish) try {
				const { shell } = await import("electron");
				shell.showItemInFolder(outPath);
			} catch {}
			return {
				ok: true,
				outputs,
				seconds,
				from: convertedFrom
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "处理失败"
			};
		}
	});
	dola.ipc.handle("last", () => {
		try {
			const f = (0, node_path.join)(dola.dataDir, "last.json");
			if (!(0, node_fs.existsSync)(f)) return null;
			return JSON.parse((0, node_fs.readFileSync)(f, "utf8"));
		} catch {
			return null;
		}
	});
	/** 把结果音频读成 data URL，页面直接 <audio> 播放。 */
	dola.ipc.handle("read-audio", (path) => {
		try {
			const p = String(path ?? "");
			if (!p || !(0, node_fs.existsSync)(p)) return {
				ok: false,
				error: "文件不存在"
			};
			if ((0, node_fs.statSync)(p).size > 62914560) return {
				ok: false,
				error: "音频太大，无法预览"
			};
			return {
				ok: true,
				audio: `data:audio/wav;base64,${(0, node_fs.readFileSync)(p).toString("base64")}`
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "读取失败"
			};
		}
	});
	/** 在资源管理器里定位一个输出文件。 */
	dola.ipc.handle("reveal", async (path) => {
		try {
			const { shell } = await import("electron");
			shell.showItemInFolder(String(path ?? ""));
			return { ok: true };
		} catch {
			return { ok: false };
		}
	});
	/**
	* 下载分离模型（走 pymss 自己的下载器，ModelScope 优先）。
	*
	* 这些权重 200 MB ~ 1.7 GB，所以只在用户真正选中时才下，进度用广播回传。
	*/
	dola.ipc.handle("download-sep-model", async (id) => {
		const model = SEP_MODELS.find((m) => m.id === String(id));
		if (!model) return {
			ok: false,
			error: "未知模型"
		};
		const st = rootStatus();
		if (!st.ok) return {
			ok: false,
			error: st.reason
		};
		const script = [
			"import json, sys",
			`sys.path.insert(0, ${JSON.stringify(state.root)})`,
			"from tools.pymss.model_download import download_model",
			`r = download_model(${JSON.stringify(model.name)}, model_dir=${JSON.stringify((0, node_path.join)(state.root, "assets", "uvr5_weights"))}, source='modelscope')`,
			"print(\"OK\")"
		].join("\n");
		const scriptFile = (0, node_path.join)(workRoot, `dl-${Date.now()}.py`);
		(0, node_fs.writeFileSync)(scriptFile, script, "utf8");
		dola.ipc.broadcast("stage", {
			stage: "download",
			label: `正在下载 ${model.label}`
		});
		return new Promise((resolve) => {
			const child = (0, node_child_process.spawn)(pythonExe(), [scriptFile], {
				cwd: state.root,
				windowsHide: true,
				stdio: [
					"ignore",
					"pipe",
					"pipe"
				]
			});
			let err = "";
			child.stderr?.on("data", (b) => {
				err += b.toString("utf8");
				if (err.length > 8e3) err = err.slice(-4e3);
			});
			child.on("exit", (code) => {
				try {
					(0, node_fs.rmSync)(scriptFile, { force: true });
				} catch {}
				if (code === 0) resolve({
					ok: true,
					model: model.id
				});
				else resolve({
					ok: false,
					error: `下载失败（退出码 ${code}）`,
					stderr: err.slice(-600)
				});
			});
			child.on("error", (e) => resolve({
				ok: false,
				error: `无法启动 python：${e.message}`
			}));
		});
	});
	dola.ipc.handle("sep-model-status", () => {
		if (!rootStatus().ok) return [];
		const dir = (0, node_path.join)(state.root, "assets", "uvr5_weights");
		return SEP_MODELS.map((m) => ({
			id: m.id,
			present: (0, node_fs.existsSync)((0, node_path.join)(dir, m.name.replace(/\.(ckpt|pth)$/i, ""), m.name)) || (0, node_fs.existsSync)((0, node_path.join)(dir, modelRelDir(m.name), m.name))
		}));
	});
}
/** catalog 的 relpath 里，模型放在子目录下（karaoke/、legacy_vr/...），这里猜一个。 */
function modelRelDir(name) {
	if (/karaoke/i.test(name)) return "karaoke";
	if (/dereverb/i.test(name)) return "reverb_echo_control/dereverb";
	return "";
}
/** 在索引目录里找与模型同名的 .index（RVC 的命名习惯是 <模型名>_added_*.index）。 */
function findIndexFile(dir, stem) {
	try {
		for (const entry of (0, node_fs.readdirSync)(dir, { withFileTypes: true })) {
			if (entry.isDirectory()) {
				const nested = findIndexFile((0, node_path.join)(dir, entry.name), stem);
				if (nested) return nested;
				continue;
			}
			if (!entry.name.toLowerCase().endsWith(".index")) continue;
			if (entry.name.startsWith(stem)) return (0, node_path.join)(dir, entry.name);
		}
	} catch {}
	return "";
}
//#endregion
exports.register = register;
