Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let node_fs = require("node:fs");
let node_path = require("node:path");
//#region mods/livepet/main/index.ts
var DEFAULTS = {
	hitBox: null,
	modelDir: "",
	modelFile: "",
	windowId: null,
	scale: 1,
	alwaysOnTop: true
};
/** Live2D models only reference a handful of file types; everything else is dead weight. */
var KEEP = /* @__PURE__ */ new Set([
	".json",
	".moc3",
	".png",
	".jpg",
	".jpeg",
	".webp",
	".wav",
	".mp3",
	".motion3.json"
]);
function register(dola) {
	const stateFile = (0, node_path.join)(dola.dataDir, "pet.json");
	const modelsRoot = (0, node_path.join)(dola.dataDir, "models");
	(0, node_fs.mkdirSync)(modelsRoot, { recursive: true });
	let state = { ...DEFAULTS };
	try {
		if ((0, node_fs.existsSync)(stateFile)) state = {
			...DEFAULTS,
			...JSON.parse((0, node_fs.readFileSync)(stateFile, "utf8"))
		};
	} catch {}
	const save = () => {
		try {
			(0, node_fs.mkdirSync)(dola.dataDir, { recursive: true });
			(0, node_fs.writeFileSync)(stateFile, JSON.stringify({
				...state,
				windowId: null,
				hitBox: null
			}, null, 2));
		} catch {}
	};
	/** Copies a model folder into the plugin's data dir, keeping only referenced files. */
	const importModel = async (sourceDir) => {
		const findModel = (dir, depth = 0) => {
			let entries = [];
			try {
				entries = (0, node_fs.readdirSync)(dir);
			} catch {
				return null;
			}
			const direct = entries.find((n) => n.toLowerCase().endsWith(".model3.json"));
			if (direct) return (0, node_path.join)(dir, direct);
			if (depth >= 2) return null;
			for (const name of entries) {
				const full = (0, node_path.join)(dir, name);
				try {
					if ((0, node_fs.readdirSync)(full).length) {
						const nested = findModel(full, depth + 1);
						if (nested) return nested;
					}
				} catch {}
			}
			return null;
		};
		const modelJson = findModel(sourceDir);
		if (!modelJson) throw new Error("这个文件夹里没有 .model3.json，可能不是 Live2D 模型");
		const root = (0, node_path.dirname)(modelJson);
		JSON.parse((0, node_fs.readFileSync)(modelJson, "utf8")).FileReferences;
		const name = (0, node_path.basename)(root);
		const target = (0, node_path.join)(modelsRoot, name);
		(0, node_fs.rmSync)(target, {
			recursive: true,
			force: true
		});
		(0, node_fs.mkdirSync)(target, { recursive: true });
		const copy = (from, to) => {
			for (const entry of (0, node_fs.readdirSync)(from, { withFileTypes: true })) {
				const src = (0, node_path.join)(from, entry.name);
				const dst = (0, node_path.join)(to, entry.name);
				if (entry.isDirectory()) {
					(0, node_fs.mkdirSync)(dst, { recursive: true });
					copy(src, dst);
				} else {
					const lower = entry.name.toLowerCase();
					if (lower.endsWith(".json") || KEEP.has((0, node_path.extname)(lower)) || lower.includes(".motion3.json")) (0, node_fs.cpSync)(src, dst);
				}
			}
		};
		copy(root, target);
		return {
			name,
			entry: (0, node_path.relative)(target, (0, node_path.join)(target, (0, node_path.relative)(root, modelJson))).replace(/\\/g, "/")
		};
	};
	const openPet = async () => {
		if (!state.modelFile) return {
			ok: false,
			error: "请先在设置里上传 Live2D 模型"
		};
		if (state.windowId) return {
			ok: true,
			windowId: state.windowId
		};
		const modelPath = `@data/models/${state.modelDir}/${state.modelFile}`.replace(/\/+/g, "/");
		const id = await dola.desktop.open({
			modId: "livepet",
			page: "pet.html",
			width: 380,
			height: 520,
			ignoreMouse: true,
			alwaysOnTop: state.alwaysOnTop,
			query: {
				model: modelPath,
				scale: String(state.scale)
			}
		});
		state.windowId = id;
		save();
		return {
			ok: true,
			windowId: id
		};
	};
	const closePet = () => {
		if (state.windowId) {
			dola.desktop.close(state.windowId);
			state.windowId = null;
			save();
		}
		return { ok: true };
	};
	dola.ipc.handle("state", () => ({
		modelDir: state.modelDir,
		modelFile: state.modelFile,
		showing: Boolean(state.windowId),
		scale: state.scale,
		alwaysOnTop: state.alwaysOnTop
	}));
	dola.ipc.handle("pick-model", async () => {
		try {
			const picked = await dola.dialog.pickDirectory("选择 Live2D 模型文件夹（含 .model3.json）");
			if (!picked) return {
				ok: false,
				canceled: true
			};
			const { name, entry } = await importModel(picked);
			state.modelDir = name;
			state.modelFile = entry;
			state.windowId = null;
			save();
			dola.ipc.broadcast("state-changed", {
				modelDir: name,
				modelFile: entry,
				showing: false
			});
			return {
				ok: true,
				name,
				entry
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "导入失败"
			};
		}
	});
	/** Import from an explicit path (also used by tests, since dialogs need a human). */
	dola.ipc.handle("import-model", async (dir) => {
		if (typeof dir !== "string" || !dir) return {
			ok: false,
			error: "缺少路径"
		};
		try {
			const { name, entry } = await importModel(dir);
			state.modelDir = name;
			state.modelFile = entry;
			state.windowId = null;
			save();
			dola.ipc.broadcast("state-changed", {
				modelDir: name,
				modelFile: entry,
				showing: false
			});
			return {
				ok: true,
				name,
				entry
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "导入失败"
			};
		}
	});
	dola.ipc.handle("show", () => openPet());
	dola.ipc.handle("hide", () => closePet());
	dola.ipc.handle("set-scale", (_scale) => {
		const s = Number(_scale);
		if (Number.isFinite(s) && s > .2 && s < 3) state.scale = s;
		save();
		if (state.windowId) {
			dola.desktop.close(state.windowId);
			state.windowId = null;
			openPet();
		}
		return {
			ok: true,
			scale: state.scale
		};
	});
	dola.ipc.handle("set-on-top", (on) => {
		state.alwaysOnTop = Boolean(on);
		if (state.windowId) dola.desktop.setAlwaysOnTop(state.windowId, state.alwaysOnTop);
		save();
		return {
			ok: true,
			alwaysOnTop: state.alwaysOnTop
		};
	});
	/**
	* The page reports the character's box so the host can decide where clicks land.
	*
	* The window is created with passthrough on; the page then toggles it off whenever the
	* pointer is over the character and back on when it leaves. That needs the pointer
	* position, which only the page has (Electron's `forward: true` keeps mousemove flowing
	* while ignoring clicks), so the page drives it and the main side just stores the box.
	*/
	dola.ipc.handle("hit-box", (box) => {
		if (!state.windowId || !box || typeof box !== "object") return { ok: false };
		state.hitBox = box;
		return { ok: true };
	});
	/** Called by the page as the pointer enters / leaves the character. */
	dola.ipc.handle("set-passthrough", (ignore) => {
		if (!state.windowId) return { ok: false };
		dola.desktop.setIgnoreMouse(state.windowId, Boolean(ignore));
		return { ok: true };
	});
	dola.ipc.handle("list-windows", () => dola.desktop.list());
	let orbWindow = null;
	let orbExpanded = false;
	const openOrb = async () => {
		if (orbWindow) return orbWindow;
		orbWindow = await dola.desktop.open({
			modId: "livepet",
			page: "orb.html",
			width: 240,
			height: 60,
			ignoreMouse: false,
			alwaysOnTop: true
		});
		dola.desktop.setBounds(orbWindow, {
			width: 240,
			height: 60
		});
		return orbWindow;
	};
	const closeOrb = () => {
		if (orbWindow) {
			dola.desktop.close(orbWindow);
			orbWindow = null;
		}
	};
	dola.ipc.handle("orb-show", async () => {
		if (orbWindow) return { ok: true };
		await openOrb();
		return { ok: true };
	});
	dola.ipc.handle("orb-hide", () => {
		closeOrb();
		return { ok: true };
	});
	dola.ipc.handle("orb-state", () => ({
		expanded: orbExpanded,
		showing: Boolean(orbWindow)
	}));
	dola.ipc.handle("orb-expanded", (on) => {
		orbExpanded = Boolean(on);
		save();
		return { ok: true };
	});
	dola.ipc.handle("orb-window", () => dola.desktop.list().filter((w) => w.id === orbWindow).map((w) => ({
		id: w.id,
		bounds: w.bounds
	})));
	dola.ipc.handle("orb-move", (pos) => {
		if (!orbWindow || !pos || typeof pos !== "object") return { ok: false };
		const p = pos;
		dola.desktop.setBounds(orbWindow, {
			x: p.x,
			y: p.y
		});
		return { ok: true };
	});
	dola.ipc.handle("orb-open-settings", () => {
		const win = dola.windows.main();
		if (win) {
			win.show();
			win.focus();
		}
		return { ok: true };
	});
	/** The four orb buttons. Vision / STT / chat all route through the app's AI settings. */
	dola.ipc.handle("orb-action", async (action) => {
		const kind = String(action);
		try {
			if (kind === "vision") {
				const shot = await captureScreen();
				if (!shot) return {
					ok: false,
					error: "无法截屏"
				};
				const res = await dola.ai.chat([{
					role: "system",
					content: "你是一个桌面助手，请用简短中文描述这张屏幕截图的内容与当前用户在做什么。"
				}, {
					role: "user",
					content: [{
						type: "text",
						text: "请描述这张截图。"
					}, {
						type: "image_url",
						image_url: { url: shot }
					}]
				}]);
				return res.ok ? {
					ok: true,
					text: res.content
				} : {
					ok: false,
					error: res.error
				};
			}
			if (kind === "chat") {
				const res = await dola.ai.chat([{
					role: "user",
					content: "你好，用一句话介绍你自己。"
				}]);
				return res.ok ? {
					ok: true,
					text: res.content
				} : {
					ok: false,
					error: res.error
				};
			}
			if (kind === "listen") return {
				ok: false,
				error: "语音识别尚未启用（下一版接入本地 whisper）"
			};
			return {
				ok: false,
				error: `未知操作：${kind}`
			};
		} catch (e) {
			return {
				ok: false,
				error: e instanceof Error ? e.message : "操作失败"
			};
		}
	});
	dola.on("boot", async () => {
		openOrb().catch(() => void 0);
		if (!state.modelFile) return;
		try {
			await openPet();
		} catch {}
	});
	dola.on("quit", () => {
		closeOrb();
		if (state.windowId) dola.desktop.close(state.windowId);
		state.windowId = null;
	});
}
/**
* Captures the primary display as a PNG data URL.
*
* `desktopCapturer` is a main-process API; the renderer cannot reach the screen without
* a permission prompt, so the screenshot for 识屏 is taken here.
*/
async function captureScreen() {
	try {
		const { desktopCapturer, screen } = await import("electron");
		const display = screen.getPrimaryDisplay();
		const { width, height } = display.size;
		const scale = display.scaleFactor || 1;
		const source = (await desktopCapturer.getSources({
			types: ["screen"],
			thumbnailSize: {
				width: Math.round(width * scale),
				height: Math.round(height * scale)
			}
		}))[0];
		if (!source) return null;
		return source.thumbnail.toDataURL();
	} catch {
		return null;
	}
}
//#endregion
exports.register = register;
