Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
let node_child_process = require("node:child_process");
let node_crypto = require("node:crypto");
let node_fs = require("node:fs");
let node_http = require("node:http");
node_http = __toESM(node_http);
let node_net = require("node:net");
let node_path = require("node:path");
let electron = require("electron");
let node_https = require("node:https");
node_https = __toESM(node_https);
require("node:fs/promises");
let node_tls = require("node:tls");
node_tls = __toESM(node_tls);
//#region mods/proxy/main/config.ts
function str(v, fallback = "") {
	return typeof v === "string" ? v : fallback;
}
function num(v, fallback = 0) {
	const n = typeof v === "number" ? v : Number(v);
	return Number.isFinite(n) ? n : fallback;
}
function port(v, fallback = 443) {
	const n = Math.round(num(v, fallback));
	return n > 0 && n < 65536 ? n : fallback;
}
function network(n) {
	const nw = str(n.network, "tcp");
	return [
		"tcp",
		"ws",
		"grpc",
		"http",
		"h2",
		"quic"
	].includes(nw) ? nw : "tcp";
}
function isTls(n) {
	const sec = str(n.security, "auto");
	return sec === "tls" || sec === "reality";
}
function listenHost(settings) {
	return settings.allowLan ? "0.0.0.0" : "127.0.0.1";
}
function alpnList(n) {
	const raw = str(n.alpn);
	if (!raw) return [];
	return raw.split(",").map((s) => s.trim()).filter(Boolean);
}
var PRIVATE_CIDRS = [
	"127.0.0.0/8",
	"10.0.0.0/8",
	"172.16.0.0/12",
	"192.168.0.0/16",
	"169.254.0.0/16",
	"100.64.0.0/10",
	"::1/128",
	"fc00::/7",
	"fe80::/10"
];
function xrayStream(n) {
	const nw = network(n);
	const stream = { network: nw === "h2" ? "http" : nw };
	const sni = str(n.sni) || str(n.host) || str(n.server);
	if (isTls(n)) {
		stream.security = str(n.security) === "reality" ? "reality" : "tls";
		if (stream.security === "reality") stream.realitySettings = {
			serverName: sni,
			fingerprint: str(n.fingerprint, "chrome"),
			publicKey: str(n.publicKey),
			shortId: str(n.shortId),
			spiderX: str(n.spiderX, "/"),
			show: false
		};
		else {
			const tlsSettings = {
				serverName: sni,
				allowInsecure: n.allowInsecure === true,
				fingerprint: str(n.fingerprint)
			};
			const alpn = alpnList(n);
			if (alpn.length) tlsSettings.alpn = alpn;
			stream.tlsSettings = tlsSettings;
		}
	} else stream.security = "none";
	if (nw === "ws") {
		const ws = { path: str(n.path, "/") };
		const host = str(n.host) || sni;
		if (host) ws.headers = { Host: host };
		stream.wsSettings = ws;
	} else if (nw === "grpc") stream.grpcSettings = {
		serviceName: str(n.serviceName),
		multiMode: false
	};
	else if (nw === "h2" || nw === "http") {
		const host = str(n.host) || sni;
		const settings = { path: str(n.path, "/") };
		if (host) settings.host = [host];
		stream.httpSettings = settings;
	}
	return stream;
}
function xrayOutbound(n) {
	const server = str(n.server);
	const p = port(n.port);
	const out = { tag: "proxy" };
	const tls = tlsFree(n);
	switch (n.protocol) {
		case "vmess":
			out.protocol = "vmess";
			out.settings = { vnext: [{
				address: server,
				port: p,
				users: [{
					id: str(n.uuid),
					alterId: Math.round(num(n.alterId, 0)),
					security: "auto"
				}]
			}] };
			break;
		case "vless":
			out.protocol = "vless";
			out.settings = { vnext: [{
				address: server,
				port: p,
				users: [{
					id: str(n.uuid),
					encryption: "none",
					flow: str(n.flow)
				}]
			}] };
			break;
		case "trojan":
			out.protocol = "trojan";
			out.settings = { servers: [{
				address: server,
				port: p,
				password: str(n.password)
			}] };
			break;
		case "shadowsocks":
			out.protocol = "shadowsocks";
			out.settings = { servers: [{
				address: server,
				port: p,
				method: str(n.method, "aes-256-gcm"),
				password: str(n.password)
			}] };
			break;
		case "socks":
			out.protocol = "socks";
			out.settings = { servers: [{
				address: server,
				port: p,
				users: str(n.password) ? [{
					user: str(n.uuid),
					pass: str(n.password)
				}] : []
			}] };
			break;
		case "http":
			out.protocol = "http";
			out.settings = { servers: [{
				address: server,
				port: p,
				users: str(n.password) ? [{
					user: str(n.uuid),
					pass: str(n.password)
				}] : []
			}] };
			break;
		default:
			out.protocol = "freedom";
			out.tag = "proxy";
	}
	if (out.protocol !== "freedom") out.streamSettings = xrayStream(n);
	out.mux = tls ? {
		enabled: false,
		concurrency: -1
	} : {
		enabled: false,
		concurrency: -1
	};
	return out;
}
function tlsFree(n) {
	return n.protocol === "shadowsocks" || n.protocol === "socks" || n.protocol === "http";
}
function buildXrayConfig(node, settings) {
	str(node.sni) || str(node.host) || node.server;
	const rules = [{
		type: "field",
		ip: ["geoip:private", ...PRIVATE_CIDRS],
		outboundTag: "direct",
		network: "tcp,udp"
	}, {
		type: "field",
		domain: [
			"localhost",
			"*.local",
			"*.lan"
		],
		outboundTag: "direct"
	}];
	if (str(node.host) && str(node.host) !== str(node.server)) rules.push({
		type: "field",
		domain: [str(node.host)],
		outboundTag: "proxy"
	});
	if (settings.routingMode !== "global") rules.push({
		type: "field",
		domain: ["geosite:cn", "geosite:private"],
		outboundTag: "direct"
	}, {
		type: "field",
		domain: ["geosite:geolocation-!cn"],
		outboundTag: "proxy"
	}, {
		type: "field",
		ip: ["geoip:cn"],
		outboundTag: "direct"
	});
	rules.push({
		type: "field",
		network: "udp",
		port: 443,
		outboundTag: "block"
	});
	const dnsServers = settings.remoteDns ? [
		{
			address: "https://dns.alidns.com/dns-query",
			domains: ["geosite:cn"],
			skipFallback: true
		},
		{
			address: "https://doh.pub/dns-query",
			domains: ["geosite:cn"],
			skipFallback: true
		},
		{
			address: "223.5.5.5",
			skipFallback: true
		},
		{ address: "119.29.29.29" }
	] : [{
		address: "223.5.5.5",
		skipFallback: true
	}, { address: "119.29.29.29" }];
	const config = {
		log: { loglevel: settings.logLevel === "debug" ? "debug" : settings.logLevel === "warn" ? "warning" : settings.logLevel === "error" ? "error" : "info" },
		dns: {
			servers: dnsServers,
			queryStrategy: settings.ipv6 ? "UseIP" : "UseIPv4",
			hosts: { "domain:localhost": ["127.0.0.1"] }
		},
		inbounds: [{
			tag: "mixed-in",
			port: port(settings.mixedPort, 7897),
			listen: listenHost(settings),
			protocol: "mixed",
			settings: {
				auth: "noauth",
				udp: true
			},
			sniffing: settings.sniffing ? {
				enabled: true,
				destOverride: [
					"http",
					"tls",
					"quic"
				],
				routeOnly: false
			} : { enabled: false }
		}],
		outbounds: [
			xrayOutbound(node),
			{
				tag: "direct",
				protocol: "freedom",
				settings: { domainStrategy: "UseIP" }
			},
			{
				tag: "block",
				protocol: "blackhole",
				settings: {}
			}
		],
		routing: {
			domainStrategy: "IPIfNonMatch",
			domainMatcher: "hybrid",
			rules: [...rules, {
				type: "field",
				network: "tcp,udp",
				outboundTag: "proxy"
			}]
		},
		policy: {
			levels: { "0": {
				handshake: 4,
				connIdle: 300,
				uplinkOnly: 1,
				downlinkOnly: 1
			} },
			system: {
				statsInboundUplink: false,
				statsInboundDownlink: false
			}
		}
	};
	return JSON.stringify(config, null, 2);
}
/**
* Xray needs its geo assets next to the binary (or via XRAY_LOCATION_ASSET).
* The manager sets that env var; this helper only reports what has to exist.
*/
function xrayGeoEnv(geoDirPath) {
	return { XRAY_LOCATION_ASSET: geoDirPath };
}
/**
* Hysteria2 pins are written in hex in share links, while sing-box wants the
* same 32 bytes as base64 (certificate_public_key_sha256). Values that are
* already base64 are passed through untouched.
*/
function pinToBase64(raw) {
	const v = raw.trim();
	if (!v) return "";
	const hex = v.replace(/[^0-9a-fA-F]/g, "");
	if (/^[0-9a-fA-F]{64}$/.test(hex)) return Buffer.from(hex, "hex").toString("base64");
	return v;
}
function sbTls(n) {
	if (!isTls(n)) return void 0;
	const insecure = n.allowInsecure === true;
	const tls = {
		enabled: true,
		server_name: str(n.sni) || str(n.host) || str(n.server),
		insecure
	};
	const fp = str(n.fingerprint);
	if (fp) tls.utls = {
		enabled: true,
		fingerprint: fp
	};
	const alpn = alpnList(n);
	if (alpn.length) tls.alpn = alpn;
	if (!insecure) {
		const pin = pinToBase64(str(n.pinSHA256));
		if (pin) tls.certificate_public_key_sha256 = [pin];
	}
	if (str(n.security) === "reality") tls.reality = {
		enabled: true,
		public_key: str(n.publicKey),
		short_id: str(n.shortId)
	};
	return tls;
}
function sbTransport(n) {
	const nw = network(n);
	if (nw === "ws") {
		const ws = {
			type: "ws",
			path: str(n.path, "/")
		};
		const host = str(n.host) || str(n.sni);
		if (host) ws.headers = { Host: host };
		const ed = num(0);
		if (ed > 0) ws.max_early_data = ed;
		return ws;
	}
	if (nw === "grpc") return {
		type: "grpc",
		service_name: str(n.serviceName)
	};
	if (nw === "h2" || nw === "http") {
		const http = {
			type: "http",
			path: str(n.path, "/")
		};
		const host = str(n.host) || str(n.sni);
		if (host) http.host = [host];
		return http;
	}
}
function sbOutbound(n) {
	const base = {
		tag: "proxy",
		server: str(n.server),
		server_port: port(n.port),
		domain_strategy: "prefer_ipv4"
	};
	switch (n.protocol) {
		case "vmess":
			base.type = "vmess";
			base.uuid = str(n.uuid);
			base.security = "auto";
			base.alter_id = Math.round(num(n.alterId, 0));
			break;
		case "vless":
			base.type = "vless";
			base.uuid = str(n.uuid);
			if (str(n.flow)) base.flow = str(n.flow);
			break;
		case "trojan":
			base.type = "trojan";
			base.password = str(n.password);
			break;
		case "shadowsocks":
			base.type = "shadowsocks";
			base.method = str(n.method, "aes-256-gcm");
			base.password = str(n.password);
			break;
		case "socks":
			base.type = "socks";
			base.version = "5";
			if (str(n.uuid)) base.username = str(n.uuid);
			if (str(n.password)) base.password = str(n.password);
			break;
		case "http":
			base.type = "http";
			if (str(n.uuid)) base.username = str(n.uuid);
			if (str(n.password)) base.password = str(n.password);
			break;
		case "hysteria2":
			base.type = "hysteria2";
			base.password = str(n.password);
			if (str(n.obfs)) base.obfs = {
				type: str(n.obfs),
				password: str(n.obfsParam)
			};
			if (num(n.upMbps) > 0) base.up_mbps = Math.round(num(n.upMbps));
			if (num(n.downMbps) > 0) base.down_mbps = Math.round(num(n.downMbps));
			break;
		case "tuic":
			base.type = "tuic";
			base.uuid = str(n.uuid);
			base.password = str(n.password);
			base.congestion_control = "bbr";
			base.udp_relay_mode = "native";
			break;
		case "anytls":
			base.type = "anytls";
			base.password = str(n.password);
			break;
		default:
			base.type = "direct";
			delete base.server;
			delete base.server_port;
	}
	const tls = sbTls(n);
	if (tls && base.type !== "direct") base.tls = tls;
	const transport = sbTransport(n);
	if (transport && base.type !== "direct") base.transport = transport;
	if (base.type === "hysteria2" || base.type === "tuic") {
		if (!base.tls) base.tls = {
			enabled: true,
			server_name: str(n.sni) || str(n.server)
		};
	}
	return base;
}
function buildSingBoxConfig(node, settings, cnRuleSets = {
	geosite: null,
	geoip: null
}) {
	const bypass = settings.routingMode !== "global";
	const ruleSets = bypass ? cnRuleSets : {
		geosite: null,
		geoip: null
	};
	const useRuleSets = bypass && Boolean(ruleSets.geosite || ruleSets.geoip);
	const ruleSetDefs = [];
	const cnRuleSetTags = [];
	if (ruleSets.geosite) {
		ruleSetDefs.push({
			type: "local",
			tag: "geosite-cn",
			format: "binary",
			path: ruleSets.geosite
		});
		cnRuleSetTags.push("geosite-cn");
	}
	if (ruleSets.geoip) {
		ruleSetDefs.push({
			type: "local",
			tag: "geoip-cn",
			format: "binary",
			path: ruleSets.geoip
		});
		cnRuleSetTags.push("geoip-cn");
	}
	const dnsServers = [{
		type: "udp",
		tag: "local",
		server: "223.5.5.5"
	}, {
		type: "udp",
		tag: "local2",
		server: "119.29.29.29"
	}];
	if (settings.remoteDns) dnsServers.push({
		type: "https",
		tag: "local-doh",
		server: "dns.alidns.com",
		domain_resolver: "local"
	});
	const dnsRules = [];
	const routeRules = [
		...settings.sniffing ? [{
			action: "sniff",
			inbound: ["mixed-in"],
			timeout: "300ms"
		}] : [],
		{
			ip_is_private: true,
			outbound: "direct"
		},
		...useRuleSets && cnRuleSetTags.length ? [{
			rule_set: cnRuleSetTags,
			outbound: "direct"
		}] : [],
		...useRuleSets && ruleSets.geosite ? [{
			rule_set: ["geosite-cn"],
			invert: true,
			outbound: "proxy"
		}] : [],
		{
			network: "udp",
			port: [443],
			action: "reject"
		}
	];
	const config = {
		log: {
			level: settings.logLevel === "debug" ? "debug" : settings.logLevel === "warn" ? "warn" : settings.logLevel === "error" ? "error" : "info",
			timestamp: true
		},
		dns: {
			servers: dnsServers,
			rules: dnsRules,
			final: settings.remoteDns ? "local-doh" : "local",
			strategy: settings.ipv6 ? "prefer_ipv4" : "ipv4_only"
		},
		inbounds: [{
			type: "mixed",
			tag: "mixed-in",
			listen: listenHost(settings),
			listen_port: port(settings.mixedPort, 7897)
		}],
		outbounds: [
			sbOutbound(node),
			{
				type: "direct",
				tag: "direct"
			},
			{
				type: "block",
				tag: "block"
			}
		],
		route: {
			rules: routeRules,
			rule_set: ruleSetDefs,
			final: "proxy",
			auto_detect_interface: true,
			default_domain_resolver: "local"
		},
		experimental: {
			cache_file: { enabled: false },
			clash_api: {
				external_controller: "127.0.0.1:0",
				default_mode: "rule"
			}
		}
	};
	return JSON.stringify(config, null, 2);
}
/** Quote anything that is not a plain alphanumeric / dash / dot token. */
function yamlStr(v) {
	const s = v === void 0 || v === null ? "" : String(v);
	if (s === "") return "\"\"";
	if (/^[A-Za-z0-9_][A-Za-z0-9_.-]*$/.test(s) && !/^(true|false|null|yes|no|on|off|~)$/i.test(s)) return s;
	return `"${s.replace(/\\/g, "\\\\").replace(/"/g, "\\\"").replace(/\r?\n/g, " ")}"`;
}
function emitYaml(value, indent = 0) {
	const pad = " ".repeat(indent);
	if (Array.isArray(value)) {
		if (value.length === 0) return `${pad}[]`;
		return value.map((v) => {
			if (Array.isArray(v) || typeof v === "object" && v !== null) {
				const nested = emitYaml(v, indent + 2);
				return `${pad}- ${nested.trimStart()}`;
			}
			return `${pad}- ${String(v)}`;
		}).join("\n");
	}
	if (typeof value === "object" && value !== null) {
		const entries = Object.entries(value);
		if (entries.length === 0) return `${pad}{}`;
		return entries.map(([k, v]) => {
			if (Array.isArray(v)) {
				if (v.length === 0) return `${pad}${k}: []`;
				return `${pad}${k}:\n${emitYaml(v, indent + 2)}`;
			}
			if (typeof v === "object" && v !== null) return `${pad}${k}:\n${emitYaml(v, indent + 2)}`;
			return `${pad}${k}: ${String(v)}`;
		}).join("\n");
	}
	return `${pad}${String(value)}`;
}
function mihomoProxy(n) {
	const p = {
		name: "NODE",
		type: "ss",
		server: yamlStr(n.server),
		port: port(n.port),
		udp: true
	};
	const sni = str(n.sni) || str(n.host) || str(n.server);
	const nw = network(n);
	switch (n.protocol) {
		case "vmess":
			p.type = "vmess";
			p.uuid = yamlStr(n.uuid);
			p.alterId = Math.round(num(n.alterId, 0));
			p.cipher = "auto";
			if (isTls(n)) {
				p.tls = true;
				p.servername = yamlStr(sni);
			}
			if (str(n.fingerprint)) p["client-fingerprint"] = yamlStr(n.fingerprint);
			break;
		case "vless":
			p.type = "vless";
			p.uuid = yamlStr(n.uuid);
			if (isTls(n)) {
				p.tls = true;
				p.servername = yamlStr(sni);
			}
			if (str(n.fingerprint)) p["client-fingerprint"] = yamlStr(n.fingerprint);
			if (str(n.flow)) p.flow = yamlStr(n.flow);
			if (str(n.security) === "reality") p["reality-opts"] = {
				"public-key": yamlStr(n.publicKey),
				"short-id": yamlStr(n.shortId)
			};
			break;
		case "trojan":
			p.type = "trojan";
			p.password = yamlStr(n.password);
			p.sni = yamlStr(sni);
			p["skip-cert-verify"] = false;
			break;
		case "shadowsocks":
			p.type = "ss";
			p.cipher = yamlStr(str(n.method, "aes-256-gcm"));
			p.password = yamlStr(n.password);
			if (str(n.obfs)) {
				p.plugin = "obfs";
				p["plugin-opts"] = {
					mode: yamlStr(n.obfs),
					host: yamlStr(n.obfsParam)
				};
			}
			break;
		case "socks":
			p.type = "socks5";
			if (str(n.uuid)) p.username = yamlStr(n.uuid);
			if (str(n.password)) p.password = yamlStr(n.password);
			break;
		case "http":
			p.type = "http";
			if (str(n.uuid)) p.username = yamlStr(n.uuid);
			if (str(n.password)) p.password = yamlStr(n.password);
			if (isTls(n)) {
				p.tls = true;
				p.sni = yamlStr(sni);
			}
			break;
		case "hysteria2":
			p.type = "hysteria2";
			p.password = yamlStr(n.password);
			p.sni = yamlStr(sni);
			p["skip-cert-verify"] = false;
			if (str(n.pinSHA256)) p.fingerprint = yamlStr(str(n.pinSHA256).toLowerCase());
			delete p.udp;
			if (str(n.obfs)) {
				p.obfs = yamlStr(n.obfs);
				p["obfs-password"] = yamlStr(n.obfsParam);
			}
			if (num(n.upMbps) > 0) p.up = yamlStr(`${Math.round(num(n.upMbps))} Mbps`);
			if (num(n.downMbps) > 0) p.down = yamlStr(`${Math.round(num(n.downMbps))} Mbps`);
			break;
		case "tuic":
			p.type = "tuic";
			p.uuid = yamlStr(n.uuid);
			p.password = yamlStr(n.password);
			p.sni = yamlStr(sni);
			p.alpn = ["h3"];
			p["congestion-controller"] = "bbr";
			p["udp-relay-mode"] = "native";
			p["skip-cert-verify"] = false;
			break;
		case "anytls":
			p.type = "anytls";
			p.password = yamlStr(n.password);
			p.sni = yamlStr(sni);
			p["skip-cert-verify"] = false;
			break;
		case "wireguard":
			p.type = "wireguard";
			p.ip = yamlStr(str(n.uuid, "172.16.0.2/32"));
			p["private-key"] = yamlStr(str(n.password));
			p["public-key"] = yamlStr(str(n.publicKey));
			p["allowed-ips"] = ["0.0.0.0/0"];
			break;
		default: p.type = "socks5";
	}
	if ([
		"vmess",
		"vless",
		"trojan"
	].includes(str(p.type))) {
		if (nw === "ws") {
			p.network = "ws";
			const ws = { path: yamlStr(str(n.path, "/")) };
			const host = str(n.host) || sni;
			if (host) ws.headers = { Host: yamlStr(host) };
			p["ws-opts"] = ws;
		} else if (nw === "grpc") {
			p.network = "grpc";
			p["grpc-opts"] = { "grpc-service-name": yamlStr(n.serviceName) };
		} else if (nw === "h2" || nw === "http") {
			p.network = "h2";
			const h2 = { path: yamlStr(str(n.path, "/")) };
			const host = str(n.host) || sni;
			if (host) h2.host = [yamlStr(host)];
			p["h2-opts"] = h2;
		} else p.network = "tcp";
		const alpn = alpnList(n);
		if (alpn.length) p.alpn = alpn.map((a) => yamlStr(a));
	}
	for (const [k, v] of Object.entries(p)) if (typeof v === "string" && !v.startsWith("\"") && k !== "type" && k !== "cipher") p[k] = yamlStr(v);
	return p;
}
function buildMihomoConfig(node, settings) {
	const proxy = mihomoProxy(node);
	const doc = {
		"mixed-port": port(settings.mixedPort, 7897),
		"allow-lan": settings.allowLan,
		"bind-address": yamlStr(listenHost(settings)),
		mode: "rule",
		"log-level": settings.logLevel,
		ipv6: settings.ipv6,
		"geodata-mode": true,
		"geodata-loader": "standard",
		"geo-auto-update": false,
		"unified-delay": true,
		"tcp-concurrent": true,
		"external-controller": yamlStr("127.0.0.1:0"),
		profile: {
			"store-selected": false,
			"store-fake-ip": false
		},
		dns: {
			enable: true,
			ipv6: settings.ipv6,
			"enhanced-mode": "fake-ip",
			"fake-ip-range": "198.18.0.1/16",
			nameserver: ["223.5.5.5", "119.29.29.29"].map((s) => yamlStr(s)),
			fallback: settings.remoteDns ? ["https://1.1.1.1/dns-query", "https://dns.google/dns-query"].map((s) => yamlStr(s)) : [],
			"fallback-filter": {
				geoip: true,
				"geoip-code": "CN"
			},
			"nameserver-policy": { "geosite:cn": ["223.5.5.5", "119.29.29.29"] }
		},
		proxies: [proxy],
		"proxy-groups": [{
			name: "PROXY",
			type: "select",
			proxies: ["NODE", "DIRECT"]
		}],
		rules: [
			"GEOIP,private,DIRECT",
			"IP-CIDR,127.0.0.0/8,DIRECT,no-resolve",
			"IP-CIDR,10.0.0.0/8,DIRECT,no-resolve",
			"IP-CIDR,172.16.0.0/12,DIRECT,no-resolve",
			"IP-CIDR,192.168.0.0/16,DIRECT,no-resolve",
			"IP-CIDR,169.254.0.0/16,DIRECT,no-resolve",
			"DOMAIN-SUFFIX,local,DIRECT",
			"DOMAIN-SUFFIX,lan,DIRECT",
			...settings.routingMode !== "global" ? [
				"GEOSITE,cn,DIRECT",
				"GEOIP,CN,DIRECT",
				"GEOSITE,private,DIRECT"
			] : [],
			"AND,((NETWORK,udp),(DST-PORT,443)),REJECT",
			"MATCH,PROXY"
		]
	};
	return `${[
		"# Dola Toolkit — generated mihomo config (do not edit, rewritten on every start)",
		`# node: ${str(node.name, "unnamed")} (${str(node.protocol)}) engine: mihomo`,
		""
	].join("\n")}${emitYaml(doc)}\n`;
}
/** Minimal YAML sanity check used by the self-test (not a real parser). */
function validateMihomoYaml(text) {
	const problems = [];
	const lines = text.split(/\r?\n/);
	if (!/^mixed-port:\s*\d+/m.test(text)) problems.push("missing mixed-port");
	if (!/^proxies:/m.test(text)) problems.push("missing proxies");
	if (!/^rules:/m.test(text)) problems.push("missing rules");
	const seen = /* @__PURE__ */ new Map();
	lines.forEach((line, i) => {
		if (line.trim().startsWith("#") || !line.trim()) return;
		if (/^\t/.test(line)) problems.push(`tab indentation at line ${i + 1}`);
		if ((line.match(/"/g) ?? []).length % 2 !== 0) problems.push(`unbalanced quotes at line ${i + 1}: ${line.trim()}`);
		const key = /^(\s*)([A-Za-z0-9_.-]+):/.exec(line);
		if (key) {
			const sig = `${key[1].length}|${key[2]}`;
			seen.set(sig, (seen.get(sig) ?? 0) + 1);
		}
	});
	for (const [sig, count] of seen) {
		const [indent, key] = sig.split("|");
		if (key === "type" || key === "name" || key === "path" || key === "mode") continue;
		if (count > 1) problems.push(`duplicate key "${key}" at indent ${indent}`);
	}
	return problems;
}
function buildCoreConfig(engine, node, settings, cnRuleSets = {
	geosite: null,
	geoip: null
}) {
	switch (engine) {
		case "xray": return buildXrayConfig(node, settings);
		case "singbox": return buildSingBoxConfig(node, settings, cnRuleSets);
		case "mihomo": return buildMihomoConfig(node, settings);
		default: return buildXrayConfig(node, settings);
	}
}
function configFileName(engine) {
	return engine === "mihomo" ? "config.yaml" : "config.json";
}
/** argv for a foreground run; the first element is the subcommand when needed. */
function startArgs(engine, configPath, homeDir) {
	switch (engine) {
		case "xray": return [
			"run",
			"-c",
			configPath
		];
		case "singbox": return [
			"run",
			"-c",
			configPath,
			"--disable-color"
		];
		case "mihomo": return homeDir ? [
			"-d",
			homeDir,
			"-f",
			configPath
		] : ["-f", configPath];
		default: return ["-c", configPath];
	}
}
function testArgs(engine, configPath, homeDir) {
	switch (engine) {
		case "xray": return [
			"run",
			"-test",
			"-c",
			configPath
		];
		case "singbox": return [
			"check",
			"-c",
			configPath,
			"--disable-color"
		];
		case "mihomo": return homeDir ? [
			"-d",
			homeDir,
			"-t",
			"-f",
			configPath
		] : [
			"-t",
			"-f",
			configPath
		];
		default: return [
			"-t",
			"-f",
			configPath
		];
	}
}
//#endregion
//#region mods/proxy/main/binary.ts
var FALLBACK_TOOL_DIR = "D:\\桌面\\server\\tool";
var EXE_NAMES = {
	xray: ["xray.exe", "xray"],
	singbox: ["sing-box.exe", "sing-box"],
	mihomo: ["mihomo.exe", "mihomo"]
};
var SUBDIRS = {
	xray: "xray",
	singbox: "singbox",
	mihomo: "mihomo"
};
var CORE_LABELS = {
	xray: "Xray",
	mihomo: "Mihomo",
	singbox: "sing-box"
};
/** True when `engine` can actually run this protocol. */
function engineSupports(engine, protocol) {
	return CAPABILITIES[engine]?.includes(protocol) ?? false;
}
/** Engines that can run this protocol, best first. */
function enginesFor(protocol) {
	return [
		"singbox",
		"mihomo",
		"xray"
	].filter((e) => engineSupports(e, protocol));
}
var CAPABILITIES = {
	xray: [
		"vmess",
		"vless",
		"trojan",
		"shadowsocks",
		"socks",
		"http"
	],
	singbox: [
		"vmess",
		"vless",
		"trojan",
		"shadowsocks",
		"socks",
		"http",
		"hysteria2",
		"tuic",
		"anytls"
	],
	mihomo: [
		"vmess",
		"vless",
		"trojan",
		"shadowsocks",
		"socks",
		"http",
		"hysteria2",
		"tuic",
		"anytls",
		"wireguard"
	]
};
var BLURBS = {
	xray: "VLESS / VMess / REALITY — 兼容性最好，适合分流与伪装",
	singbox: "sing-box 1.14 — 支持 Hysteria2 / TUIC / AnyTLS 等新协议",
	mihomo: "Clash Meta 内核 — 协议最全，支持 WireGuard 与规则集"
};
var cachedRoot = null;
/** Candidate `cores` directories, most specific first. */
function coreRoots() {
	const roots = [];
	if (electron.app.isPackaged) {
		roots.push((0, node_path.join)(process.resourcesPath, "cores"));
		try {
			const exeDir = (0, node_path.dirname)(electron.app.getPath("exe"));
			roots.push((0, node_path.join)(exeDir, "cores"));
			roots.push((0, node_path.join)(exeDir, "..", "cores"));
			roots.push((0, node_path.join)(exeDir, "resources", "cores"));
		} catch {}
		roots.push((0, node_path.join)(FALLBACK_TOOL_DIR, "cores"));
		roots.push(FALLBACK_TOOL_DIR);
	} else {
		const appPath = safeAppPath();
		if (appPath) {
			roots.push((0, node_path.join)(appPath, "cores"));
			roots.push((0, node_path.join)(appPath, "..", "cores"));
			roots.push((0, node_path.join)(appPath, "..", "..", "cores"));
		}
		roots.push((0, node_path.join)(process.cwd(), "cores"));
		roots.push((0, node_path.join)(FALLBACK_TOOL_DIR, "cores"));
		roots.push(FALLBACK_TOOL_DIR);
	}
	return [...new Set(roots.map((r) => normalize(r)))];
}
function safeAppPath() {
	try {
		return electron.app.getAppPath();
	} catch {
		return null;
	}
}
function normalize(p) {
	return p.replace(/[\\/]+$/, "");
}
function isFile(p) {
	try {
		return (0, node_fs.statSync)(p).isFile();
	} catch {
		return false;
	}
}
function dirHasEngine(dir, engine) {
	const sub = (0, node_path.join)(dir, SUBDIRS[engine]);
	const names = EXE_NAMES[engine];
	for (const n of names) {
		if (isFile((0, node_path.join)(sub, n))) return true;
		if (isFile((0, node_path.join)(dir, n))) return true;
	}
	return false;
}
/** Locate a `cores` dir that actually contains this engine (or fall back to the first). */
function coresDirFor(engine) {
	const roots = coreRoots();
	for (const root of roots) if (dirHasEngine(root, engine)) return root;
	if (cachedRoot) return cachedRoot;
	return roots[0] ?? (0, node_path.join)(process.cwd(), "cores");
}
/** Absolute exe path for an engine, or null when no binary can be found. */
function findCore(engine) {
	const roots = coreRoots();
	const sub = SUBDIRS[engine];
	for (const root of roots) for (const name of EXE_NAMES[engine]) {
		const nested = (0, node_path.join)(root, sub, name);
		if (isFile(nested)) return nested;
	}
	for (const root of roots) for (const name of EXE_NAMES[engine]) {
		const flat = (0, node_path.join)(root, name);
		if (isFile(flat)) return flat;
	}
	return null;
}
/** Directory where geoip.dat / geosite.dat live (may not exist yet). */
function geoDir() {
	const root = coresDirFor("xray");
	return (0, node_path.join)(root, "geofiles");
}
/**
* sing-box rule-set (.srs) files for the 绕过大陆 mode.
*
* Unlike Xray and Mihomo, sing-box 1.14 cannot read the legacy geoip.dat /
* geosite.dat databases, so the CN lists are shipped separately as binary rule
* sets. Returns nulls when they are missing, in which case the caller falls back
* to routing everything through the proxy.
*/
function findRuleSets() {
	const roots = [
		(0, node_path.join)(process.resourcesPath ?? "", "geo"),
		(0, node_path.join)(electron.app.getAppPath(), "resources", "geo"),
		(0, node_path.join)((0, node_path.dirname)(electron.app.getPath("exe")), "geo"),
		(0, node_path.join)(process.cwd(), "resources", "geo")
	];
	let geosite = null;
	let geoip = null;
	for (const dir of roots) {
		if (!geosite && isFile((0, node_path.join)(dir, "geosite-cn.srs"))) geosite = (0, node_path.join)(dir, "geosite-cn.srs");
		if (!geoip && isFile((0, node_path.join)(dir, "geoip-cn.srs"))) geoip = (0, node_path.join)(dir, "geoip-cn.srs");
		if (geosite && geoip) break;
	}
	return {
		geosite,
		geoip
	};
}
function findGeo() {
	const roots = coreRoots();
	for (const root of roots) for (const dir of [(0, node_path.join)(root, "geofiles"), root]) {
		const geoip = (0, node_path.join)(dir, "geoip.dat");
		const geosite = (0, node_path.join)(dir, "geosite.dat");
		if (isFile(geoip) || isFile(geosite)) return {
			dir,
			geoip: isFile(geoip) ? geoip : null,
			geosite: isFile(geosite) ? geosite : null
		};
	}
	return {
		dir: geoDir(),
		geoip: null,
		geosite: null
	};
}
function geoFileInfo(file) {
	if (!file || !(0, node_fs.existsSync)(file)) return null;
	try {
		const st = (0, node_fs.statSync)(file);
		return {
			path: file,
			size: st.size,
			updatedAt: st.mtimeMs
		};
	} catch {
		return null;
	}
}
var VERSION_ARGS = {
	xray: ["--version"],
	singbox: ["version"],
	mihomo: ["-v"]
};
var versionCache = /* @__PURE__ */ new Map();
function extractVersion(engine, raw) {
	for (const re of {
		xray: [/Xray\s+([vV]?\d+(?:\.\d+)+)/i],
		singbox: [/sing-box\s+version\s+([vV]?\d+(?:\.\d+)+)/i, /version\s+([vV]?\d+(?:\.\d+)+)/i],
		mihomo: [/Mihomo\s+Meta\s+([vV]?\d+(?:\.\d+)+)/i, /([vV]?\d+(?:\.\d+)+)/]
	}[engine]) {
		const m = re.exec(raw);
		if (m?.[1]) return m[1].replace(/^v/i, "");
	}
	return null;
}
/** Runs `<core> --version` once (3 s cap) and caches the parsed version string. */
/**
* Drops the cached "exe -version" result for an engine.
* Called after an in-app core update replaces the binary, otherwise the UI keeps
* showing the old version until the app restarts.
*/
function invalidateCoreVersion(engine) {
	versionCache.delete(engine);
}
function runCoreVersion(engine) {
	if (versionCache.has(engine)) return Promise.resolve(versionCache.get(engine) ?? null);
	const bin = findCore(engine);
	if (!bin) {
		versionCache.set(engine, null);
		return Promise.resolve(null);
	}
	return new Promise((resolve) => {
		let settled = false;
		const done = (v) => {
			if (settled) return;
			settled = true;
			versionCache.set(engine, v);
			resolve(v);
		};
		try {
			(0, node_child_process.execFile)(bin, VERSION_ARGS[engine], {
				windowsHide: true,
				timeout: 3e3,
				encoding: "utf8",
				maxBuffer: 1 << 20
			}, (err, stdout, stderr) => {
				const raw = `${stdout ?? ""}\n${stderr ?? ""}`.trim();
				const v = extractVersion(engine, raw);
				if (v) return done(v);
				if (err && !raw) return done(null);
				done(null);
			}).on("error", () => done(null));
			setTimeout(() => done(null), 3200).unref?.();
		} catch {
			done(null);
		}
	});
}
async function listEngines() {
	const engines = [
		"xray",
		"singbox",
		"mihomo"
	];
	const out = [];
	for (const engine of engines) {
		const bin = findCore(engine);
		const version = bin ? await runCoreVersion(engine) : null;
		out.push({
			engine,
			label: CORE_LABELS[engine],
			blurb: BLURBS[engine],
			protocols: CAPABILITIES[engine],
			version,
			available: bin !== null,
			binary: bin ?? ""
		});
	}
	return out;
}
/** Forget cached versions (used after the Lead copies cores into place). */
function clearBinaryCache() {
	versionCache.clear();
	cachedRoot = null;
}
/** Numeric-aware version comparison (`1.10` > `1.9`, `26.10.21` > `26.3.27`). */
function compareVersions(a, b) {
	const pa = String(a).replace(/^v/, "").split(/[.-]/).map((n) => Number.parseInt(n, 10) || 0);
	const pb = String(b).replace(/^v/, "").split(/[.-]/).map((n) => Number.parseInt(n, 10) || 0);
	for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
		const d = (pa[i] ?? 0) - (pb[i] ?? 0);
		if (d !== 0) return d;
	}
	return 0;
}
/** Installed version of an engine, or null when the binary is missing. */
async function currentCoreVersion(engine) {
	if (!findCore(engine)) return null;
	try {
		return await runCoreVersion(engine) ?? null;
	} catch {
		return null;
	}
}
//#endregion
//#region mods/proxy/main/manager.ts
/**
* Host services, injected by the mod entry before the manager is used.
*
* The manager used to import `../store` and `./binary` directly, which tied the proxy
* feature to the application core. Everything it needs now arrives through this handle,
* so the app carries no proxy knowledge at all.
*/
var host = null;
function setProxyHost(api) {
	host = api;
}
var LOG_LIMIT = 400;
/**
* Absolute path to reg.exe.
*
* The Electron main process can inherit a PATH without System32 (portable exe,
* launched from a minimal shell), in which case spawn('reg.exe') fails with
* ENOENT and the system proxy silently never gets applied.
*/
function regExe() {
	const root = process.env["SystemRoot"] || process.env["windir"] || "C:\\Windows";
	const abs = (0, node_path.join)(root, "System32", "reg.exe");
	return (0, node_fs.existsSync)(abs) ? abs : "reg.exe";
}
var REG_INTERNET = "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings";
var TEST_TIMEOUT = 8e3;
var HEALTH_TIMEOUT = 8e3;
function emptyRunning() {
	return {
		child: null,
		pid: null,
		startedAt: null,
		nodeId: null,
		error: null,
		restarting: false,
		restartCount: 0,
		configPath: null
	};
}
function now() {
	return Date.now();
}
function delay(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
var ProxyManager = class {
	nodes = [];
	selectedNodeId = null;
	activeEngine = "xray";
	systemProxyOn = false;
	running = /* @__PURE__ */ new Map();
	logs = /* @__PURE__ */ new Map();
	versions = /* @__PURE__ */ new Map();
	listeners = /* @__PURE__ */ new Set();
	logListeners = /* @__PURE__ */ new Set();
	broadcastTimer = null;
	stopping = false;
	/** engines we are deliberately shutting down (see stopEngine) */
	intentionalStop = /* @__PURE__ */ new Set();
	/** set when the last start failed because the port was already taken */
	recentPortClash = false;
	/** log count at the start of the last node test, per engine */
	logCursor = /* @__PURE__ */ new Map();
	testPortCursor = 18080;
	/** user's own proxy settings, captured before we enable ours */
	previousProxy = null;
	constructor() {
		this.reload();
		for (const engine of [
			"xray",
			"singbox",
			"mihomo"
		]) {
			this.running.set(engine, emptyRunning());
			this.logs.set(engine, []);
		}
	}
	reload() {
		const stored = host.store.get();
		this.nodes = stored.nodes;
		this.selectedNodeId = stored.selectedNodeId;
		this.activeEngine = stored.activeEngine;
		this.systemProxyOn = stored.systemProxy;
	}
	persist() {
		host.store.patch({
			nodes: this.nodes,
			selectedNodeId: this.selectedNodeId,
			activeEngine: this.activeEngine,
			systemProxy: this.systemProxyOn
		});
	}
	onState(cb) {
		this.listeners.add(cb);
		return () => this.listeners.delete(cb);
	}
	onLog(cb) {
		this.logListeners.add(cb);
		return () => this.logListeners.delete(cb);
	}
	/** Throttled state broadcast — cores can emit hundreds of lines per second. */
	emitState() {
		if (this.broadcastTimer) return;
		this.broadcastTimer = setTimeout(() => {
			this.broadcastTimer = null;
			let snapshot;
			try {
				snapshot = this.state();
			} catch {
				return;
			}
			for (const cb of this.listeners) try {
				cb(snapshot);
			} catch {}
		}, 120);
		this.broadcastTimer.unref?.();
	}
	emitLog(event) {
		for (const cb of this.logListeners) try {
			cb(event);
		} catch {}
	}
	settings() {
		return host.settings.get().proxy;
	}
	state() {
		return {
			nodes: this.nodes.map((n) => ({ ...n })),
			selectedNodeId: this.selectedNodeId,
			engines: [
				"xray",
				"singbox",
				"mihomo"
			].map((e) => this.statusOf(e)),
			activeEngine: this.activeEngine,
			systemProxy: this.systemProxyOn,
			geo: this.geoState(),
			settings: this.settings()
		};
	}
	statusOf(engine) {
		const run = this.running.get(engine) ?? emptyRunning();
		return {
			engine,
			available: findCore(engine) !== null,
			version: this.versions.get(engine) ?? null,
			running: run.child !== null,
			pid: run.pid,
			nodeId: run.nodeId,
			startedAt: run.startedAt,
			error: run.error,
			mixedPort: this.settings().mixedPort,
			logs: [...this.logs.get(engine) ?? []]
		};
	}
	async engines() {
		const list = await listEngines();
		for (const e of list) this.versions.set(e.engine, e.version);
		return list;
	}
	appendLog(engine, line) {
		const clean = line.replace(/\r$/, "");
		if (!clean.trim()) return;
		const buf = this.logs.get(engine) ?? [];
		buf.push(clean);
		if (buf.length > LOG_LIMIT) buf.splice(0, buf.length - LOG_LIMIT);
		this.logs.set(engine, buf);
		this.emitLog({
			engine,
			line: clean,
			level: this.levelOf(clean),
			at: now()
		});
	}
	levelOf(line) {
		if (/\b(fatal|error|err|failed|exception)\b/i.test(line)) return "error";
		if (/\b(warn|warning|deprecated)\b/i.test(line)) return "warn";
		return "info";
	}
	clearLogs(engine) {
		this.logs.set(engine, []);
		this.emitState();
	}
	nodeById(id) {
		if (!id) return null;
		return this.nodes.find((n) => n.id === id) ?? null;
	}
	saveNode(draft) {
		const ts = now();
		const engineDefault = this.settings().defaultEngine;
		const existing = draft.id ? this.nodeById(draft.id) : null;
		if (existing) {
			const updated = {
				...existing,
				...sanitizeDraft(draft),
				id: existing.id,
				createdAt: existing.createdAt,
				updatedAt: ts
			};
			this.nodes = this.nodes.map((n) => n.id === existing.id ? updated : n);
			this.persist();
			this.emitState();
			return updated;
		}
		const created = {
			...baseNode(),
			...sanitizeDraft(draft),
			id: (0, node_crypto.randomUUID)(),
			engine: isEngine(draft.engine) ? draft.engine : engineDefault,
			createdAt: ts,
			updatedAt: ts
		};
		this.nodes = [...this.nodes, created];
		if (!this.selectedNodeId) this.selectedNodeId = created.id;
		this.persist();
		this.emitState();
		return created;
	}
	deleteNode(id) {
		if (!this.nodes.some((n) => n.id === id)) return;
		this.nodes = this.nodes.filter((n) => n.id !== id);
		if (this.selectedNodeId === id) {
			this.selectedNodeId = this.nodes[0]?.id ?? null;
			if (this.isRunning()) this.restartForNodeChange();
		}
		this.persist();
		this.emitState();
	}
	selectNode(id) {
		if (id !== null && !this.nodeById(id)) {
			this.emitState();
			return this.state();
		}
		const changed = id !== this.selectedNodeId;
		this.selectedNodeId = id;
		const node = this.nodeById(id);
		if (node && isEngine(node.engine)) this.activeEngine = node.engine;
		this.persist();
		if (changed && this.isRunning()) this.restartForNodeChange();
		this.emitState();
		return this.state();
	}
	async restartForNodeChange() {
		if (!this.isRunning()) return;
		const keepSystemProxy = this.systemProxyOn;
		this.stopping = true;
		try {
			for (const e of [
				"xray",
				"singbox",
				"mihomo"
			]) await this.stopEngine(e);
		} finally {
			this.stopping = false;
		}
		await delay(150);
		this.systemProxyOn = keepSystemProxy;
		await this.start();
		if (keepSystemProxy && !this.systemProxyOn) await this.setSystemProxy(true);
	}
	isRunning() {
		for (const run of this.running.values()) if (run.child) return true;
		return false;
	}
	/**
	* React to a settings write that affects the proxy.
	*
	* Previously nothing notified the manager, so toggling 允许局域网 (allowLan)
	* changed the stored value but the running core kept its old listen address:
	* only whichever mode the core had been started with actually worked, and
	* flipping the other switch appeared to break proxying.
	*/
	async applySettingsChange(prev, next) {
		if ((prev.allowLan !== next.allowLan || prev.mixedPort !== next.mixedPort || prev.sniffing !== next.sniffing || prev.ipv6 !== next.ipv6 || prev.logLevel !== next.logLevel || prev.remoteDns !== next.remoteDns || prev.bypass !== next.bypass) && this.isRunning()) await this.restartForNodeChange();
		if (prev.systemProxy !== next.systemProxy) {
			if (next.systemProxy && this.isRunning()) await this.setSystemProxy(true);
			else if (!next.systemProxy && this.systemProxyOn) await this.setSystemProxy(false);
		}
	}
	importLinks(text) {
		const result = {
			added: [],
			failed: []
		};
		if (typeof text !== "string" || !text.trim()) return result;
		const lines = text.split(/\r?\n/);
		for (const raw of lines) {
			const line = raw.trim();
			if (!line || line.startsWith("#") || line.startsWith("//")) continue;
			try {
				const parsed = parseShareLink(line);
				if (!parsed) {
					result.failed.push({
						link: truncate(line),
						reason: "无法识别的链接格式"
					});
					continue;
				}
				const node = this.saveNode(parsed);
				result.added.push(node);
			} catch (e) {
				result.failed.push({
					link: truncate(line),
					reason: e instanceof Error ? e.message : "解析失败"
				});
			}
		}
		return result;
	}
	async start() {
		this.stopping = false;
		this.recentPortClash = false;
		const node = this.nodeById(this.selectedNodeId) ?? this.nodes[0] ?? null;
		if (!node) {
			this.fail("xray", "请先添加或选择一个节点");
			const engine = this.activeEngine;
			return this.statusOf(engine);
		}
		if (!node.enabled) {
			this.fail(node.engine, "该节点已被禁用");
			return this.statusOf(node.engine);
		}
		const engine = isEngine(node.engine) ? node.engine : this.settings().defaultEngine;
		if (this.selectedNodeId !== node.id) this.selectedNodeId = node.id;
		this.activeEngine = engine;
		if (!engineSupports(engine, node.protocol)) {
			const alternatives = enginesFor(node.protocol).filter((e) => findCore(e) !== null);
			const suggest = alternatives.length ? `请把该节点的内核改为 ${alternatives.map((e) => CORE_LABELS[e]).join(" 或 ")}` : "当前没有可用的内核支持该协议";
			const msg = `${CORE_LABELS[engine]} 不支持 ${node.protocol.toUpperCase()} 节点，${suggest}`;
			this.fail(engine, msg);
			return this.statusOf(engine);
		}
		for (const other of [
			"xray",
			"singbox",
			"mihomo"
		]) if (other !== engine && this.running.get(other)?.child) await this.stopEngine(other);
		await this.killOrphanedCores(this.settings().mixedPort);
		const run = this.running.get(engine) ?? emptyRunning();
		if (run.child && run.nodeId === node.id && await this.waitForPort(this.settings().mixedPort, 400)) {
			this.emitState();
			return this.statusOf(engine);
		}
		this.running.set(engine, run);
		run.error = null;
		run.nodeId = node.id;
		const bin = findCore(engine);
		if (!bin) {
			this.running.set(engine, {
				...emptyRunning(),
				nodeId: node.id,
				error: `未找到 ${CORE_LABELS[engine]} 核心文件`
			});
			this.emitState();
			return this.statusOf(engine);
		}
		const settings = this.settings();
		let configText;
		try {
			configText = buildCoreConfig(engine, node, settings, findRuleSets());
		} catch (e) {
			const msg = e instanceof Error ? e.message : "配置生成失败";
			this.running.set(engine, {
				...emptyRunning(),
				nodeId: node.id,
				error: msg
			});
			this.emitState();
			return this.statusOf(engine);
		}
		if (engine === "mihomo") {
			const problems = validateMihomoYaml(configText);
			if (problems.length) this.appendLog(engine, `配置自检警告: ${problems.join("; ")}`);
		}
		const dir = (0, node_path.join)(host.dataDir, "proxy", engine);
		try {
			(0, node_fs.mkdirSync)(dir, { recursive: true });
		} catch {}
		const cfgPath = (0, node_path.join)(dir, configFileName(engine));
		try {
			(0, node_fs.writeFileSync)(cfgPath, configText, "utf8");
		} catch (e) {
			const msg = `无法写入配置文件: ${e instanceof Error ? e.message : String(e)}`;
			this.running.set(engine, {
				...emptyRunning(),
				nodeId: node.id,
				error: msg
			});
			this.emitState();
			return this.statusOf(engine);
		}
		run.configPath = cfgPath;
		this.bootstrapGeo(engine, dir);
		const check = await this.validateConfig(engine, cfgPath);
		if (!check.ok) {
			const msg = check.message || "配置校验失败";
			this.appendLog(engine, `配置校验失败: ${msg}`);
			this.running.set(engine, {
				...emptyRunning(),
				nodeId: node.id,
				error: msg,
				configPath: cfgPath
			});
			this.emitState();
			return this.statusOf(engine);
		}
		const args = startArgs(engine, cfgPath, dir);
		const env = { ...process.env };
		if (engine === "xray") {
			const geo = findGeo();
			Object.assign(env, xrayGeoEnv(geo.dir));
		}
		let child;
		try {
			child = (0, node_child_process.spawn)(bin, args, {
				cwd: engine === "mihomo" ? dir : (0, node_path.join)(bin, ".."),
				windowsHide: true,
				env,
				stdio: [
					"ignore",
					"pipe",
					"pipe"
				]
			});
		} catch (e) {
			const msg = e instanceof Error ? e.message : "核心启动失败";
			this.running.set(engine, {
				...emptyRunning(),
				nodeId: node.id,
				error: msg,
				configPath: cfgPath
			});
			this.emitState();
			return this.statusOf(engine);
		}
		this.running.set(engine, {
			child,
			pid: child.pid ?? null,
			startedAt: now(),
			nodeId: node.id,
			error: null,
			restarting: false,
			restartCount: 0,
			configPath: cfgPath
		});
		this.appendLog(engine, `[dola] 启动 ${CORE_LABELS[engine]} pid=${child.pid ?? "?"} port=${settings.mixedPort}`);
		child.stdout?.on("data", (buf) => this.onCoreData(engine, buf));
		child.stderr?.on("data", (buf) => this.onCoreData(engine, buf));
		child.on("error", (err) => {
			this.appendLog(engine, `[dola] 进程错误: ${err.message}`);
			this.markError(engine, err.message);
		});
		child.on("exit", (code, signal) => {
			this.onCoreExit(engine, code, signal);
		});
		this.emitState();
		if (!await this.waitForPort(settings.mixedPort, HEALTH_TIMEOUT)) {
			const run2 = this.running.get(engine);
			if (run2?.child) {
				run2.error = `核心已启动但 ${settings.mixedPort} 端口未就绪`;
				this.appendLog(engine, `[dola] ${run2.error}`);
			}
		} else if (engine === "xray" || engine === "singbox") {
			const run2 = this.running.get(engine);
			if (run2) run2.error = null;
		}
		if (settings.systemProxy) {
			if (!await this.setSystemProxy(true)) this.appendLog(engine, "[dola] 系统代理设置失败，请检查权限");
		}
		this.emitState();
		return this.statusOf(engine);
	}
	onCoreData(engine, buf) {
		const text = buf.toString("utf8");
		for (const line of text.split(/\r?\n/)) {
			if (!line.trim()) continue;
			if (/Only one usage of each socket address|address already in use|failed to listen/i.test(line)) this.recentPortClash = true;
			this.appendLog(engine, line);
		}
		this.emitState();
	}
	markError(engine, message) {
		const run = this.running.get(engine);
		if (run) run.error = message;
		this.emitState();
	}
	async onCoreExit(engine, code, signal) {
		const run = this.running.get(engine);
		if (!run) return;
		const wasIntentional = this.intentionalStop.has(engine) || this.stopping;
		this.intentionalStop.delete(engine);
		run.child = null;
		run.pid = null;
		this.appendLog(engine, `[dola] 核心已退出 code=${code ?? "null"} signal=${signal ?? "null"}`);
		this.emitState();
		if (wasIntentional) return;
		const settings = this.settings();
		const crashed = code !== 0 && !(code === 4294967295 || code === -1);
		const portClash = this.recentPortClash;
		const willRetry = settings.autoRestart && crashed && !portClash && run.restartCount < 3 && run.nodeId;
		if (!willRetry && this.systemProxyOn && settings.systemProxy) await this.setSystemProxy(false);
		if (portClash) {
			run.error = `端口 ${settings.mixedPort} 已被占用，请关闭占用该端口的程序或改用其他端口`;
			this.appendLog(engine, `[dola] ${run.error}`);
			this.recentPortClash = false;
		}
		if (willRetry) {
			run.restartCount += 1;
			run.error = `核心异常退出（code=${code ?? "?"}），正在第 ${run.restartCount} 次自动重启…`;
			this.emitState();
			this.appendLog(engine, `[dola] ${run.error}`);
			await delay(2e3);
			if (this.stopping) return;
			this.start();
			return;
		}
		run.error = code === 0 || code === null ? null : `核心退出 code=${code}`;
		run.nodeId = null;
		this.emitState();
	}
	async stop() {
		this.stopping = true;
		const engine = this.activeEngine;
		try {
			for (const e of [
				"xray",
				"singbox",
				"mihomo"
			]) await this.stopEngine(e);
			if (this.systemProxyOn) await this.setSystemProxy(false);
		} finally {
			this.stopping = false;
		}
		this.emitState();
		return this.statusOf(engine);
	}
	/**
	* Kills cores left behind by a previous (crashed or force-killed) run.
	*
	* Only the three core image names are considered, and only when nothing of ours
	* is currently tracked — a healthy run is never disturbed. The path check is
	* deliberately permissive: an orphan can live in any folder this app has shipped
	* cores from (the project `cores` tree, a previous install under the deploy
	* folder, a temp unpack of the portable build), and refusing to clean it leaves
	* the mixed port owned forever, so every start fails with「核心退出 code=1」.
	* If a *different* program owns the port it is not one of these images, and the
	* normal error message still reports it to the user.
	*/
	async killOrphanedCores(port) {
		if (process.platform !== "win32") return;
		if ([
			"xray",
			"singbox",
			"mihomo"
		].some((e) => this.running.get(e)?.child)) return;
		if (!await this.portIsListening(port)) return;
		const ps = (0, node_path.join)(process.env["SystemRoot"] || "C:\\Windows", "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
		for (const image of [
			"xray.exe",
			"sing-box.exe",
			"mihomo.exe"
		]) await new Promise((resolve) => {
			const script = `Get-Process -Name '${image.replace(/\.exe$/i, "")}' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue`;
			const child = (0, node_child_process.spawn)(ps, [
				"-NoProfile",
				"-NonInteractive",
				"-Command",
				script
			], {
				windowsHide: true,
				stdio: "ignore"
			});
			child.on("error", () => resolve());
			child.on("exit", () => resolve());
			setTimeout(resolve, 6e3).unref?.();
		});
		await delay(700);
	}
	/** True when something is already listening on the port. */
	portIsListening(port) {
		return new Promise((resolve) => {
			const socket = (0, node_net.connect)({
				host: "127.0.0.1",
				port
			});
			let done = false;
			const finish = (v) => {
				if (done) return;
				done = true;
				socket.destroy();
				resolve(v);
			};
			socket.on("connect", () => finish(true));
			socket.on("error", () => finish(false));
			setTimeout(() => finish(false), 800).unref?.();
		});
	}
	async stopEngine(engine) {
		const run = this.running.get(engine);
		if (!run) return;
		const child = run.child;
		const pid = run.pid ?? child?.pid ?? null;
		this.intentionalStop.add(engine);
		run.restartCount = 0;
		run.error = null;
		run.nodeId = null;
		run.child = null;
		run.pid = null;
		run.startedAt = null;
		if (!child && !pid) {
			this.intentionalStop.delete(engine);
			return;
		}
		this.appendLog(engine, `[dola] 停止 ${CORE_LABELS[engine]} pid=${pid ?? "?"}`);
		if (pid && process.platform === "win32") await new Promise((resolve) => {
			try {
				const killer = (0, node_child_process.spawn)("taskkill", [
					"/PID",
					String(pid),
					"/T",
					"/F"
				], {
					windowsHide: true,
					stdio: "ignore"
				});
				killer.on("exit", () => resolve());
				killer.on("error", () => resolve());
			} catch {
				resolve();
			}
		});
		try {
			child?.kill();
		} catch {}
		await this.waitForPortReleased(this.settings().mixedPort, 4e3);
		await delay(80);
		this.intentionalStop.delete(engine);
		this.emitState();
	}
	fail(engine, message) {
		const run = this.running.get(engine) ?? emptyRunning();
		run.error = message;
		this.running.set(engine, run);
		this.appendLog(engine, `[dola] ${message}`);
		this.emitState();
	}
	/** Run `-test` / `check` and report the first meaningful error line. */
	validateConfig(engine, cfgPath) {
		return new Promise((resolve) => {
			const bin = findCore(engine);
			if (!bin) return resolve({
				ok: false,
				message: "核心文件缺失"
			});
			const env = { ...process.env };
			if (engine === "xray") Object.assign(env, xrayGeoEnv(findGeo().dir));
			const homeDir = (0, node_path.dirname)(cfgPath);
			let out = "";
			let settled = false;
			const done = (ok, message = "") => {
				if (settled) return;
				settled = true;
				resolve({
					ok,
					message
				});
			};
			try {
				const child = (0, node_child_process.spawn)(bin, testArgs(engine, cfgPath, homeDir), {
					cwd: (0, node_path.join)(bin, ".."),
					windowsHide: true,
					env,
					stdio: [
						"ignore",
						"pipe",
						"pipe"
					]
				});
				child.stdout?.on("data", (b) => out += b.toString("utf8"));
				child.stderr?.on("data", (b) => out += b.toString("utf8"));
				child.on("error", (e) => done(false, e.message));
				child.on("exit", (code) => {
					if (code === 0) return done(true);
					const lines = out.split(/\r?\n/).map((l) => l.trim()).filter((l) => l && !/^Xray \d|^A unified platform|^sing-box version|^Environment:|^Mihomo Meta/i.test(l));
					done(false, lines.slice(-2).join(" ") || `exit code ${code}`);
				});
				setTimeout(() => done(false, "配置校验超时"), 2e4).unref?.();
			} catch (e) {
				done(false, e instanceof Error ? e.message : "校验失败");
			}
		});
	}
	/** Make sure mihomo finds its .dat assets in its working directory. */
	bootstrapGeo(engine, dir) {
		if (engine !== "mihomo") return;
		try {
			const geo = findGeo();
			for (const name of ["geoip.dat", "geosite.dat"]) {
				const target = (0, node_path.join)(dir, name);
				const from = name === "geoip.dat" ? geo.geoip : geo.geosite;
				if (!from || !(0, node_fs.existsSync)(from)) continue;
				if (((0, node_fs.existsSync)(target) ? (0, node_fs.statSync)(target).size : 0) >= (0, node_fs.statSync)(from).size) continue;
				(0, node_fs.writeFileSync)(target, (0, node_fs.readFileSync)(from));
			}
		} catch {}
	}
	/** Resolve once nothing is listening on `port` (or the timeout elapses). */
	waitForPortReleased(port, timeoutMs) {
		const deadline = now() + timeoutMs;
		return new Promise((resolve) => {
			const attempt = () => {
				const socket = (0, node_net.connect)({
					host: "127.0.0.1",
					port
				});
				let done = false;
				const finish = (inUse) => {
					if (done) return;
					done = true;
					socket.destroy();
					if (!inUse) return resolve();
					if (now() > deadline) return resolve();
					setTimeout(attempt, 150);
				};
				socket.setTimeout(600, () => finish(false));
				socket.once("connect", () => finish(true));
				socket.once("error", () => finish(false));
			};
			attempt();
		});
	}
	waitForPort(port, timeoutMs) {
		const deadline = now() + timeoutMs;
		return new Promise((resolve) => {
			const attempt = () => {
				const socket = (0, node_net.connect)({
					host: "127.0.0.1",
					port
				});
				let done = false;
				const finish = (ok) => {
					if (done) return;
					done = true;
					socket.destroy();
					if (ok) return resolve(true);
					if (now() > deadline) return resolve(false);
					setTimeout(attempt, 200);
				};
				socket.setTimeout(1200, () => finish(false));
				socket.once("connect", () => finish(true));
				socket.once("error", () => finish(false));
			};
			attempt();
		});
	}
	getSystemProxy() {
		return this.systemProxyOn;
	}
	/**
	* Turn the Windows system proxy on/off. When enabling, the user's existing
	* settings are snapshotted first and restored on disable, so Dola Toolkit never
	* destroys a proxy configuration it did not create. Idempotent: the snapshot
	* is taken exactly once per enable cycle.
	*/
	async setSystemProxy(on) {
		if (process.platform !== "win32") {
			this.systemProxyOn = on;
			this.persist();
			this.emitState();
			return on;
		}
		const settings = this.settings();
		const port = settings.mixedPort;
		const key = REG_INTERNET;
		let ok;
		if (on) {
			if (!this.systemProxyOn) this.previousProxy = await this.readProxySnapshot();
			ok = await this.regWrite(key, "ProxyEnable", "REG_DWORD", "1");
			if (ok) {
				await this.regWrite(key, "ProxyServer", "REG_SZ", `127.0.0.1:${port}`);
				const bypass = normalizeBypass(settings.bypass);
				if (bypass) await this.regWrite(key, "ProxyOverride", "REG_SZ", bypass);
			}
		} else {
			if (!((await this.readProxySnapshot())?.server === `127.0.0.1:${port}` || this.systemProxyOn)) {
				this.systemProxyOn = false;
				this.persist();
				this.emitState();
				return true;
			}
			ok = await this.regWrite(key, "ProxyEnable", "REG_DWORD", "0");
			if (!this.previousProxy) {
				const after = await this.readProxySnapshot();
				if (after?.enable && after.server === `127.0.0.1:${port}`) await this.regWrite(key, "ProxyEnable", "REG_DWORD", "0");
			}
			if (ok && this.previousProxy) {
				await this.regWrite(key, "ProxyEnable", "REG_DWORD", this.previousProxy.enable ? "1" : "0");
				if (this.previousProxy.server) await this.regWrite(key, "ProxyServer", "REG_SZ", this.previousProxy.server);
				if (this.previousProxy.override !== null) await this.regWrite(key, "ProxyOverride", "REG_SZ", this.previousProxy.override);
				this.previousProxy = null;
				const after = await this.readProxySnapshot();
				if (after?.enable && after.server === `127.0.0.1:${port}`) await this.regWrite(key, "ProxyEnable", "REG_DWORD", "0");
			}
		}
		if (ok) await notifyInternetSettingsChanged();
		this.systemProxyOn = ok ? on : this.systemProxyOn;
		this.persist();
		this.emitState();
		return ok;
	}
	/** Read the three registry values we touch, so they can be restored later. */
	readProxySnapshot() {
		return new Promise((resolve) => {
			try {
				const child = (0, node_child_process.spawn)(regExe(), ["query", REG_INTERNET], {
					windowsHide: true,
					stdio: [
						"ignore",
						"pipe",
						"ignore"
					]
				});
				let out = "";
				child.stdout?.on("data", (b) => out += b.toString("utf8"));
				child.on("error", () => resolve(null));
				child.on("exit", () => {
					const parse = (name) => {
						const m = new RegExp(`^\\s*${name}\\s+REG_\\w+\\s+(.*)$`, "im").exec(out);
						return m ? m[1].trim() : null;
					};
					const enableRaw = parse("ProxyEnable");
					const server = parse("ProxyServer");
					const override = parse("ProxyOverride");
					resolve({
						enable: enableRaw === "0x1" || enableRaw === "1",
						server: server && server !== "<none>" ? server : null,
						override: override && override !== "<none>" ? override : null
					});
				});
				setTimeout(() => resolve(null), 5e3).unref?.();
			} catch {
				resolve(null);
			}
		});
	}
	regWrite(key, name, type, value) {
		return new Promise((resolve) => {
			try {
				const child = (0, node_child_process.spawn)(regExe(), [
					"add",
					key,
					"/v",
					name,
					"/t",
					type,
					"/d",
					value,
					"/f"
				], {
					windowsHide: true,
					stdio: "ignore"
				});
				child.on("exit", (code) => resolve(code === 0));
				child.on("error", () => resolve(false));
				setTimeout(() => resolve(false), 6e3).unref?.();
			} catch {
				resolve(false);
			}
		});
	}
	async testNode(id) {
		const node = this.nodeById(id);
		const base = {
			nodeId: id,
			ok: false,
			delayMs: null,
			exitIp: null,
			country: null,
			error: null
		};
		if (!node) return {
			...base,
			error: "节点不存在"
		};
		const engine = isEngine(node.engine) ? node.engine : this.settings().defaultEngine;
		const bin = findCore(engine);
		if (!bin) return {
			...base,
			error: `未找到 ${CORE_LABELS[engine]} 核心`
		};
		const settings = { ...this.settings() };
		const run = this.running.get(engine);
		const alreadyRunning = run?.child != null && run.nodeId === node.id;
		let port = settings.mixedPort;
		let tempChild = null;
		let tempDir = null;
		if (!alreadyRunning) {
			port = await this.freePort();
			this.logCursor.set(engine, (this.logs.get(engine) ?? []).length);
			const testSettings = {
				...settings,
				mixedPort: port,
				allowLan: false,
				systemProxy: false
			};
			let cfg;
			try {
				cfg = buildCoreConfig(engine, node, testSettings, findRuleSets());
			} catch (e) {
				return {
					...base,
					error: e instanceof Error ? e.message : "配置生成失败"
				};
			}
			tempDir = (0, node_path.join)(electron.app.getPath("temp"), `dola-test-${(0, node_crypto.randomUUID)()}`);
			try {
				(0, node_fs.mkdirSync)(tempDir, { recursive: true });
			} catch {
				return {
					...base,
					error: "无法创建临时目录"
				};
			}
			const cfgPath = (0, node_path.join)(tempDir, configFileName(engine));
			try {
				(0, node_fs.writeFileSync)(cfgPath, cfg, "utf8");
			} catch (e) {
				await removeDir(tempDir);
				return {
					...base,
					error: e instanceof Error ? e.message : "无法写入临时配置"
				};
			}
			if (engine === "mihomo") this.bootstrapGeo(engine, tempDir);
			const env = { ...process.env };
			if (engine === "xray") Object.assign(env, xrayGeoEnv(findGeo().dir));
			try {
				tempChild = (0, node_child_process.spawn)(bin, startArgs(engine, cfgPath, tempDir), {
					cwd: engine === "mihomo" ? tempDir : (0, node_path.join)(bin, ".."),
					windowsHide: true,
					env,
					stdio: [
						"ignore",
						"pipe",
						"pipe"
					]
				});
			} catch (e) {
				await removeDir(tempDir);
				return {
					...base,
					error: e instanceof Error ? e.message : "临时核心启动失败"
				};
			}
			tempChild.stdout?.on("data", (b) => this.onCoreData(engine, b));
			tempChild.stderr?.on("data", (b) => this.onCoreData(engine, b));
			if (!await this.waitForPort(port, HEALTH_TIMEOUT)) {
				await killTree(tempChild);
				await removeDir(tempDir);
				return {
					...base,
					error: "测试用核心启动超时"
				};
			}
		}
		try {
			const delayMs = await this.measureDelay(port);
			const exit = await this.probeExit(port);
			return {
				nodeId: id,
				ok: delayMs !== null,
				delayMs,
				exitIp: exit?.ip ?? null,
				country: exit?.country ?? null,
				error: delayMs === null ? this.diagnose(engine, node) : null
			};
		} catch (e) {
			return {
				...base,
				error: e instanceof Error ? e.message : "测试失败"
			};
		} finally {
			if (tempChild) await killTree(tempChild);
			if (tempDir) await removeDir(tempDir);
		}
	}
	/**
	* Turns the core's own stderr into an explanation the user can act on.
	*
	* "无法通过该节点访问网络" alone is useless when the real reason is a
	* certificate pin mismatch — which is exactly what happens with a Hysteria2
	* link whose pinSHA256 no longer matches the server's public key.
	*/
	diagnose(engine, node) {
		const lines = this.logs.get(engine) ?? [];
		const from = this.logCursor.get(engine) ?? Math.max(0, lines.length - 40);
		const tail = lines.slice(from).slice(-60);
		const has = (re) => {
			for (let i = tail.length - 1; i >= 0; i--) if (re.test(tail[i])) return tail[i];
		};
		if (has(/unrecognized remote public key|certificate_public_key|pin/i)) return `证书公钥不匹配：服务器当前公钥与链接里的 pinSHA256 不一致（服务器可能更换了证书）。可在节点设置中开启「跳过证书校验」后重试`;
		if (has(/certificate|tls:|x509/i)) return "TLS 握手失败：证书校验未通过。可尝试开启「跳过证书校验」，或检查 SNI 是否正确";
		if (has(/i\/o timeout|timeout|deadline exceeded/i)) return "连接超时：节点可能离线，或当前网络阻断了该端口";
		if (has(/connection refused|no route|network is unreachable/i)) return "无法建立连接：节点地址或端口不可达";
		if (node.protocol === "hysteria2" || node.protocol === "tuic") return "节点不可用：Hysteria2/TUIC 使用 UDP，请确认网络允许 UDP 且节点在线";
		const last = has(/ERROR|FATAL|error/i);
		return last ? `节点不可用：${last.replace(/^.*?(ERROR|FATAL)\s*/i, "").slice(0, 160)}` : "无法通过该节点访问网络";
	}
	/**
	* Measures latency through the local proxy.
	*
	* Several endpoints are tried in order, because a single hard-coded one is not a
	* measurement of the NODE: `www.gstatic.com` is reset outright on some routes
	* (observed: ECONNRESET on every attempt through a Hysteria2 node that served
	* youtube fine), so the old implementation reported "测速失败" for a perfectly
	* healthy node. Endpoints that answer give a real number; only when none do is the
	* node actually unusable.
	*
	* The 204 endpoints are used with plain HTTP on purpose: no TLS handshake, so the
	* number reflects the tunnel rather than a session-cache warm-up.
	*/
	async measureDelay(port) {
		const endpoints = [
			{
				host: "www.google.com",
				path: "http://www.google.com/generate_204"
			},
			{
				host: "cp.cloudflare.com",
				path: "http://cp.cloudflare.com/generate_204"
			},
			{
				host: "www.gstatic.com",
				path: "http://www.gstatic.com/generate_204"
			},
			{
				host: "www.bing.com",
				path: "http://www.bing.com/generate_204"
			}
		];
		const results = [];
		for (const ep of endpoints) {
			const ms = await this.timeOnce(port, ep.host, ep.path);
			if (ms !== null) {
				results.push(ms);
				if (results.length >= 2) break;
			}
		}
		if (results.length === 0) return null;
		return Math.min(...results);
	}
	/** One timed request through the proxy; null when it did not get through. */
	timeOnce(port, host, path) {
		return new Promise((resolve) => {
			const started = now();
			let settled = false;
			const done = (v) => {
				if (settled) return;
				settled = true;
				resolve(v);
			};
			try {
				const req = (0, node_http.request)({
					host: "127.0.0.1",
					port,
					method: "GET",
					path,
					headers: {
						Host: host,
						"User-Agent": "Dola Toolkit/1.0",
						Connection: "close"
					},
					timeout: TEST_TIMEOUT
				});
				req.on("response", (res) => {
					res.resume();
					res.on("end", () => done(Math.max(1, now() - started)));
					res.on("error", () => done(null));
				});
				req.on("timeout", () => {
					req.destroy();
					done(null);
				});
				req.on("error", () => done(null));
				req.end();
				setTimeout(() => {
					try {
						req.destroy();
					} catch {}
					done(null);
				}, TEST_TIMEOUT).unref?.();
			} catch {
				done(null);
			}
		});
	}
	/**
	* Looks up the exit IP / country through the node.
	*
	* Several plain-HTTP endpoints are tried in turn: some nodes (or the networks
	* they exit through) block one of them, and a single hard-coded endpoint made
	* the result flip between an IP and "unknown" for no visible reason.
	*/
	async probeExit(port) {
		const probes = [
			{
				path: "http://ip-api.com/json?fields=status,country,query",
				host: "ip-api.com",
				read: (j) => ({
					ip: typeof j.query === "string" ? j.query : null,
					country: typeof j.country === "string" ? j.country : null
				})
			},
			{
				path: "http://ipinfo.io/json",
				host: "ipinfo.io",
				read: (j) => ({
					ip: typeof j.ip === "string" ? j.ip : null,
					country: typeof j.country === "string" ? j.country : null
				})
			},
			{
				path: "http://api.ipify.org/?format=json",
				host: "api.ipify.org",
				read: (j) => ({
					ip: typeof j.ip === "string" ? j.ip : null,
					country: null
				})
			}
		];
		for (const probe of probes) {
			const got = await this.getJson(port, probe.path, probe.host);
			if (!got) continue;
			const parsed = probe.read(got);
			if (parsed?.ip) return parsed;
		}
		return null;
	}
	/** Tiny HTTP GET through the local proxy port, JSON-decoded. */
	getJson(port, path, host) {
		return new Promise((resolve) => {
			let settled = false;
			const done = (v) => {
				if (settled) return;
				settled = true;
				resolve(v);
			};
			try {
				const req = (0, node_http.request)({
					host: "127.0.0.1",
					port,
					method: "GET",
					path,
					headers: {
						Host: host,
						"User-Agent": "Dola Toolkit/1.0",
						Accept: "application/json"
					},
					timeout: 6e3
				});
				req.on("response", (res) => {
					let body = "";
					res.setEncoding("utf8");
					res.on("data", (c) => {
						if (body.length < 8192) body += c;
					});
					res.on("end", () => {
						try {
							done(JSON.parse(body));
						} catch {
							done(null);
						}
					});
				});
				req.on("timeout", () => {
					req.destroy();
					done(null);
				});
				req.on("error", () => done(null));
				req.end();
				setTimeout(() => {
					try {
						req.destroy();
					} catch {}
					done(null);
				}, 6e3).unref?.();
			} catch {
				done(null);
			}
		});
	}
	freePort() {
		const tryOnce = (candidate) => new Promise((resolve, reject) => {
			const srv = (0, node_http.createServer)();
			srv.once("error", () => reject(/* @__PURE__ */ new Error("busy")));
			srv.listen(candidate, "127.0.0.1", () => {
				const addr = srv.address();
				const port = typeof addr === "object" && addr ? addr.port : candidate;
				srv.close(() => resolve(port));
			});
		});
		return (async () => {
			for (let i = 0; i < 24; i++) {
				const candidate = this.testPortCursor;
				this.testPortCursor = this.testPortCursor >= 18980 ? 18080 : this.testPortCursor + 7;
				try {
					return await tryOnce(candidate);
				} catch {}
			}
			return tryOnce(0);
		})();
	}
	geoState() {
		const geo = findGeo();
		return {
			geoip: geoFileInfo(geo.geoip),
			geosite: geoFileInfo(geo.geosite),
			dir: geo.dir
		};
	}
	async importGeo() {
		const targetDir = geoDir();
		try {
			(0, node_fs.mkdirSync)(targetDir, { recursive: true });
		} catch {}
		const picked = await electron.dialog.showOpenDialog({
			title: "选择 geoip.dat / geosite.dat",
			properties: ["openFile", "multiSelections"],
			filters: [{
				name: "Geo 数据",
				extensions: ["dat"]
			}]
		});
		if (picked.canceled || picked.filePaths.length === 0) return this.state();
		for (const file of picked.filePaths) {
			const name = (0, node_path.basename)(file).toLowerCase();
			if (name !== "geoip.dat" && name !== "geosite.dat") continue;
			try {
				copyAtomic(file, (0, node_path.join)(targetDir, name));
			} catch (e) {
				this.appendLog(this.activeEngine, `[dola] 导入 ${name} 失败: ${e instanceof Error ? e.message : String(e)}`);
			}
		}
		clearBinaryCache();
		this.emitState();
		return this.state();
	}
	async updateGeo() {
		const targetDir = geoDir();
		try {
			(0, node_fs.mkdirSync)(targetDir, { recursive: true });
		} catch {}
		const sources = ["https://github.com/Loyalsoldier/v2ray-rules-dat/releases/download/latest", "https://cdn.jsdelivr.net/gh/Loyalsoldier/v2ray-rules-dat@release"];
		const names = ["geoip.dat", "geosite.dat"];
		let okCount = 0;
		for (const name of names) {
			let succeeded = false;
			for (const base of sources) try {
				const buf = await download(`${base}/${name}`);
				if (buf.length < 1024) throw new Error("下载内容异常");
				copyAtomicBuffer(buf, (0, node_path.join)(targetDir, name));
				succeeded = true;
				okCount++;
				this.appendLog(this.activeEngine, `[dola] ${name} 已更新 (${fmtSize(buf.length)})`);
				break;
			} catch (e) {
				this.appendLog(this.activeEngine, `[dola] 从 ${hostOf(base)} 下载 ${name} 失败: ${e instanceof Error ? e.message : String(e)}`);
			}
			if (!succeeded) this.appendLog(this.activeEngine, `[dola] ${name} 更新失败，保留旧文件`);
		}
		if (okCount > 0) clearBinaryCache();
		this.emitState();
		return this.state();
	}
};
function isEngine(v) {
	return v === "xray" || v === "singbox" || v === "mihomo";
}
function baseNode() {
	return {
		id: "",
		name: "",
		protocol: "vmess",
		engine: "xray",
		server: "",
		port: 443,
		enabled: true,
		createdAt: 0,
		updatedAt: 0
	};
}
var PROTOCOLS = [
	"vmess",
	"vless",
	"trojan",
	"shadowsocks",
	"socks",
	"http",
	"hysteria2",
	"tuic",
	"anytls",
	"wireguard"
];
function sanitizeDraft(draft) {
	const out = {};
	if (typeof draft.name === "string") out.name = draft.name.trim().slice(0, 120);
	if (draft.protocol && PROTOCOLS.includes(draft.protocol)) out.protocol = draft.protocol;
	if (isEngine(draft.engine)) out.engine = draft.engine;
	if (typeof draft.server === "string") out.server = draft.server.trim();
	const portNum = Number(draft.port);
	if (Number.isFinite(portNum) && portNum > 0 && portNum < 65536) out.port = Math.round(portNum);
	for (const key of [
		"uuid",
		"password",
		"method",
		"flow",
		"sni",
		"alpn",
		"fingerprint",
		"pinSHA256",
		"publicKey",
		"shortId",
		"spiderX",
		"path",
		"host",
		"serviceName",
		"obfs",
		"obfsParam",
		"extra",
		"remark",
		"group"
	]) {
		const v = draft[key];
		if (typeof v === "string") out[key] = v;
	}
	if (draft.security) {
		const sec = draft.security;
		if (sec === "none" || sec === "tls" || sec === "reality" || sec === "auto") out.security = sec;
	}
	if (typeof draft.allowInsecure === "boolean") out.allowInsecure = draft.allowInsecure;
	if (draft.network) {
		const nw = draft.network;
		if ([
			"tcp",
			"ws",
			"grpc",
			"http",
			"h2",
			"quic"
		].includes(nw)) out.network = nw;
	}
	const alterId = Number(draft.alterId);
	if (Number.isFinite(alterId)) out.alterId = Math.max(0, Math.round(alterId));
	for (const key of ["upMbps", "downMbps"]) {
		const v = Number(draft[key]);
		if (Number.isFinite(v) && v >= 0) out[key] = Math.round(v);
	}
	if (typeof draft.enabled === "boolean") out.enabled = draft.enabled;
	if (!out.name && out.server) out.name = `${out.server}`;
	return out;
}
function truncate(s) {
	return s.length > 160 ? `${s.slice(0, 157)}…` : s;
}
function fmtSize(n) {
	if (n > 1048576) return `${(n / 1024 / 1024).toFixed(1)} MB`;
	if (n > 1024) return `${(n / 1024).toFixed(0)} KB`;
	return `${n} B`;
}
function hostOf(url) {
	try {
		return new URL(url).host;
	} catch {
		return url;
	}
}
/** Windows wants `<local>` first and semicolon separators. */
function normalizeBypass(raw) {
	const parts = String(raw || "").split(/[;,]/).map((s) => s.trim()).filter(Boolean);
	if (!parts.some((p) => p === "<local>")) parts.unshift("<local>");
	return parts.join(";");
}
/**
* Tell Windows the WinINET settings changed.
*
* Writing ProxyEnable/ProxyServer to the registry is NOT enough: WinINET caches
* the configuration per process and only reloads it when an app calls
* InternetSetOption(INTERNET_OPTION_SETTINGS_CHANGED / _REFRESH). Without that
* call the UI can show "系统代理已开启" while every app keeps using the old
* (or no) proxy — exactly the "UI 是亮的但无法代理" symptom.
*
* We therefore do it in-process via a tiny PowerShell shim, but resolve the
* interpreter explicitly: `powershell.exe` is frequently absent from PATH (this
* machine only has PowerShell 7, whose binary is `pwsh.exe`), and the old code
* silently swallowed that spawn failure.
*/
async function notifyInternetSettingsChanged() {
	if (process.platform !== "win32") return;
	for (const exe of resolvePowerShellCandidates()) if (await runPowerShell(exe)) return;
	await new Promise((resolve) => {
		let settled = false;
		const done = () => {
			if (settled) return;
			settled = true;
			resolve();
		};
		try {
			const child = (0, node_child_process.spawn)("rundll32.exe", ["user32.dll,UpdatePerUserSystemParameters"], {
				windowsHide: true,
				stdio: "ignore"
			});
			child.on("exit", done);
			child.on("error", done);
		} catch {
			done();
		}
		setTimeout(done, 4e3).unref?.();
	});
}
/** Every PowerShell we can plausibly launch, most-preferred first. */
function resolvePowerShellCandidates() {
	const win = process.env["SystemRoot"] ?? process.env["windir"] ?? "C:\\Windows";
	const out = [];
	const legacy = (0, node_path.join)(win, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
	if ((0, node_fs.existsSync)(legacy)) out.push(legacy);
	out.push("pwsh.exe", "powershell.exe");
	return out;
}
/** Run the InternetSetOption shim in one interpreter; true when it executed. */
function runPowerShell(exe) {
	return new Promise((resolve) => {
		const script = [
			"$sig = '[DllImport(\"wininet.dll\", SetLastError=true)] public static extern bool InternetSetOption(IntPtr h, int o, IntPtr b, int l);'",
			"$t = Add-Type -MemberDefinition $sig -Name WinINet -Namespace Dola Toolkit -PassThru",
			"foreach ($o in 39,37) { [void]$t::InternetSetOption([IntPtr]::Zero, $o, [IntPtr]::Zero, 0) }"
		].join("; ");
		let settled = false;
		const done = (ok) => {
			if (settled) return;
			settled = true;
			resolve(ok);
		};
		try {
			const child = (0, node_child_process.spawn)(exe, [
				"-NoProfile",
				"-NonInteractive",
				"-WindowStyle",
				"Hidden",
				"-Command",
				script
			], {
				windowsHide: true,
				stdio: "ignore"
			});
			child.on("exit", (code) => done(code === 0));
			child.on("error", () => done(false));
			setTimeout(() => done(false), 8e3).unref?.();
		} catch {
			done(false);
		}
	});
}
function killTree(child) {
	const pid = child.pid;
	return new Promise((resolve) => {
		if (!pid) return resolve();
		if (process.platform === "win32") {
			try {
				const killer = (0, node_child_process.spawn)("taskkill", [
					"/PID",
					String(pid),
					"/T",
					"/F"
				], {
					windowsHide: true,
					stdio: "ignore"
				});
				killer.on("exit", () => resolve());
				killer.on("error", () => {
					try {
						child.kill();
					} catch {}
					resolve();
				});
			} catch {
				resolve();
			}
			return;
		}
		try {
			child.kill("SIGKILL");
		} catch {}
		resolve();
	});
}
async function removeDir(dir) {
	try {
		(0, node_fs.rmSync)(dir, {
			recursive: true,
			force: true
		});
	} catch {
		await delay(50);
		try {
			(0, node_fs.rmSync)(dir, {
				recursive: true,
				force: true
			});
		} catch {}
	}
}
function copyAtomicBuffer(buf, target) {
	const tmp = `${target}.${process.pid}.tmp`;
	(0, node_fs.writeFileSync)(tmp, buf);
	(0, node_fs.renameSync)(tmp, target);
}
function copyAtomic(from, to) {
	copyAtomicBuffer((0, node_fs.readFileSync)(from), to);
}
function download(url, timeoutMs = 45e3) {
	return new Promise((resolve, reject) => {
		const go = (target, redirects) => {
			if (redirects > 5) return reject(/* @__PURE__ */ new Error("重定向过多"));
			const req = httpsGet$1(target, timeoutMs, (res) => {
				if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
					res.resume();
					const next = new URL(res.headers.location, target).toString();
					return go(next, redirects + 1);
				}
				if (res.statusCode !== 200) {
					res.resume();
					return reject(/* @__PURE__ */ new Error(`HTTP ${res.statusCode}`));
				}
				const chunks = [];
				let size = 0;
				res.on("data", (c) => {
					size += c.length;
					if (size > 268435456) {
						req.destroy();
						return reject(/* @__PURE__ */ new Error("文件过大"));
					}
					chunks.push(c);
				});
				res.on("end", () => resolve(Buffer.concat(chunks)));
				res.on("error", reject);
			});
			req.on("error", reject);
			req.end();
		};
		go(url, 0);
	});
}
function httpsGet$1(url, timeoutMs, onResponse) {
	const req = (url.startsWith("https:") ? require("node:https") : require("node:http")).get(url, {
		timeout: timeoutMs,
		headers: { "User-Agent": "Dola Toolkit/1.0" }
	}, onResponse);
	req.on("timeout", () => req.destroy(/* @__PURE__ */ new Error("请求超时")));
	return req;
}
function parseShareLink(line) {
	const trimmed = line.trim();
	if (!trimmed) return null;
	if (trimmed.startsWith("{")) return parseJsonNode(trimmed);
	const m = /^([a-zA-Z0-9+]+):\/\/(.*)$/s.exec(trimmed);
	if (!m) return null;
	const scheme = m[1].toLowerCase();
	const rest = m[2];
	switch (scheme) {
		case "vmess": return parseVmess(rest);
		case "vless": return parseVless(rest);
		case "trojan": return parseTrojan(rest);
		case "ss": return parseShadowsocks(rest);
		case "hysteria2":
		case "hy2": return parseHysteria2(rest);
		case "tuic": return parseTuic(rest);
		case "socks":
		case "socks5":
		case "socks4": return parseUserPass(rest, "socks", "SOCKS");
		case "http":
		case "https": return parseUserPass(rest, "http", "HTTP");
		default: return null;
	}
}
function b64decode(s) {
	const cleaned = s.replace(/-/g, "+").replace(/_/g, "/").replace(/\s/g, "");
	return Buffer.from(cleaned, "base64").toString("utf8");
}
function urlParts(rest) {
	const hashIndex = rest.indexOf("#");
	const beforeHash = hashIndex >= 0 ? rest.slice(0, hashIndex) : rest;
	const rawName = hashIndex >= 0 ? rest.slice(hashIndex + 1) : "";
	return {
		url: new URL(`scheme://${beforeHash}`),
		name: safeDecode(rawName)
	};
}
function safeDecode(s) {
	try {
		return decodeURIComponent(s);
	} catch {
		return s;
	}
}
function parseJsonNode(text) {
	let obj;
	try {
		obj = JSON.parse(text);
	} catch {
		return null;
	}
	const protocol = typeof obj.protocol === "string" ? obj.protocol : "vmess";
	if (!PROTOCOLS.includes(protocol)) return null;
	return {
		name: typeof obj.name === "string" ? obj.name : "导入节点",
		protocol,
		engine: isEngine(obj.engine) ? obj.engine : defaultEngineFor(protocol),
		server: typeof obj.server === "string" ? obj.server : "",
		port: Number(obj.port) || 443,
		uuid: typeof obj.uuid === "string" ? obj.uuid : void 0,
		password: typeof obj.password === "string" ? obj.password : void 0,
		method: typeof obj.method === "string" ? obj.method : void 0,
		security: normalizeSecurity(obj.security),
		sni: typeof obj.sni === "string" ? obj.sni : typeof obj.servername === "string" ? obj.servername : void 0,
		network: normalizeNet(obj.network),
		path: typeof obj.path === "string" ? obj.path : void 0,
		host: typeof obj.host === "string" ? obj.host : void 0,
		flow: typeof obj.flow === "string" ? obj.flow : void 0
	};
}
function normalizeSecurity(v) {
	return v === "tls" || v === "reality" || v === "none" ? v : void 0;
}
function normalizeNet(v) {
	if (typeof v !== "string") return void 0;
	const nw = v.toLowerCase();
	if (nw === "tcp" || nw === "ws" || nw === "grpc" || nw === "http" || nw === "h2" || nw === "quic") return nw;
}
function defaultEngineFor(p) {
	if (p === "hysteria2" || p === "tuic" || p === "anytls") return "singbox";
	if (p === "wireguard") return "mihomo";
	return "xray";
}
function parseVmess(rest) {
	let raw;
	try {
		raw = JSON.parse(b64decode(rest));
	} catch {
		return null;
	}
	const host = strOf(raw.add) || strOf(raw.address);
	const port = Number(raw.port);
	if (!host || !Number.isFinite(port)) return null;
	const tls = strOf(raw.tls);
	const net = normalizeNet(raw.net);
	const streamHost = strOf(raw.host);
	const tlsField = tls === "tls" || tls === "reality";
	return {
		name: strOf(raw.ps) || `${host}:${port}`,
		protocol: "vmess",
		engine: "xray",
		server: host,
		port,
		uuid: strOf(raw.id),
		alterId: Number(raw.aid) || 0,
		security: tlsField ? tls === "reality" ? "reality" : "tls" : "none",
		sni: strOf(raw.sni) || streamHost || void 0,
		alpn: strOf(raw.alpn) || void 0,
		fingerprint: strOf(raw.fp) || void 0,
		publicKey: strOf(raw.pbk) || void 0,
		shortId: strOf(raw.sid) || void 0,
		spiderX: strOf(raw.spx) || void 0,
		network: net,
		path: strOf(raw.path) || void 0,
		host: streamHost || void 0,
		serviceName: strOf(raw.serviceName) || void 0
	};
}
function parseVlessV2(rest) {
	const { url, name } = urlParts(rest);
	const uuid = url.username ? safeDecode(url.username) : "";
	const port = Number(url.port);
	if (!url.hostname || !uuid || !Number.isFinite(port)) return null;
	const q = url.searchParams;
	const security = normalizeSecurity(q.get("security"));
	return {
		name: name || `${url.hostname}:${port}`,
		protocol: "vless",
		engine: "xray",
		server: url.hostname,
		port,
		uuid,
		flow: q.get("flow") ?? void 0,
		security: security ?? "none",
		sni: q.get("sni") ?? q.get("peer") ?? void 0,
		alpn: q.get("alpn") ?? void 0,
		fingerprint: q.get("fp") ?? void 0,
		publicKey: q.get("pbk") ?? void 0,
		shortId: q.get("sid") ?? void 0,
		spiderX: q.get("spx") ?? void 0,
		network: normalizeNet(q.get("type")),
		path: q.get("path") ?? void 0,
		host: q.get("host") ?? void 0,
		serviceName: q.get("serviceName") ?? void 0
	};
}
function parseVless(rest) {
	return parseVlessV2(rest);
}
function parseTrojan(rest) {
	const { url, name } = urlParts(rest);
	const port = Number(url.port);
	if (!url.hostname || !Number.isFinite(port)) return null;
	const q = url.searchParams;
	return {
		name: name || `${url.hostname}:${port}`,
		protocol: "trojan",
		engine: "xray",
		server: url.hostname,
		port,
		password: safeDecode(url.password || url.username || ""),
		security: "tls",
		sni: q.get("sni") ?? q.get("peer") ?? void 0,
		alpn: q.get("alpn") ?? void 0,
		fingerprint: q.get("fp") ?? void 0,
		network: normalizeNet(q.get("type")),
		path: q.get("path") ?? void 0,
		host: q.get("host") ?? void 0,
		serviceName: q.get("serviceName") ?? void 0
	};
}
function parseShadowsocks(rest) {
	const hashIndex = rest.indexOf("#");
	const beforeHash = hashIndex >= 0 ? rest.slice(0, hashIndex) : rest;
	const name = hashIndex >= 0 ? safeDecode(rest.slice(hashIndex + 1)) : "";
	const atIndex = beforeHash.lastIndexOf("@");
	let method = "";
	let password = "";
	let host = "";
	let port = 0;
	let query = "";
	if (atIndex > 0) {
		const credPart = beforeHash.slice(0, atIndex);
		const cred = credPart.includes(":") ? safeDecode(credPart) : b64decode(credPart);
		const sep = cred.indexOf(":");
		if (sep <= 0) return null;
		method = cred.slice(0, sep);
		password = cred.slice(sep + 1);
		const hostPart = beforeHash.slice(atIndex + 1);
		const qIdx = hostPart.indexOf("?");
		query = qIdx >= 0 ? hostPart.slice(qIdx + 1) : "";
		const hp = qIdx >= 0 ? hostPart.slice(0, qIdx) : hostPart;
		const lastColon = hp.lastIndexOf(":");
		if (lastColon <= 0) return null;
		host = hp.slice(0, lastColon).replace(/^\[|\]$/g, "");
		port = Number(hp.slice(lastColon + 1));
	} else {
		const decoded = b64decode(beforeHash);
		const at = decoded.lastIndexOf("@");
		if (at <= 0) return null;
		const cred = decoded.slice(0, at);
		const hp = decoded.slice(at + 1);
		const sep = cred.indexOf(":");
		if (sep <= 0) return null;
		method = cred.slice(0, sep);
		password = cred.slice(sep + 1);
		const qIdx = hp.indexOf("?");
		query = qIdx >= 0 ? hp.slice(qIdx + 1) : "";
		const hostPort = qIdx >= 0 ? hp.slice(0, qIdx) : hp;
		const lastColon = hostPort.lastIndexOf(":");
		if (lastColon <= 0) return null;
		host = hostPort.slice(0, lastColon).replace(/^\[|\]$/g, "");
		port = Number(hostPort.slice(lastColon + 1));
	}
	if (!host || !Number.isFinite(port) || port <= 0) return null;
	const pluginParts = (new URLSearchParams(query).get("plugin") ?? "").split(";");
	const obfs = pluginParts[0] && /obfs/i.test(pluginParts[0]) ? "http" : void 0;
	return {
		name: name || `${host}:${port}`,
		protocol: "shadowsocks",
		engine: "xray",
		server: host,
		port,
		method,
		password,
		security: "none",
		obfs,
		obfsParam: obfs ? pluginParts.slice(1).find((p) => p.startsWith("host="))?.slice(5) : void 0
	};
}
/** Hysteria2 pinSHA256 is hex; accept it with or without separators/case. */
function normalizePin(raw) {
	if (!raw) return void 0;
	const hex = raw.replace(/[^0-9a-fA-F]/g, "").toUpperCase();
	return hex.length === 64 ? hex : void 0;
}
function parseHysteria2(rest) {
	const { url, name } = urlParts(rest);
	const port = Number(url.port);
	if (!url.hostname || !Number.isFinite(port)) return null;
	const q = url.searchParams;
	const password = safeDecode(url.password || url.username || "") || (q.get("auth") ?? "");
	return {
		name: name || `${url.hostname}:${port}`,
		protocol: "hysteria2",
		engine: "singbox",
		server: url.hostname,
		port,
		password,
		security: "tls",
		sni: q.get("sni") ?? void 0,
		alpn: q.get("alpn") ?? void 0,
		allowInsecure: /^(1|true|yes)$/i.test(q.get("insecure") ?? q.get("allowInsecure") ?? q.get("skip-cert-verify") ?? ""),
		pinSHA256: normalizePin(q.get("pinSHA256") ?? q.get("pin") ?? q.get("pinsha256")),
		obfs: q.get("obfs") ?? void 0,
		obfsParam: q.get("obfs-password") ?? void 0,
		upMbps: q.get("up") ? Number(q.get("up")) / 1e6 : void 0,
		downMbps: q.get("down") ? Number(q.get("down")) / 1e6 : void 0
	};
}
function parseTuic(rest) {
	const { url, name } = urlParts(rest);
	const port = Number(url.port);
	if (!url.hostname || !Number.isFinite(port)) return null;
	const q = url.searchParams;
	return {
		name: name || `${url.hostname}:${port}`,
		protocol: "tuic",
		engine: "singbox",
		server: url.hostname,
		port,
		uuid: url.username ? safeDecode(url.username) : void 0,
		password: url.password ? safeDecode(url.password) : q.get("password") ?? void 0,
		security: "tls",
		sni: q.get("sni") ?? void 0,
		alpn: q.get("alpn") ?? "h3"
	};
}
function parseUserPass(rest, protocol, label) {
	const { url, name } = urlParts(rest);
	const port = Number(url.port);
	if (!url.hostname || !Number.isFinite(port)) return null;
	return {
		name: name || `${label} ${url.hostname}:${port}`,
		protocol,
		engine: "xray",
		server: url.hostname,
		port,
		uuid: url.username ? safeDecode(url.username) : void 0,
		password: url.password ? safeDecode(url.password) : void 0,
		security: "none"
	};
}
function strOf(v) {
	return typeof v === "string" ? v : "";
}
var managerInstance = null;
/** The shared manager; created on first use, after the host was injected. */
function proxyManagerRef() {
	if (!managerInstance) managerInstance = new ProxyManager();
	return managerInstance;
}
//#endregion
//#region mods/proxy/main/net.ts
/**
* https agent that tunnels through an HTTP proxy (the app's mixed inbound).
*
* Node does not honour HTTP_PROXY on its own and there is no third-party proxy
* agent in this project, so the CONNECT handshake and the TLS layer on top of it
* are done by hand. Subclassing Agent rather than passing `createConnection` in
* the options keeps TypeScript happy (it is a class method, not an AgentOption).
*/
var ProxyHttpsAgent = class extends node_https.Agent {
	proxyPort;
	constructor(proxyPort) {
		super({ keepAlive: false });
		this.proxyPort = proxyPort;
	}
	createConnection(options, callback) {
		const done = (err, socket) => callback?.(err, socket);
		const host = String(options.host ?? "");
		const targetPort = Number(options.port) || 443;
		const connect = node_http.request({
			host: "127.0.0.1",
			port: this.proxyPort,
			method: "CONNECT",
			path: `${host}:${targetPort}`,
			timeout: 2e4,
			headers: { Host: `${host}:${targetPort}` }
		});
		connect.on("connect", (res, socket) => {
			if (res.statusCode !== 200) {
				socket.destroy();
				done(/* @__PURE__ */ new Error(`代理未建立隧道 (HTTP ${res.statusCode})`));
				return;
			}
			const secured = node_tls.connect({
				socket,
				servername: host
			}, () => done(null, secured));
			secured.on("error", (e) => done(e));
		});
		connect.on("timeout", () => connect.destroy(/* @__PURE__ */ new Error("代理连接超时")));
		connect.on("error", (e) => done(e));
		connect.end();
	}
};
function proxyAgent(port) {
	return new ProxyHttpsAgent(port);
}
function httpsGet(url, timeoutMs, onResponse, options = {}) {
	const isHttps = url.startsWith("https:");
	const mod = isHttps ? node_https : node_http;
	const agent = isHttps && options.proxyPort ? proxyAgent(options.proxyPort) : void 0;
	const req = mod.get(url, {
		timeout: timeoutMs,
		agent,
		headers: {
			"User-Agent": "Dola Toolkit/1.0",
			"Accept-Language": "zh-CN,zh;q=0.9",
			...options.headers
		}
	}, onResponse);
	req.on("timeout", () => req.destroy(/* @__PURE__ */ new Error("请求超时")));
	return req;
}
//#endregion
//#region mods/proxy/main/coreStage.ts
var LABELS = {
	xray: "Xray",
	singbox: "sing-box",
	mihomo: "Mihomo"
};
/** File name each engine's binary must end up with (what findCore looks for). */
function targetExeName(engine) {
	return engine === "singbox" ? "sing-box.exe" : `${engine}.exe`;
}
/** Folder name each engine lives in under the cores root. */
function engineFolder(engine) {
	return engine === "singbox" ? "singbox" : engine;
}
function stagingRoot() {
	const dir = (0, node_path.join)(electron.app.getPath("userData"), "updates", "staged");
	(0, node_fs.mkdirSync)(dir, { recursive: true });
	return dir;
}
function manifestPath() {
	return (0, node_path.join)(electron.app.getPath("userData"), "updates", "staged-cores.json");
}
function writeStagedCores(list) {
	try {
		if (list.length === 0) {
			(0, node_fs.rmSync)(manifestPath(), { force: true });
			return;
		}
		(0, node_fs.writeFileSync)(manifestPath(), JSON.stringify(list, null, 2));
	} catch {}
}
/** Reads the staged manifest, dropping entries whose file vanished. */
function readStagedCores() {
	let parsed;
	try {
		const raw = (0, node_fs.readFileSync)(manifestPath(), "utf8");
		const value = JSON.parse(raw);
		if (!Array.isArray(value)) return [];
		parsed = value;
	} catch {
		return [];
	}
	const alive = parsed.filter((s) => s && typeof s.stagedPath === "string" && (0, node_fs.existsSync)(s.stagedPath));
	if (alive.length !== parsed.length) writeStagedCores(alive);
	return alive;
}
function hasStagedCores() {
	return readStagedCores().length > 0;
}
/** SHA-256 of a file as lowercase hex. */
function fileSha256(path) {
	return new Promise((resolve, reject) => {
		const hash = (0, node_crypto.createHash)("sha256");
		const rs = (0, node_fs.createReadStream)(path);
		rs.on("data", (c) => hash.update(c));
		rs.on("end", () => resolve(hash.digest("hex")));
		rs.on("error", reject);
	});
}
function findFile(dir, name) {
	for (const entry of (0, node_fs.readdirSync)(dir, { withFileTypes: true })) {
		const full = (0, node_path.join)(dir, entry.name);
		if (entry.isDirectory()) {
			const nested = findFile(full, name);
			if (nested) return nested;
		} else if (entry.name.toLowerCase() === name.toLowerCase()) return full;
	}
	return null;
}
function findFileMatch(dir, pattern) {
	for (const entry of (0, node_fs.readdirSync)(dir, { withFileTypes: true })) {
		const full = (0, node_path.join)(dir, entry.name);
		if (entry.isDirectory()) {
			const nested = findFileMatch(full, pattern);
			if (nested) return nested;
		} else if (pattern.test(entry.name)) return full;
	}
	return null;
}
/**
* Where this engine's binary actually lives.
*
* `coreRoots()[0]` is NOT the right answer: in a packaged build it is
* `<resources>/cores`, which usually does not exist, while the real cores sit in a
* `cores` folder next to the executable. Writing there created a second tree that
* `findCore` then preferred, so the "update" never replaced the binary that was
* actually being launched. The existing binary's own location wins when there is one,
* and `coresDirFor` (which probes the same list findCore uses) decides otherwise.
*/
/**
* Moves a file, falling back to copy+delete across volumes.
*
* The staging folder lives in userData (usually on C:) while the cores can sit on
* another drive — `renameSync` throws EXDEV there, and that failure used to abort the
* apply silently, leaving the old core in place after a "successful" update.
*/
function moveFile(from, to) {
	try {
		(0, node_fs.renameSync)(from, to);
	} catch (e) {
		const code = e.code;
		if (code !== "EXDEV" && code !== "EPERM" && code !== "EACCES") throw e;
		(0, node_fs.copyFileSync)(from, to);
		(0, node_fs.unlinkSync)(from);
	}
}
function resolveTargetPath(engine) {
	const existing = findCore(engine);
	if (existing) return existing;
	return (0, node_path.join)(coresDirFor(engine), engineFolder(engine), targetExeName(engine));
}
/** True when the file starts with an MZ header, i.e. it is a Windows executable. */
async function hasMzHeader(path) {
	const { open } = await import("node:fs/promises");
	const handle = await open(path, "r");
	try {
		const buf = Buffer.alloc(2);
		await handle.read(buf, 0, 2, 0);
		return buf[0] === 77 && buf[1] === 90;
	} finally {
		await handle.close();
	}
}
/**
* Downloads, verifies and extracts one core release into the staging folder.
*
* Every rejection happens before anything is staged, so the caller can always turn a
* throw into「请重新下载」rather than a restart prompt.
*/
async function stageCore(options) {
	const { engine, version, url, expectedSha256, onProgress, download } = options;
	const dir = (0, node_path.join)(stagingRoot(), `${engine}-${Date.now()}`);
	(0, node_fs.mkdirSync)(dir, { recursive: true });
	const archive = (0, node_path.join)(dir, "core.zip");
	const cleanup = () => (0, node_fs.rmSync)(dir, {
		recursive: true,
		force: true
	});
	try {
		await download(url, archive, (got, total) => {
			if (total > 0) onProgress(Math.min(100, Math.round(got / total * 100)));
		});
		if (!(0, node_fs.existsSync)(archive)) throw new Error("下载未完成，请重新下载");
		const size = (0, node_fs.statSync)(archive).size;
		if (size < 1048576) throw new Error(`下载的文件过小（${Math.round(size / 1024)} KB），可能已损坏，请重新下载`);
		const archiveSha = await fileSha256(archive);
		if (expectedSha256 && archiveSha.toLowerCase() !== expectedSha256.toLowerCase()) throw new Error(`SHA-256 校验失败，下载的文件已损坏。\n期望：${expectedSha256.slice(0, 16)}…\n实际：${archiveSha.slice(0, 16)}…\n请重新下载`);
		const tarExe = (0, node_path.join)(process.env["SystemRoot"] || "C:\\Windows", "System32", "tar.exe");
		await new Promise((resolve, reject) => {
			const child = (0, node_child_process.spawn)(tarExe, [
				"-xf",
				archive,
				"-C",
				dir
			], {
				windowsHide: true,
				stdio: "ignore"
			});
			child.on("error", reject);
			child.on("exit", (code) => code === 0 ? resolve() : reject(/* @__PURE__ */ new Error(`解压失败 (${code})`)));
		});
		const exe = findFile(dir, targetExeName(engine)) ?? findFileMatch(dir, new RegExp(`^${engine}.*\\.exe$`, "i")) ?? findFileMatch(dir, /^mihomo.*\.exe$/i);
		if (!exe) throw new Error("压缩包里没有内核实执行文件，请重新下载");
		if (!await hasMzHeader(exe)) throw new Error("解压出的文件不是有效的可执行文件，请重新下载");
		const stagedPath = (0, node_path.join)(dir, targetExeName(engine));
		if (stagedPath !== exe) {
			(0, node_fs.rmSync)(stagedPath, { force: true });
			(0, node_fs.renameSync)(exe, stagedPath);
		}
		(0, node_fs.rmSync)(archive, { force: true });
		const exeSha = await fileSha256(stagedPath);
		const record = {
			engine,
			label: LABELS[engine],
			version,
			stagedPath,
			targetPath: resolveTargetPath(engine),
			size: (0, node_fs.statSync)(stagedPath).size,
			sha256: exeSha,
			at: Date.now()
		};
		const list = readStagedCores().filter((s) => s.engine !== engine);
		list.push(record);
		writeStagedCores(list);
		return record;
	} catch (e) {
		cleanup();
		throw e;
	}
}
/**
* Applies every staged binary and clears the manifest.
*
* Runs on launch before any core can start, so no file is locked. The staged file is
* re-hashed here too: it sat on disk between sessions and anything that damaged it
* must be caught before it replaces a working core.
*/
async function applyStagedCores() {
	const list = readStagedCores();
	const applied = [];
	const failed = [];
	if (list.length === 0) return {
		applied,
		failed
	};
	/** entries that could not be applied but are still worth retrying */
	const keep = [];
	for (const item of list) try {
		if (!(0, node_fs.existsSync)(item.stagedPath)) throw new Error("暂存文件已丢失");
		if ((await fileSha256(item.stagedPath)).toLowerCase() !== item.sha256.toLowerCase()) throw new Error("暂存文件校验失败");
		if (!await hasMzHeader(item.stagedPath)) throw new Error("暂存文件不是有效的可执行文件");
		const target = resolveTargetPath(item.engine);
		(0, node_fs.mkdirSync)((0, node_path.join)(target, ".."), { recursive: true });
		(0, node_fs.rmSync)(`${target}.bak`, { force: true });
		if ((0, node_fs.existsSync)(target)) moveFile(target, `${target}.bak`);
		moveFile(item.stagedPath, target);
		invalidateCoreVersion(item.engine);
		applied.push(`${item.label} ${item.version}`);
		(0, node_fs.rmSync)((0, node_path.join)(item.stagedPath, ".."), {
			recursive: true,
			force: true
		});
	} catch (e) {
		const message = e instanceof Error ? e.message : "替换失败";
		failed.push({
			engine: item.label,
			error: message
		});
		if ((0, node_fs.existsSync)(item.stagedPath) && !/校验失败|不是有效/.test(message)) keep.push(item);
	}
	writeStagedCores(keep);
	return {
		applied,
		failed
	};
}
//#endregion
//#region mods/proxy/main/coreUpdate.ts
var CORE_REPOS = {
	xray: {
		owner: "XTLS",
		repo: "Xray-core",
		label: "Xray",
		asset: /^Xray-windows-64\.zip$/,
		exe: "xray.exe"
	},
	singbox: {
		owner: "SagerNet",
		repo: "sing-box",
		label: "sing-box",
		asset: /^sing-box-[\d.]+-windows-amd64\.zip$/,
		exe: "sing-box.exe"
	},
	mihomo: {
		owner: "MetaCubeX",
		repo: "mihomo",
		label: "Mihomo",
		asset: /^mihomo-windows-amd64(-compatible)?(-v[\d.]+)?\.zip$/,
		exe: "mihomo.exe"
	}
};
var ENGINE_KEYS = [
	"xray",
	"singbox",
	"mihomo"
];
var USER_AGENT = "DolaToolkit-CoreUpdater";
/** Only used to pick where the bytes come from; metadata always comes from the API. */
var channelOverride = "github";
function setUpdateChannel(channel) {
	channelOverride = channel === "mirror" ? "mirror" : "github";
}
var MIRROR_PREFIX = "https://gh-proxy.com/";
async function fetchText(url, proxyPort, timeoutMs = 15e3) {
	return new Promise((resolve, reject) => {
		const req = httpsGet(url, timeoutMs, (res) => {
			let body = "";
			res.setEncoding("utf8");
			res.on("data", (c) => {
				if (body.length < 4e6) body += c;
			});
			res.on("end", () => resolve(body));
			res.on("error", reject);
		}, {
			headers: {
				"User-Agent": USER_AGENT,
				Accept: "application/vnd.github+json"
			},
			proxyPort
		});
		req.on("error", reject);
		req.end();
	});
}
async function githubRelease(owner, repo, proxyPort) {
	try {
		return JSON.parse(await fetchText(`https://api.github.com/repos/${owner}/${repo}/releases/latest`, proxyPort));
	} catch {
		return null;
	}
}
/** Tag as reported by jsDelivr, used when the GitHub API is unreachable. */
async function jsdelivrTag(owner, repo, proxyPort) {
	try {
		const raw = await fetchText(`https://data.jsdelivr.com/v1/packages/gh/${owner}/${repo}?structure=flat`, proxyPort);
		const first = JSON.parse(raw).versions?.[0];
		return first ? `v${first.version.replace(/^v/, "")}` : null;
	} catch {
		return null;
	}
}
function isPrerelease(tag) {
	return /-(alpha|beta|rc|dev)/i.test(tag);
}
/** Rebuilds an asset URL from the known release naming when the API has none. */
function fallbackAssetUrl(engine, version) {
	const numeric = version.replace(/^v/, "").split("-")[0];
	switch (engine) {
		case "xray": return `https://github.com/XTLS/Xray-core/releases/download/v${numeric}/Xray-windows-64.zip`;
		case "singbox": return `https://github.com/SagerNet/sing-box/releases/download/v${numeric}/sing-box-${numeric}-windows-amd64.zip`;
		case "mihomo": return `https://github.com/MetaCubeX/mihomo/releases/download/v${numeric}/mihomo-windows-amd64-v${numeric}.zip`;
		default: return null;
	}
}
function viaChannel(url, channel) {
	return channel === "mirror" ? `${MIRROR_PREFIX}${url}` : url;
}
/** Downloads to a file and refuses to report success on a short read. */
function downloadTo(url, target, onProgress, options, timeoutMs = 6e5) {
	return (async () => {
		const proxyPort = options.proxyPort;
		return new Promise((resolve, reject) => {
			const go = (current, redirects) => {
				if (redirects > 6) return reject(/* @__PURE__ */ new Error("重定向过多"));
				const req = httpsGet(current, timeoutMs, (res) => {
					if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
						res.resume();
						go(new URL(res.headers.location, current).toString(), redirects + 1);
						return;
					}
					if (res.statusCode !== 200) {
						res.resume();
						reject(/* @__PURE__ */ new Error(`HTTP ${res.statusCode}`));
						return;
					}
					const total = Number(res.headers["content-length"] ?? 0);
					let got = 0;
					let settled = false;
					const out = (0, node_fs.createWriteStream)(target);
					const fail = (err) => {
						if (settled) return;
						settled = true;
						clearTimeout(idle);
						out.destroy();
						(0, node_fs.rmSync)(target, { force: true });
						reject(err);
					};
					let idle = setTimeout(() => req.destroy(/* @__PURE__ */ new Error("下载停滞，请尝试切换为国内镜像站")), 6e4);
					res.on("data", (c) => {
						clearTimeout(idle);
						idle = setTimeout(() => req.destroy(/* @__PURE__ */ new Error("下载停滞，请尝试切换为国内镜像站")), 6e4);
						got += c.length;
						onProgress(got, total);
					});
					res.on("error", (e) => fail(e));
					res.pipe(out);
					out.on("error", (e) => fail(e));
					out.on("finish", () => {
						clearTimeout(idle);
						out.close(() => {
							if (settled) return;
							if (total > 0 && got < total) {
								settled = true;
								(0, node_fs.rmSync)(target, { force: true });
								reject(/* @__PURE__ */ new Error(`下载不完整（${Math.round(got / total * 100)}%），请重试或切换下载渠道`));
								return;
							}
							settled = true;
							resolve();
						});
					});
				}, { proxyPort });
				req.on("error", (e) => reject(e));
				req.end();
			};
			go(url, 0);
		});
	})();
}
/** Version check for all three cores. */
async function checkCoreUpdates(proxyPort = null) {
	const channel = channelOverride;
	const out = [];
	for (const engine of ENGINE_KEYS) {
		const meta = CORE_REPOS[engine];
		const local = await currentCoreVersion(engine);
		let latest = null;
		let asset = null;
		const rel = await githubRelease(meta.owner, meta.repo, proxyPort);
		if (rel?.tag_name && !isPrerelease(rel.tag_name)) {
			latest = rel.tag_name.replace(/^v/, "");
			const hit = rel.assets?.find((a) => meta.asset.test(a.name));
			if (hit) asset = {
				name: hit.name,
				url: hit.browser_download_url,
				digest: hit.digest ?? null
			};
		}
		if (!latest) {
			const tag = await jsdelivrTag(meta.owner, meta.repo, proxyPort);
			if (tag && !isPrerelease(tag)) latest = tag.replace(/^v/, "");
		}
		if (!asset?.url && latest) {
			const url = fallbackAssetUrl(engine, latest);
			if (url) asset = {
				name: `${meta.label}-${latest}.zip`,
				url
			};
		}
		const missing = local === null;
		out.push({
			engine,
			label: meta.label,
			local,
			latest,
			missing,
			updateAvailable: Boolean(latest) && (missing || compareVersions(latest, local) > 0),
			channel,
			assetUrl: asset?.url ?? null,
			assetSha256: asset?.digest ? asset.digest.replace(/^sha256:/i, "") : null,
			error: latest ? null : "无法获取版本信息"
		});
	}
	return out;
}
/**
* Downloads, verifies and stages one core.
*
* The proxy is never stopped: nothing here touches a live binary, and the swap happens on
* the next launch from applyStagedCores().
*/
async function stageCoreUpdate(engine, onProgress, proxyPort) {
	const info = (await checkCoreUpdates(proxyPort)).find((c) => c.engine === engine);
	if (!info) throw new Error("未找到内核信息");
	if (!info.updateAvailable && !info.missing) throw new Error("该内核已是最新版本");
	if (!info.assetUrl || !info.latest) throw new Error(info.error ?? "没有可用的下载地址");
	return { staged: await stageCore({
		engine,
		version: info.latest,
		url: viaChannel(info.assetUrl, info.channel),
		expectedSha256: info.assetSha256,
		onProgress,
		download: (url, target, progress) => downloadTo(url, target, progress, { proxyPort })
	}) };
}
//#endregion
//#region mods/proxy/main/index.ts
/**
* The shared manager.
*
* Resolved inside register() once the host has been injected — taking the function
* reference here would leave `proxyManager.onState` undefined.
*/
var proxyManager$1;
/** the mixed port while a core is running (updates tunnel through it) */
function activePort() {
	const state = proxyManagerRef().state();
	return state.engines.some((e) => e.running) ? state.settings.mixedPort : null;
}
/** staged record → the shape the UI consumes */
function toStagedInfo(s) {
	return {
		engine: s.engine,
		label: s.label,
		version: s.version,
		size: s.size,
		sha256: s.sha256,
		targetPath: s.targetPath
	};
}
var wired = false;
/** Wire manager events to the renderer exactly once. */
function wireEvents(host) {
	if (wired) return;
	wired = true;
	proxyManager$1.onState((state) => host.ipc.broadcast("state-changed", state));
	proxyManager$1.onLog((event) => host.ipc.broadcast("log", event));
}
function asCoreId(v) {
	return v === "xray" || v === "singbox" || v === "mihomo" ? v : null;
}
function register(dola) {
	const host = dola;
	const channel = dola.settings.get().general?.downloadChannel;
	setUpdateChannel(channel === "mirror" ? "mirror" : "github");
	setProxyHost(dola);
	proxyManager$1 = proxyManagerRef();
	wireEvents(dola);
	host.ipc.handle("state", () => proxyManager$1.state());
	host.ipc.handle("engines", async () => {
		try {
			return await proxyManager$1.engines();
		} catch {
			return [];
		}
	});
	host.ipc.handle("save-node", (draft) => {
		if (typeof draft !== "object" || draft === null) return null;
		const d = draft;
		try {
			return proxyManager$1.saveNode(d);
		} catch (e) {
			host.log("error", `save-node: ${e instanceof Error ? e.stack : String(e)}`);
			return null;
		}
	});
	host.ipc.handle("delete-node", (id) => {
		if (typeof id !== "string" || !id) return;
		try {
			proxyManager$1.deleteNode(id);
		} catch {}
	});
	host.ipc.handle("import-links", (text) => {
		if (typeof text !== "string") return {
			added: [],
			failed: []
		};
		try {
			return proxyManager$1.importLinks(text);
		} catch (e) {
			host.log("error", `import-links: ${e instanceof Error ? e.stack : String(e)}`);
			return {
				added: [],
				failed: [{
					link: "",
					reason: "导入失败"
				}]
			};
		}
	});
	host.ipc.handle("select-node", (id) => {
		const nodeId = typeof id === "string" && id ? id : null;
		try {
			return proxyManager$1.selectNode(nodeId);
		} catch {
			return proxyManager$1.state();
		}
	});
	host.ipc.handle("start", async () => {
		try {
			return await proxyManager$1.start();
		} catch (e) {
			return {
				engine: dola.settings.get().proxy.defaultEngine,
				available: false,
				version: null,
				running: false,
				pid: null,
				nodeId: null,
				startedAt: null,
				error: e instanceof Error ? e.message : "启动失败",
				mixedPort: dola.settings.get().proxy.mixedPort,
				logs: []
			};
		}
	});
	host.ipc.handle("stop", async () => {
		try {
			return await proxyManager$1.stop();
		} catch (e) {
			return {
				engine: proxyManager$1.state().activeEngine,
				available: false,
				version: null,
				running: false,
				pid: null,
				nodeId: null,
				startedAt: null,
				error: e instanceof Error ? e.message : "停止失败",
				mixedPort: dola.settings.get().proxy.mixedPort,
				logs: []
			};
		}
	});
	host.ipc.handle("test-node", async (id) => {
		const nodeId = typeof id === "string" ? id : "";
		if (!nodeId) return {
			nodeId: "",
			ok: false,
			delayMs: null,
			exitIp: null,
			country: null,
			error: "缺少节点 id"
		};
		try {
			return await proxyManager$1.testNode(nodeId);
		} catch (e) {
			return {
				nodeId,
				ok: false,
				delayMs: null,
				exitIp: null,
				country: null,
				error: e instanceof Error ? e.message : "测试失败"
			};
		}
	});
	host.ipc.handle("system-proxy", async (on) => {
		try {
			return await proxyManager$1.setSystemProxy(on === true);
		} catch {
			return false;
		}
	});
	host.ipc.handle("import-geo", async () => {
		try {
			return await proxyManager$1.importGeo();
		} catch {
			return proxyManager$1.state();
		}
	});
	host.ipc.handle("update-geo", async () => {
		try {
			dola.cores.clearVersionCache();
			return await proxyManager$1.updateGeo();
		} catch {
			return proxyManager$1.state();
		}
	});
	host.ipc.handle("clear-logs", (engine) => {
		const id = asCoreId(engine);
		if (!id) return;
		try {
			proxyManager$1.clearLogs(id);
		} catch {}
	});
	host.ipc.handle("geo-state", () => proxyManager$1.geoState());
	host.ipc.handle("toggle", async () => {
		return proxyManager$1.state().engines.some((e) => e.running) ? proxyManager$1.stop() : proxyManager$1.start();
	});
	/** Mixed port while a core is running, else null. Used to route update downloads. */
	host.ipc.handle("active-port", () => {
		const state = proxyManager$1.state();
		return state.engines.some((e) => e.running) ? state.settings.mixedPort : null;
	});
	host.ipc.handle("apply-settings", async (before, next) => {
		if (next && typeof next === "object") await onProxySettingsChanged(next);
	});
	/** Re-read the node store after the settings window replaced it. */
	host.ipc.handle("reload", () => proxyManager$1.reload());
	host.ipc.handle("check-core-updates", async () => {
		try {
			return await checkCoreUpdates(activePort());
		} catch {
			return [];
		}
	});
	host.ipc.handle("stage-core", async (engine, channel) => {
		const id = engine;
		if (![
			"xray",
			"singbox",
			"mihomo"
		].includes(id)) return {
			ok: false,
			error: "未知内核"
		};
		try {
			const { staged } = await stageCoreUpdate(id, (percent) => host.ipc.broadcast("update-progress", {
				kind: "core",
				engine: id,
				percent,
				state: "downloading"
			}), activePort());
			host.ipc.broadcast("update-progress", {
				kind: "core",
				engine: id,
				percent: 100,
				state: "done"
			});
			return {
				ok: true,
				staged: toStagedInfo(staged),
				needsRestart: true
			};
		} catch (e) {
			const message = e instanceof Error ? (e.stack ?? e.message) || "下载失败" : "下载失败";
			host.ipc.broadcast("update-progress", {
				kind: "core",
				engine: id,
				percent: 0,
				state: "error",
				message
			});
			return {
				ok: false,
				error: message
			};
		}
	});
	host.ipc.handle("stage-all-cores", async () => {
		const staged = [];
		const failed = [];
		try {
			const list = await checkCoreUpdates(activePort());
			for (const item of list.filter((c) => c.updateAvailable && c.assetUrl)) try {
				const { staged: one } = await stageCoreUpdate(item.engine, (percent) => host.ipc.broadcast("update-progress", {
					kind: "core",
					engine: item.engine,
					percent,
					state: "downloading"
				}), activePort());
				staged.push(toStagedInfo(one));
			} catch (e) {
				const message = e instanceof Error ? e.message : "下载失败";
				host.ipc.broadcast("update-progress", {
					kind: "core",
					engine: item.engine,
					percent: 0,
					state: "error",
					message
				});
				failed.push({
					engine: item.label,
					error: message
				});
			}
		} catch (e) {
			failed.push({
				engine: "检查",
				error: e instanceof Error ? e.message : "检查失败"
			});
		}
		return {
			ok: failed.length === 0,
			staged,
			failed,
			needsRestart: staged.length > 0
		};
	});
	host.ipc.handle("staged-cores", () => readStagedCores().map(toStagedInfo));
	host.ipc.handle("clear-staged", () => {
		for (const item of readStagedCores()) try {
			host.fs.rm(item.stagedPath, { force: true });
			host.fs.rm(join(item.stagedPath, ".."), {
				recursive: true,
				force: true
			});
		} catch {}
		writeStagedCores([]);
		return { ok: true };
	});
	host.ipc.handle("apply-staged", () => {
		if (!hasStagedCores()) return {
			ok: false,
			error: "没有待应用的内核"
		};
		const wasRunning = proxyManager$1.state().engines.some((e) => e.running);
		host.app.relaunch(wasRunning ? "proxy" : null, async () => {
			await proxyManager$1.stop();
			await proxyManager$1.setSystemProxy(false);
		});
		return { ok: true };
	});
	host.ipc.handle("has-staged", () => hasStagedCores());
	dola.on("boot", async () => {
		try {
			const result = await applyStagedCores();
			if (result.applied.length > 0) host.log("info", `内核已更新：${result.applied.join(", ")}`);
			if (result.failed.length > 0) host.log("error", `内核替换失败：${result.failed.map((f) => `${f.engine}: ${f.error}`).join("; ")}`);
		} catch (e) {
			host.log("error", `内核替换异常：${e instanceof Error ? e.message : String(e)}`);
		}
		const resume = resumeRequested();
		const settings = dola.settings.get();
		if (resume || settings.proxy.autoStart) try {
			await proxyManager$1.start();
		} catch {}
	});
	dola.on("quit", async () => {
		try {
			await proxyManager$1.stop();
			await proxyManager$1.setSystemProxy(false);
		} catch {}
	});
}
/**
* Whether the app asked for a post-update resume.
*
* The marker is written by the update flow before it restarts the app; the host exposes
* it per mod id so no feature-specific flag lives in the core.
*/
function resumeRequested() {
	return globalThis.__DOLA_RESUME_MODS__?.includes("proxy") ?? false;
}
/**
* Called by the settings IPC when proxy settings change so that a running core
* can pick up a new port / log level without a manual restart.
*/
async function onProxySettingsChanged(next) {
	const state = proxyManager$1.state();
	if (!state.engines.some((e) => e.running)) return;
	if (next.mixedPort !== state.settings.mixedPort) try {
		await proxyManager$1.stop();
		await proxyManager$1.start();
	} catch {}
}
//#endregion
exports.onProxySettingsChanged = onProxySettingsChanged;
exports.register = register;
